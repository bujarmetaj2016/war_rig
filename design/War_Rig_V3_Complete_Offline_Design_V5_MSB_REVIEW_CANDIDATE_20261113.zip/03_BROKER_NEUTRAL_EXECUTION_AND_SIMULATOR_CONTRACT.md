# Broker-neutral execution and simulator contract (proposed core normative interface)

## No-IG offline boundary

The offline simulator implements a broker-neutral protocol that **does not link, import, load, call, authenticate or route to IG**. There are two distinct runtime implementations in the overall product roadmap: `OfflineBrokerSimulator` at G1-R; any actual `IGAdapter` only after separate future G2/G3 authorisation. Exactly one conformance suite is defined against the shared protocol; the simulator runs it during offline implementation, the later adapter is required to run the applicable same cases plus independently approved IG probes.

### Typed interface sketch (shape only, NOT deployed code)

```
capabilities(account_scope, instrument) -> CapabilityRecord | NOT_PROVEN
quote(account_scope, instrument, as_of) -> QuoteSnapshot | UNKNOWN
submit_market(intent_id, attempt_id, policy_hash, side, stake, initial_protection_spec, guard_hash) -> ACCEPTED(ref) | REJECTED(reason) | UNKNOWN(transport_or_broker_evidence)
read_order(account_scope, source_intent_id, broker_ref?) -> snapshot | UNKNOWN
read_position(account_scope, position_id) -> filled_quantity, avg_fill, applied_stop, applied_target, verified_timestamp | UNKNOWN
modify_stop(modify_intent_id, attempt_id, position_id, new_stop, policy_hash, fence) -> ACCEPTED(ref) | REJECTED(reason) | UNKNOWN
cancel_or_close(intent_id, position_id, qty, fence) -> ACCEPTED | REJECTED | UNKNOWN
read_events(correlation_scope) -> immutable broker events + provenance | UNKNOWN
```

- `CapabilityRecord` must declare tick/price grid, money-per-point, currency conversion, minimum size, stop distance, supported order types, modification feasibility, protection semantics, and reliability/evidence status. **Fixture values are explicitly synthetic and signed**; unverified IG values must never be represented as certified.
- Direction-sensitive quote price and spread are explicit. Model/reference price and executable-side price remain separate; no stale-close fallback.
- `ACCEPTED` means the adapter accepted/recorded a request, **not** proof of fill, applied stop, realised P&L or closed position. `UNKNOWN` is a first-class nonterminal result. Read-back has a separate independent failure path.
- All requests bind to explicit account and product scope, position identity, a durable pre-commit intent, immutable policy version and writer fence; an operation has **at most one wire attempt per intent**. Idempotency keys identify a local intent; they do not imply a broker duplicate-suppression guarantee. No retries of the same intent.
- Reconciliation is authoritative only on evidence sufficient for that specific claim, not on a timeout, an error code or a missing item in a partial snapshot. UNKNOWN reserves gross potential exposure. Distinguish PARTIALLY_FILLED, PARTIALLY_CLOSED, COMPLETE, CANCELLED_PRE_FILL, UNKNOWN and explicit NOT_SENT proof.
- A stop modification checks the **latest verified applied** stop and its instrument grid. Only tighter stops allowed. The simulator can perform modifications under `SIMULATOR_ONLY_TIGHTEN`, and must permit fault injection returning `UNKNOWN`, `REJECTED`, stale, external widening and broker-applied mismatches. The real IG `LIVE_TIGHTEN_ONLY` mode is not part of G1-R.
- Each broker-neutral result creates typed requested/committed/denied ledger events with **atomic transaction group** correlation spanning intent, attempt, position, protection, capital reservation and audit. If audit cannot be written, no automated simulated mutation proceeds; the failure must be observable.

## Initial fill-to-protection transaction and risk reservation (normative offline test contract; PROPOSED)

**Pre-entry admission.** A signed fixture policy supplies a protective stop/target specification and the capability record declares whether the simulated broker can attach protection to each fill. `initial_protection_spec` carries stop type, stop/target prices, direction, version, and synthetic price-grid/size constraints. If protection cannot be attached or positively verified by the allowed simulator policy, **deny new entry**. Any two-step attachment alternative remains `UNSELECTED` and is not implicitly authorised. A returned `ACCEPTED` is not a fill and not verified protection.

**Full or partial fill.** On every authoritative fill event (including a partial fill), record actual filled quantity, price, synthetic account/product identity, position version and **gross worst-case exposure reserved** in a single fenced ledger transaction. Set the position axis to `OPEN_CONFIRMED` (`D03-SRC-015`, fill proven) and the protection axis to `PROTECTION_UNVERIFIED` (`D03-SRC-020`); do not set `PROTECTION_VERIFIED` merely because the order was accepted, protection was requested, or a fill was seen. Any remaining unfilled quantity stays independently reserved according to the maximum possible pending exposure. The simulator must bind each new partial quantity to effective protection; after every quantity change, re-verify the entire filled size and applied protective stop. No trailing evaluates until verified.

**Stop read-back.** An independent, account-bound `read_position` must confirm `filled_quantity`, `applied_stop`, price-grid correctness, protective side and min stop distance, policy/version compatibility, and correct ownership. A verified match moves protection from `PROTECTION_UNVERIFIED` to `PROTECTION_VERIFIED` (`D03-SRC-028`) and releases only the justified protection uncertainty, **not** the position's capital/risk reservation. An applied stop different from requested outside an *approved* tolerance (UNSET means exact match only), missing stop, failed read or stale/partial evidence remains `PROTECTION_UNVERIFIED` (or becomes `PROTECTION_DRIFT` when a defect is proven, `D03-SRC-023`), freezes trailing for the position, blocks additional simulated entry under its fail-closed fixture policy, preserves gross risk reservations, writes an incident and requests an independently evidenced watchdog alert. An applied stop worse than the last verified stop is never silently promoted.

**Rejected, ambiguous, missing initial protection.** If the entry is rejected with authoritative proof of no fill, leave `NOT_FILLED` and release a reservation only after that proof. If an entry result is `UNKNOWN`, retain maximum pending exposure; a timeout or partial snapshot does not prove absence. If protection is rejected, missing, or its modification outcome is ambiguous, **no blind retry, no automatic IG/real close or repair**. Offline simulator may exercise a separately labelled *fixture-only protective-response test*, but that is a negative scenario, not a default remediation permission. A real broker account's protective-response A/B/C remains owner-open at G3.

**Crash, concurrent close, and audit failure.** A crash between fill and first verified stop must recover with position `BROKER_OUTCOME_UNKNOWN` (if the fill itself is not proven) or position `OPEN_CONFIRMED` with protection `PROTECTION_UNVERIFIED`, full reservations and no trailing until authoritative read-back. A close/fill/partial-fill race uses the one-writer, atomic cross-axis commit and a fresh account/position read; conflicting evidence freezes mutation. If audit pre-commit fails, deny the mutation; if the fill has already occurred externally, preserve exposure, mark protection unverified and alert—**never invent an order rollback**.

**Invariant:** the simulator never presents an active position as safely protected without independent applied-stop and quantity evidence, and never treats a requested protective change as applied. These are contract *specifications* and fixture tests; no implementation or broker capability is claimed.

## Modes that cannot be confused

| Mode | What it does | Broker write import permitted |
|---|---|---|
| `OFF` | Records no trading proposals | None |
| `COMPUTE_AND_LOG_ONLY` | Calculates stop or simulated trade decisions and logs only | None |
| `SIMULATOR_ONLY_TIGHTEN` | Sends one broker-neutral modification to a strictly local offline simulator and verifies its applied stop | Offline simulator only, no networking |
| `LIVE_TIGHTEN_ONLY` | **Future G3 candidate**, separately verified IG mutation authority and stop read-back | **DENIED/ABSENT in offline artifacts** |

## Safety vs routine management

An authorised **offline simulated** tighten is part of normal position management, not emergency repair. An unprotected or unknown simulated position triggers an incident/alert, preserves exposure and follows an explicit fixture-controlled protective-response scenario; this does not grant a real-IG emergency-close capability. Local Stop blocks new simulated entries but does not stop observing/managing established simulated positions; the separate mutation-safety latch can freeze automated trailing. An external manual real IG close remains outside offline scope.

## Required simulator fault schedule (minimal contract)

- Reject order without filling; reject stop update after the request is recorded; return UNKNOWN despite applying a stop; drop acknowledgment after partial fill; duplicate and reorder confirmation events.
- Simulate a bad position snapshot, delayed read-back, stale quote, wrong account, invalid instrument grid, too-tight/wide stop, widened external stop and absent stop.
- Simulate partial fills/partial closes; close/fill races; manager crash between intent commit and send; journal disk-full; duplicate tick; stale model artifact; daylight-saving/market closed window.
- Simulate direct-IP/DNS/outbound transport attempts and require zero external network egress. No fixture may be allowed to carry an actual IG secret.

**Contract-change rule:** the future IG adapter must satisfy these exact shared behaviour classes and any additional separately approved IG constraints. Any necessary strategy-domain rewrite is a design regression that requires disclosure and controlled review; do not promise perfect platform interchangeability before G2/G3 proof.
