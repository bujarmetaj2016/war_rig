# G0-R: one owner acceptance of the complete offline-core design — BLANK / UNSIGNED

**Owner action required only after full final group presentation, valid 48h wait and independent evidence.** This form is an artifact for review; it is not executable approval merely by inclusion in a ZIP.

- Final accepted immutable group root SHA-256: `________________`
- Final core-design baseline SHA-256: `________________`
- Controlled source amendments AM-01..AM-14 exactly as in `23_CONTROLLED_AMENDMENT_EXACT_TEXT.csv` (its SHA-256) and the adopted amended-source hashes: `________________`
- Owner-selected Master Option R / EXT Option C (yes/no): `________________`
- MS-B dual-source predictions, no refit: file 24, file 25 and tests MSB-01..MSB-19 exactly as hashed; OC-D04-04 stays DEFER and no model cadence is selected (yes/no): `________________`
- Full component schedule hash and all 16+2 dispositions: `________________`
- Formal 14 Stage D decisions + 4 ATC decisions (all identified) hashes and values: `________________`
- All 43 master dispositions, all 13 freeze-finding dispositions, all 21 repair dispositions: `________________`
- Independent review and quorum/witness/custody evidence hashes: `________________`
- 27-Oct rule (a)/(b) primary source hash and applicability: `________________`
- Last complete presentation UTC / cooling-off completion UTC / elapsed hours: `________________`
- Scope exclusions: IG integration, real broker mutations, V2 runtime modifications, DEMO/LIVE and model fitting/promotion unapproved; the only prediction sources are signed test scores and owner-registered non-executable trained models under MS-B (file 24): `[CONFIRM]`
- Accepted residuals, each with denial gate/test and later owner gate: `________________`

**Proposed owner acceptance text (NOT spoken or selected):**

> I accept, for DESIGN_ONLY and broker-independent offline implementation planning, the complete War Rig V3 core under Master Option R and EXT Scope C, against the exact immutable hashes entered above. This includes simulated trading, confidence-based strategies and sizing, TP/SL, adaptive trailing and verification, risk, ledger, watchdog, audit, dashboard and comparison. I separately acknowledge that this G0-R acceptance alone grants no implementation, IG, DEMO or LIVE authority. All listed open or deferred items retain their recorded denials. I have reviewed the independent evidence, signature/quorum/custody proof and completed grouped 48-hour hold under the governing rule.

Owner identity/signature: `________`  UTC: `________`  Independent/countersignature proof: `________`.

**Current state: NOT_SELECTED / NOT_SIGNED / NOT_ACCEPTED.**
