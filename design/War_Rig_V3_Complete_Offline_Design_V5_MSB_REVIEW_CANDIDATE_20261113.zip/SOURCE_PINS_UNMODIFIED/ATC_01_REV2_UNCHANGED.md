# War Rig V3 — ATC-01: adaptive position protection (trailing) and trading confidence

**Author:** R2 (design proposal, in the same way as WDA-08). **Date:** 13 November 2026. **Revision 2** of the same day: applies the author's integration assessment (ATC-I01 to ATC-I08) and two wording fixes of my own. The core design in section 1 is unchanged. Section 9 lists what changed.
**Status:** `DESIGN_ONLY / PROPOSED / NONBINDING / NOT_FROZEN / NOT_AUTHORISED`.
**What this is not:** it selects nothing, approves nothing, changes no pinned source, and contains no owner policy value. Every improvement below is a **hypothesis to test**, not a result. Nothing was run and no V2 outcome data was analysed.
**Why it exists:** Jon's direction is that V3 must improve V2, and that adaptive trailing and confidence were main V2 features. This keeps both and improves them. V2's own behaviour is the floor.

---

## 1. In plain words (for Jon)

**What I propose.** Keep V2's adaptive trailing and confidence. Reproduce V2's rules as the starting policy, so V3 does what V2 did whenever its inputs are verified. The only differences are four safety rules, listed in 3.6: no trailing from an unverified stop, none on missing or stale data, no unverified stop stored as applied, and no second send of a stop move. Then fix what V2 did badly, and test each improvement beside V2's rule before it is allowed to replace it. You approve each promotion.

**What V2 really does, read from the code.**
- *Trailing.* Once a trade is more than half a risk-unit in profit, V2 scores "continuation" from 0 to 100 and trails the stop very tightly behind the best price (0.15 to 0.25 of the initial risk). Before that, and as a fallback, it moves to break-even and then trails by a multiple of ATR. The adaptive rule was **evaluated for every** instrument whenever the global mode was on. Whether it actually moved a stop on each instrument, and whether that helped, is not shown by the code and needs the V2 logs.
- *Confidence.* The model's probability is multiplied by a macro "climate" number. That product gives the grade A to D. The grade sets the stake tier. Outside FX it also sets the break-even trigger and the ATR trail multiple.

**Six things in V2 worth improving.** All are in the code or in my earlier source review.
1. **A quarter of the continuation score is free.** 25 of 100 points just mean "spread data was present" and "ATR data was present". So one yes/no signal, price above its EMA, already puts a trade in the "moderate" tier.
2. **Profit is measured against the stop V2 asked for, not one verified at IG.** "R" uses the model's stop from signal creation. If IG applied a different level, or the read-back failed, R is wrong.
3. **Stop verification is best-effort.** If the position read fails, V2 stores the stop it *asked for* as if IG had applied it.
4. **Confidence drives trailing in a way nobody tested.** Highest-grade trades get the tightest trail and the earliest break-even; lowest-grade the widest and latest. It may be right. There is no evidence either way.
5. **The confidence number is not a probability.** It is a product, the model is not calibrated, shorts are scored as the complement of a long-side label, and missing features are filled with zero.
6. **The mode was named "shadow" but moves live stops,** and a per-instrument "adaptive" flag exists that nothing reads.

**What the design does.**
- *Trailing.* One decision function says HOLD or PROPOSE. A gated pipeline then proposes, authorises, sends, reads back the stop IG really applied, and marks it verified or unverified. The policy version is stamped on every position and every move. Four candidate improvements run beside V2's rule, and you approve any promotion.
- *Confidence.* Five things V2 blended are kept apart: raw score, calibrated probability, evidence quality, climate, and the decision band. An entry needs the **lower bound** of a calibrated probability to beat the break-even of the trade's take-profit and stop-loss after costs. For a +1.5% / −1.0% trade, break-even is a 40% win rate before spread. That is the entry gate, not proof of profit: trailing changes the outcomes, so stake increases and promotion also need a positive average realised result by band under the rule actually traded. Stake tiers go up only with confidence and are capped. Missing data means no trade, not zero. Confidence never widens a stop or a target.

**What stays, and what it costs.** Trailing and confidence stay, and trailing stays tighten-only. The costs are more verification work, and a stricter entry test. The stricter test will refuse some entries V2 would have taken: low-confidence ones, shorts without short-side evidence, and trades with missing features. That is deliberate. Section 7 lets you choose parity instead for any of them.

**What you decide.** Four items, listed once in section 7.

**Corrections to my earlier review (revision 2).** Reading the code settled two things I had wrong or open:
- V2's per-instrument `requires_adaptive_protection` flag is metadata that nothing enforces (symbol_resolver.py, a TODO). The adaptive trailing rule is gated only by the global `EXIT_POLICY_MODE` and was evaluated for all instruments. So the EXT-G0R-14 V2 map's "adaptive: Gold only" does not describe what V2 did.
- I said confidence changed stake size, "not TP/SL". It also selected the break-even trigger and trail multiple through the grade (non-FX). It still did not change TP/SL distances.

---

## 2. What V2 does (verified against the uploaded snapshot)

All anchors are checked by `check_atc01.py`: 27 code anchors, 11 checks, none failed.

| # | Element | V2 behaviour | Anchor |
|---|---|---|---|
| V-1 | Gate | The adaptive rule runs only if env `EXIT_POLICY_MODE=adaptive_shadow_v1`. Global, all instruments. The per-instrument `requires_adaptive_protection` is metadata only. | position_manager.py:913; symbol_resolver.py:171-185 |
| V-2 | Entry to the rule | Only if unrealised R > 0.50, else HOLD. | position_manager.py:307 |
| V-3 | R basis | R uses the signal's model stop (`sl_price`, the stop requested at entry), not a verified read-back of the stop IG applied. The docstring flags the dependency. | position_manager.py:282-288 |
| V-4 | Tiers, R ≥ 1.0 | Trail 0.25R, 0.20R or 0.15R behind the best price (watermark) for score ≥ 65, ≥ 50, otherwise. | position_manager.py:331-341 |
| V-5 | Tiers, 0.5 < R < 1.0 | Score ≥ 65: HOLD, use baseline. ≥ 50: 0.20R. ≥ 40: 0.15R. < 40 "squeeze": stop at fill price ∓ 0.25R, i.e. a loss stop at −0.25R. | position_manager.py:344-362, 370 |
| V-6 | Distance floor | Trail distance = max(fraction × risk, max(2 × spread, broker minimum stop)). HOLD if neither spread nor minimum stop is known. | position_manager.py:322-324, 373 |
| V-7 | Invariants | Never loosen against the current broker stop, never cross the market, keep the minimum market distance. | position_manager.py:381-434 |
| V-8 | Continuation score | 25 price vs EMA; 20 "EMA slope" (actually the last five closes); 20 at or beyond the watermark; **15 spread present; 10 ATR present**; 10 within one ATR of the watermark. No ML. | shadow_exit_lab.py:232, 250-310 |
| V-9 | Existing state machine | Break-even at a trigger, then ATR trail. Floors by instrument (Gold 50, DAX 20, SP500 10, FX 30 points); break-even buffer 2 points; modify hysteresis 2 points. | position_manager.py:82-98 |
| V-10 | Parameters by grade | A: BE 0.5%, ATR × 1.5. B: 0.6%, × 2.0. C: 1.0%, × 3.5. D: 1.2%, × 4.0. Missing grade defaults to C. FX pairs override with BE 0.3%, × 1.5; DAX, Gold, SP500 use the grade values. | position_manager.py:17-25, 102-107, 485-510 |
| V-11 | Precedence | Adverse-exit path for R < 0 (off by default; shadow and live are separate env flags, and live needs shadow); then the adaptive rule; then the state machine. A TIGHTEN skips the trail that tick. Whether the adverse-exit flags were on in production is not shown by the snapshot. | position_manager.py:596-620, 909-925 |
| V-12 | Verification | Read-back is best-effort; if the position read fails the requested stop is stored as an estimate. | source review IM-12 (:29) |
| V-13 | Confidence | Model label is one long-side barrier event (TP 1.5% before SL 1.0% for Gold, DAX, US 500). Bearish means probability ≤ 0.45. Class re-weighted; nothing calibrates. | source review SR-18 (:93) |
| V-14 | Missing features | Zero-filled at inference, rows dropped in training. | source review SR-17 (:92) |
| V-15 | Grade | Grade = confidence × 100, confidence = probability × climate / 100; bands A 60, B 45, C 30, else D; risk tier follows grade. | source review SR-19 (:94) |

**What the score arithmetic shows (checks A04 to A08).** The 25 availability points shift every threshold. The tiers 40, 50 and 65 need only 20, 25 and 40 points of market evidence out of 75. Price above EMA alone scores 50, so a single binary reading reaches the "moderate" tier. With all three price features against, a trade scores 25 or 35, which is the squeeze tier.

---

## 3. Part A: adaptive position protection

### 3.1 Principles

1. **Floor first.** V2's rule is reproduced as `V2_PARITY_V1` before anything is improved. It has two outputs. The **reference replay** is V2's own decision on pinned inputs, exactly. The **executable result** is the same rule passed through V3's safety rules. Every difference between them is a numbered divergence with a reason (3.6). V3's safety rules are never weakened to match V2.
2. **Tighten-only.** A stop never moves away from the market (D03-04).
3. **IG's stop is the truth.** Decisions compare with the latest *verified applied* stop, and R is measured from the broker-confirmed initial stop (D03-06).
4. **Unknown means hold.** Missing, stale or unverifiable input produces HOLD, never a score or an estimate.
5. **Name modes by effect.** "Shadow" is reserved for compute-and-log with no broker-write path.
6. **Improvements are earned.** A candidate replaces the floor only through a pre-registered test and an owner approval.

### 3.2 Pipeline for one position

1. **Evaluate.** A pure function of (the position's immutable record, the latest verified stop, a timestamped market snapshot, the policy version) returns `HOLD(reason)` or `PROPOSE(stop, reason, inputs digest)`. It has no side effects.
2. **Authorise.** Preconditions: audit write succeeds; no latch disabling automated mutation; the position is in a verified-protection state; the policy and mode are enabled by an effective permit; the minimum interval and minimum move are respected; single fenced writer. The permit is a separate typed broker authority to modify a stop on this account, product and position. A ledger edge does not imply it. The request and its audit record are committed before the send. The preconditions are checked again inside the same fenced write that records the send, together with a fresh read of the position. A close, cancel, manual change, partial fill or terminal state seen at that point cancels the move.
3. **Send.** A modification is its own intent with a stable key and at most one wire attempt (T07).
4. **Read back.** Read the applied stop from IG and compare it under the tolerance rule in T08.
5. **Record.** Match: VERIFIED, version n+1 (ledger edge D03-ADD-034). Mismatch or read failure: UNVERIFIED, the last verified stop stays the reference, trailing freezes for that position, and an alert is raised.

### 3.3 Requirements

| ID | Requirement |
|---|---|
| ATC-T01 | **One evaluator, one proposal per position per tick.** Replaces V2's three overlapping paths with one ordered rule set. The precedence of V-11 is kept and recorded in the reason code. |
| ATC-T02 | **Tighten-only against the latest verified applied stop.** Never propose a stop equal to or looser than it. Never cross the market. Keep the minimum market distance = max(2 × spread, broker minimum stop), as V2 does. Unknown spread and unknown minimum stop: HOLD. |
| ATC-T03 | **R from the broker-confirmed initial stop and actual fill.** If the initial applied stop is unverified, R is unknown and the result is HOLD(`R_UNKNOWN`). V2 used the stop it requested (V-3). |
| ATC-T04 | **Missing or stale inputs produce HOLD.** V2 awarded 15 and 10 score points for spread and ATR being present (V-8). `V2_PARITY_V1` keeps those points when the data are present and fresh, because they are part of V2's rule. Removing them is candidate C1, not part of the floor. |
| ATC-T05 | **Policy binding.** At entry each position records an immutable `policy_id`, version, parameter digest and arm. A policy change applies to new positions only. |
| ATC-T06 | **Authorisation gates** as in 3.2 step 2. A failed audit write blocks every automated IG mutation (BB-05 item 3). |
| ATC-T07 | **One wire attempt per modification intent. No retry.** The key ties the intent to its ledger record. It is not broker idempotency, and reusing it never authorises a second send (master `NO_IMPLICIT_RETRY`). An ambiguous or failed send is UNKNOWN until an authoritative, attempt-specific read-back reconciles it. Until then that position's trailing is frozen and an alert is raised. After reconciliation, a fresh evaluation on a later tick is a new intent with its own key. It is not a retry. The master's replacement-attempt policy is OPEN and is not used here. IG's duplicate-request behaviour is not assumed (section 8). |
| ATC-T08 | **Read-back verification.** The applied stop is read after every send, from the same account and the same position, and compared in the right direction. VERIFIED needs a match within the per-instrument tolerance approved under D03-04. That tolerance is UNSET. Until it is set and certified, any mismatch is UNVERIFIED. A read failure is UNVERIFIED. An applied stop looser than the last verified stop is UNVERIFIED and raises an alert; it is never silently accepted. An UNVERIFIED stop is never stored as if it were the requested one (V-12). |
| ATC-T09 | **Rejections.** Record the reason code. No retry. N is owner-set and UNSET here. Until it is set, N = 1: the first rejection or mismatch freezes that position's trailing and raises an alert. A frozen position resumes only through a separately defined, audited reset after authoritative reconciliation. Once N is set, up to N consecutive rejections are tolerated, each followed only by a fresh evaluation as a new intent, and then the position freezes. |
| ATC-T10 | **Every move is reconstructable.** Record policy id, version, digest and arm; reason code; the inputs or a digest plus a stored snapshot (R, score components, ATR, spread, watermark); previous verified stop; requested stop; applied stop; timestamps; broker response identifiers. |
| ATC-T11 | **Modes named by effect:** `OFF`, `COMPUTE_AND_LOG_ONLY`, `LIVE_TIGHTEN_ONLY`. The compute-only code path has no broker-write import, enforced by a static test in the manner of V3EXT-070. |
| ATC-T12 | **Degradation.** If V3's manager or watchdog stops, the last verified broker stop is the reference and the stop at IG is expected to remain. Tighten-only means a lost manager leaves a looser stop, not no stop. That is an expectation, not a verified fact: after a failed read-back or an unreconciled send, protection is UNKNOWN and the alert says so. A staleness alert goes through the WDA-08 channel. No new clock is proposed and the deadline stays UNSET. |
| ATC-T13 | **Stop and breakers.** The local Stop is entry-only (OD-11) and does not pause management of open positions. A safety latch that disables automated mutation pauses trailing, and the verified broker stop remains. |
| ATC-T14 | **Parity proof.** The reference replay must reproduce V2's decisions exactly: offline on synthetic cases generated from the rule table in section 2, and later on recorded V2 ticks where the V2 logs hold the inputs. The executable result is then compared with it, and every difference must match a numbered divergence in 3.6. An unexplained difference fails the test. |

### 3.4 Candidate improvements (hypotheses)

Each runs beside `V2_PARITY_V1`. None is live until promoted.

| ID | Hypothesis | Change | Main risk | How it is tested |
|---|---|---|---|---|
| C1 | V2's score barely discriminates, because 25 of its 100 points are free. | Replace it with a score of market-evidence features whose predictive value is measured on out-of-sample data. Candidates: position against short-term trend, volatility regime change, adverse excursion since the watermark in ATR units, time since the last new watermark, spread widening. Missing data: HOLD. | Overfitting a small sample. | Compute-only where it tightens at least as much as V2 does, plus historical replay. Where it would hold while V2 tightens it gives more room, and needs the split. |
| C2 | A trail of 0.15 to 0.25R ignores volatility, so it is noisy in high volatility and loose in low. | Trail distance = max(k × ATR, V2's floors), with k per instrument and regime from evidence, in place of a pure fraction of R. | Wider than V2 in some regimes, so stop-outs change. | Needs the split of DEMO trades (3.5), because a wider stop cannot be evaluated by shadow. |
| C3 | Winners give back profit between tiers. | A profit-lock ladder: at set R levels, lock a fixed fraction of open profit, never beyond the executable-safe level. | Premature exits. | Compute-only if it is tighter than V2; otherwise the split. |
| C4 | Management should follow the market's behaviour, not the entry grade. | Break-even and trail parameters from per-instrument, per-regime evidence (favourable and adverse excursion), instead of from the entry grade (V-10). | Loses whatever signal the grade carries. | Split of trades against the grade mapping in the parity arm. First test whether the grade predicts anything about optimal management. |

### 3.5 Evidence and promotion

- **Arms.** `V2_PARITY_V1` is the control. Each candidate is another arm.
- **Compute-only evidence.** A candidate tighter than the live rule can be scored on the live path as "would have triggered". The limit: it is valid only up to the live exit. A candidate that gives more *room* than the live rule cannot be evaluated this way, because the live rule would already have closed the trade.
- **Split of DEMO trades.** For candidates that give more room, assign each new position to an arm by a pre-registered deterministic hash of its signal identity, balanced by instrument. Record the arm at entry (ATC-T05). The share of each arm is owner-set and UNSET here.
- **Pre-registration.** Before any arm runs, fix the primary metric (net R per trade after spread and slippage), the secondary metrics (give-back from peak, stop-out-before-continuation rate, worst-trade R, rejected or unverified modification rate), the minimum sample per instrument, and the out-of-sample period.
- **Promotion rule.** A candidate is promoted only if: its tail loss is no worse than the control within a stated bound; its primary metric beats the control, with an interval excluding zero or a pre-set minimum effect, on the out-of-sample period; its unverified and rejection rates are no higher; and the result holds per instrument or the promotion is per instrument. Then the owner approves, and the new version applies to new positions only.
- **Sample size is unknown.** Compute the required sample from V2 history variance *before* registering a split. If it cannot be reached in reasonable time, say so and rely on historical replay and compute-only evidence for those candidates.
- **DEMO evidence is DEMO evidence.** DEMO fills and spreads may differ from LIVE. Promotion to LIVE is a separate gate.

### 3.6 Divergences between the reference replay and the executable result

These are the only intended differences. Each has a reason, and none may be removed to match V2 exactly. Candidates C1 to C4 are not divergences. They are separate arms.

| ID | V2 reference | V3 executable result | Reason |
|---|---|---|---|
| DV-1 | R measured from the stop V2 requested (V-3). | R from the broker-confirmed initial stop and the actual fill. Initial stop unverified: HOLD(`R_UNKNOWN`). | An unverified stop is not a fact (T03). |
| DV-2 | A missing EMA, history, watermark, spread or ATR scored no points for that feature and the score was still computed. No price scored 0 (V-8). | Missing or stale price, quote, spread, ATR or any score input: HOLD. | Unknown means hold (T04). |
| DV-3 | Best-effort read-back. If the position read fails, the requested stop is stored as an estimate (V-12). | Read failure, mismatch or a looser applied stop: UNVERIFIED, last verified stop stays the reference, trailing frozen, alert (T08). | IG's stop is the truth. |
| DV-4 | Stop moves were gated by V2's own invariants and hysteresis (V-7, V-9). I did not read V2's retry behaviour. | Sent only if every authorisation precondition passes. One wire attempt per intent. No retry (T06, T07). | Master `NO_IMPLICIT_RETRY`, BB-05. |

A new divergence needs a stated reason and a controlled amendment.

---

## 4. Part B: trading confidence

### 4.1 Layers

V2 blends these into one number. V3 keeps them apart, each stored with its own version (D04-03 already requires the distinction).

| Layer | Meaning | May be called |
|---|---|---|
| L1 | Raw model score, side-specific | "score" only |
| L2 | Calibrated probability per instrument, side and regime, from an out-of-sample calibration artifact, with an interval and a sample count | "probability" |
| L3 | Evidence quality: feature completeness, data freshness, calibration sample size, drift flag | "evidence flags" |
| L4 | Climate or macro context, kept separate and not multiplied into the probability. It stays only if a test shows it adds information. | "context" |
| L5 | Decision band, derived from L2 to L4 | "band" (V2's letters A to D may be kept) |

### 4.2 Uses

| Use | Rule |
|---|---|
| **U1 Eligibility** | An entry needs all of: (i) a side-specific calibrated probability whose **lower bound** exceeds the cost-adjusted break-even of the *traded* geometry plus an owner margin in probability units; (ii) complete features; (iii) a valid, non-stale calibration artifact; (iv) no drift flag. Cost-adjusted break-even probability = (SL + c) / (TP + SL), where c is the expected round-trip cost (spread, slippage, and financing if held) in the same units as TP and SL, taken as the same on a win and a loss. With c = 0 and the +1.5% / −1.0% label geometry in SR-18 it is 0.40, and each 0.1 percentage point of cost adds 0.04. This gates the label event (TP before SL). It is necessary, not sufficient: stake increases and promotion also need a positive mean net realised R by band under the policy actually traded, validated as set out in 4.3. |
| **U2 Stake** | The tier comes from the band. The band sets a **base tier** only. The base tier is monotone: with every other condition equal, higher confidence never gives a smaller base tier. The final stake is the base tier after broker minimums, the finite monetary cap (OD-05), portfolio exposure and theme limits, margin, climate suppress or reduce rules and every safety gate, any of which can reduce or deny it. Confidence never raises a stake past any of them. Unknown or uncalibrated maps to the lowest tier or to ineligible, never the highest. The parity arm copies V2's grade-to-tier values; I have not read them. |
| **U3 Management** | Entry confidence does not select trailing parameters, except in the parity arm (V2's grade mapping) and in an explicit experiment (candidate C4). |
| **Never** | Confidence widens a take-profit or stop; loosens a stop; overrides a safety gate; or raises a stake because calibration is missing or drifting. |

### 4.3 Calibration and evidence

- Calibrate out-of-sample by instrument × side × regime × period, with counts and intervals. Report reliability (expected calibration error with a confidence interval) and Brier score, on a chronological walk-forward.
- **Two calibrations.** The label probability ("TP before SL") and the **realised outcome by band under the policy actually traded**. Trailing and break-even change the outcome distribution, so a label probability alone does not give expected profit. Require a table of mean net realised R by band, per instrument and side. Pre-register the validation before it is run: the cells, the costs in the same units as R, the treatment of censored (still open) outcomes, and the acceptable uncertainty.
- Set a minimum sample per cell. If a cell is short, pool to a coarser cell and flag it, or make it ineligible.
- **Drift monitoring** on feature missingness, score distribution and the rolling calibration residual over recent resolved trades. A drift flag **fails down**: cap the tier, or make the cell ineligible. Recalibration happens only through an authorised promotion (D04 §4 item 4).
- **Side-specific labels.** A short needs a label for the event a short trade needs (−TP before +SL). Until it exists and is evidenced, shorts are ineligible. This is already D04-03's rule.

### 4.4 Requirements

| ID | Requirement |
|---|---|
| ATC-C01 | Keep L1 to L5 as separate stored fields, each with its own version and artifact hash. Only L2 may be labelled "probability". |
| ATC-C02 | Eligibility per U1. Fail closed on any missing element. |
| ATC-C03 | **No zero-imputation.** A missing feature makes the entry ineligible. (V2 filled 0.0 at inference.) |
| ATC-C04 | Side-specific calibration. A short is eligible only with a short-side label and calibration. |
| ATC-C05 | Calibration artifact bound at entry: hash, version, valid-until, sample counts. A stale or missing artifact is ineligible. |
| ATC-C06 | Stake tier per U2: a base tier that is monotone with other conditions equal, reduced or denied by every cap and gate, and lowest or ineligible when unknown. |
| ATC-C07 | Confidence is read-only with respect to stop and take-profit placement and trailing parameters, except per U3. |
| ATC-C08 | Drift flag fails down. |
| ATC-C09 | Realised-R-by-band report per instrument and side, kept as a standing artifact, so band meaning is checked against outcomes. |
| ATC-C10 | The continuation score (management) is a different object from entry confidence. It is never called "confidence". |
| ATC-C11 | Climate (L4) is retained only if a documented test shows it adds information beyond L2. Until then it is a labelled gate input, not a multiplier. |

---

## 5. Fit with the existing V3 design

| Item | Where it lives | What is needed |
|---|---|---|
| Never-loosen, write authority, verified applied stop | D03-04, D03-06, ledger edge D03-ADD-034 | Used as they are. D03-ADD-034 records a verified update. It grants no write, and nothing here treats it as a permit. The permit is separate (3.2, step 2). |
| Each stop move as a transition | `LEDGER_TRANSITION_REQUESTED / COMMITTED / DENIED` | No new event type is proposed. The author maps ATC-T10's fields onto the existing events. Any new type needs the controlled registration under OD-14. |
| Typed policy fields | EXT-G0R-14 §2.2 `ProtectionPolicyParameters` | Proposed additions, by controlled amendment: policy-version binding, minimum trail points, minimum move, break-even buffer, profit-tier table, continuation-score policy reference, maximum modifications per position, minimum interval, arm assignment rule. |
| Monetary cap, stop type | OD-05 | Required before stake tiers have meaning. |
| Protective response when protection is missing | OD-06, WDA-08 | Unchanged. This design is routine management of a verified stop, not rescue. |
| Audit failure blocks automated mutation | BB-05 item 3 | Applies to every stop move (ATC-T06). |
| Calibration, side labels, model cadence | D04-03, D04-04, §4 items 4 and 5 | Implements them. Nothing here activates a model. |
| Offline scope | OD-01 sentence (P-F1, revision 2) | At G0-R only the schemas, the pure evaluator and synthetic tests exist. No broker import (V3EXT-070). Compute-only on live data needs a live snapshot feed, which is a later gate. Replaying recorded V2 ticks needs an owner decision on using V2 data. |

**Not proposed.** No numeric policy value. No new event type or clock. No change to the pinned master, EXT-G0R-14 or WDA-08. No claim that any candidate beats V2. No dependence on IG-specific features I have not verified (see 8).

---

## 6. Acceptance tests (specifications only; all NOT_RUN)

| ID | Test |
|---|---|
| ATC-X01 | Property test on random price paths: no proposal is ever equal to or looser than the latest verified stop. |
| ATC-X02 | Hidden drift: the local stop differs from the broker's. The comparison uses the verified broker stop. |
| ATC-X03 | Initial applied stop unverified: R is unknown and the result is HOLD(`R_UNKNOWN`). |
| ATC-X04 | Spread or ATR missing or stale: HOLD (DV-2). V2 scored the other features and could still have trailed. |
| ATC-X05 | Read-back mismatch with no approved tolerance, or beyond it: UNVERIFIED, trailing frozen, alert. A looser applied stop is never accepted. |
| ATC-X06 | Read-back failure: UNVERIFIED, never stored as the requested stop. |
| ATC-X07 | Broker rejection: no retry. With N unset the first rejection freezes the position. Once N is set, N consecutive rejections do. |
| ATC-X08 | A duplicate tick with the same key produces one modification. A second send under the same intent is denied. |
| ATC-X09 | Audit-write failure blocks the send. |
| ATC-X10 | Static test: the compute-only path imports no broker-write module. |
| ATC-X11 | A policy change leaves open positions on their recorded policy version. |
| ATC-X12 | Parity: the reference replay reproduces V2's tiers, floors and precedence on the synthetic rule-table cases, and every difference in the executable result maps to a numbered divergence (3.6). |
| ATC-X13 | Same tick: an adaptive TIGHTEN skips the trail, as in V-11. |
| ATC-X14 | Spread blow-out: the minimum market distance forces HOLD. |
| ATC-X15 | Manager stops: the last verified stop is the reference and a staleness alert is raised. After an unreconciled send the alert states protection UNKNOWN. |
| ATC-X16 | A short signal from a long-only label is ineligible. |
| ATC-X17 | A missing feature makes the entry ineligible. |
| ATC-X18 | A point estimate above break-even with a lower bound below it is ineligible. |
| ATC-X19 | A stale calibration artifact is ineligible. |
| ATC-X20 | A drift flag caps the tier or makes the cell ineligible. |
| ATC-X21 | Base tiers are monotone with other conditions equal. No final stake exceeds the OD-05 cap, the margin limit or an exposure limit, and a higher band can still be denied by a gate. |
| ATC-X22 | Property test: confidence cannot change a take-profit, widen a stop or loosen a stop. |
| ATC-X23 | A raw score is never emitted under the label "probability". |

---

## 7. What Jon decides (listed once)

Each is a proposed direction, nonbinding until you select it. The author would carry the selected ones into the design through the controlled amendment process.

| # | Decision | Plain words | Alternative |
|---|---|---|---|
| J1 | Adopt this design as the proposed direction for trailing and confidence. | V2's rule becomes the floor. Improvements are tested against it and promoted only on evidence you approve. | Different direction, or defer. |
| J2 | Allow a controlled split of DEMO trades between V2's rule and a candidate. | Some demo trades use a new rule and others use V2's, assigned by a fixed rule decided in advance. It is the only way to test a rule that gives *more room* than V2's. The shares are yours to set. | Compute-only plus historical replay: slower evidence, no new rule on the account. |
| J3 | Eligibility uses the **lower bound** of the calibrated probability against the cost-adjusted break-even (a gate on the label; realised profit under trailing is checked separately, U1). | Stricter than V2. A trade is taken only if we are confident the edge is real, not just that the best guess looks fine. Fewer trades. | Use the point estimate: closer to V2, more trades, more of them uncertain. |
| J4 | Shorts are ineligible until a short-side label and calibration exist. | This is already D04-03's rule. V2 traded shorts as the complement of a long-side label. It cuts V2 activity until the evidence exists. | Not a free alternative. Allowing V2-style shorts in DEMO, labelled "uncalibrated" and at the lowest stake tier, contradicts U1, ATC-C04 and D04-03, and one selection here cannot activate it. It would be a separate proposed policy exception needing a controlled amendment, DEMO-only limits, stated risk evidence and negative tests. Until then, a short without short-side evidence is ineligible. |

---

## 8. Disclosures

- **What I read.** From V2's code: position_manager.py lines 1-120, 186-525 and 596-620 and 905-965; shadow_exit_lab.py lines 226-316; symbol_resolver.py lines 150-199; instrument_map.json for the flag. Source review rows SR-15, SR-17 to SR-20, SR-34 and IM-12 are from my earlier source review (hash `289d73fd…`). The D04, D03, EXT-G0R-14 and BB-05 anchors are those used in my review of the 14-decision pack.
- **What I did not read.** The adverse-exit policy file and whether it is enabled in production; the break-even and trail state machine beyond its header and constants (lines 1060-1225); governor.py's grade and tier computation (I rely on SR-19); V2's tier risk values; the ML training code; any V2 outcome data. A parity replay needs those.
- **No performance claim.** I have not shown that any candidate beats V2, or that V2's adaptive rule helped. Everything in 3.4 and 4 is a hypothesis with a test.
- **IG specifics not verified.** I did not rely on IG's native trailing stop, on guaranteed-stop modification rules, or on IG's modification limits. If the stop type chosen under OD-05 has restrictions on modification, they must be checked with IG evidence at G2 or G3 and may change ATC-T07, T08 and T09. Whether IG de-duplicates a repeated stop amendment is not verified and not assumed.
- **One expectation of mine was wrong and the checker caught it.** I expected the lowest score tier to need 15 evidence points. It needs 20. The text uses 20.
- **Corrections to my revision 2 review** are in section 1. Both make my earlier statements more accurate; neither changes a finding against the pack. I withdraw the optional addition to E1 ("and management parameters"). OD-01 already lists break-even and trailing activation as not dropped, so it is not needed, and it would change the pack's hash. Findings P-F1 and P-F2 are unchanged.
- **Governance.** I am the design owner of WDA-08 and cannot be its independent checker. This proposal is likewise mine, so it needs a reviewer who did not write it before anyone relies on it. Jon decides who.
- **Evidence.** `check_atc01.py` (11 checks, 0 failed, 27 V2 code anchors) and its output are delivered with this file. `verify_atc01_rev2.py` checks revision 2 against revision 1 and the cited sources.

---

## 9. Revision 2: what changed and why

The author's integration assessment (ATC-01 targeted integration assessment, 13 November 2026) raised nine items against revision 1 (SHA-256 `929c51b4…`). R2 accepts eight as exact edits and found the ninth already in the text. The core design is unchanged. None of the changes blocks the offline G0-R scope. All are needed before G3 operation.

| Item | Change in this revision | Where |
|---|---|---|
| ATC-I01 | Two outputs for the parity floor, and a register of four divergences. | 3.1(1), T04, T14, X04, X12, 3.6, section 1 |
| ATC-I02 | No retry. One wire attempt per modification intent. | 3.2(3), T07, X08, section 8 |
| ATC-I03 | No assumed one-step tolerance. Any mismatch is UNVERIFIED until a tolerance is approved. | 3.2(4), T08, X05 |
| ATC-I04 | N = 1 until set. Last verified stop is a reference, not proof of protection. | T09, T12, X07, X15 |
| ATC-I05 | Costs in the same units as TP and SL. Label gate is necessary, not sufficient. Pre-registered realised-R validation. | section 1, U1, 4.3, J3 |
| ATC-I06 | J4's alternative is a separate controlled exception, not a free choice. | J4 |
| ATC-I07 | Monotone applies to the base tier. Gates can reduce or deny the final stake. | U2, C06, X21 |
| ATC-I08 | The stop-modification permit is separate from the ledger edge. Preconditions re-checked at send. | 3.2(2), section 5 |
| ATC-I09 | No change. The text already has four candidates, and C2 and C4 are already marked as needing the split because compute-only cannot test them. | 3.4, 3.5 |

**Two errors of mine, found by this review.**
- ATC-T07 allowed a retry with the same key. The pinned master V1.8 allows at most one wire attempt per intent and denies retries (`NO_IMPLICIT_RETRY`, lines 212 and 316). My own interim suggestion to the owner kept a retry as well. Both are withdrawn.
- ATC-T04 said V2's "free" presence points are not awarded, while 3.1(1) said V2's rule is reproduced exactly. Both cannot hold. The floor keeps the points. Removing them is candidate C1.

**Two wording fixes of mine.** V2's adaptive rule was *evaluated* for every instrument, which is not the same as moving a stop on every instrument. And the optional addition to E1 is withdrawn.

**Still true.** All four decisions J1 to J4 are NOT_SELECTED. Every test is NOT_RUN. No numeric policy value is proposed. ATC-01 is authored by R2 and needs a reviewer who did not write it before anyone relies on it for G3. Jon decides who.
