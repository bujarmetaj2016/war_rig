# War Rig V3 — Stage D01: completed **draft** contracts, guarded ledger registry and freeze-readiness gaps

**Prepared:** 13 November 2026 · **Status:** `DESIGN_ONLY / AUTHOR_DRAFT_COMPLETE / OWNER_NOT_BINDING / EDGE_REGISTRY_NOT_ACTIVE / NO_G0_FREEZE / NO_G1_GRANT / NO_TIMER`  

**Source scope:** corrected V1.8 master, EXT-G0R-14 Annex G, WDA-08 §3.1–§7 and §10, BB-05 owner provisional acceptance. Source texts remain unchanged. All proposed MUST statements below are design-candidate requirements pending exact-fingerprint acceptance.

## 1. Completion verdict — do not confuse documentary registration with authority

- **Prepared:** 35 source **edge contracts**, plus seven newly proposed master intent/eligibility edge candidates with evidence guards, effects and negative oracles; four initial MARKET-only resting-entry exclusions; 59 unchanged source-negative graph cases plus 25 proposed master-axis negative cases; 3 proposed ledger event payloads; six clock schema candidates; an expanded set of proposed, unexecuted design test cases. All checks performed here are **schema/source consistency checks**, not implemented or executed system tests.

- **Not completed:** independently checked and formally accepted runtime registration; final owner policy/alternative choices; 43 owner substantive closures, 13 freeze findings, 21 repairs; release manifest, controlled freeze, G1 approval, proof on real IG or a deployed store. All 42 candidate edges retain effective `UNREGISTERED_NOT_ENABLED` and all 3 event names retain `BLOCKED_UNREGISTERED`.

- **Owner preference already recorded:** `I will accept all 14 B choices` on 13 November 2026 is a provisional response, **not** 14 binding contract decisions. BB-04 targeted R2 replay is evidenced by R2 on 13 November 2026 (44 checks, 0 failed); this changes no binding status.

## 2. B-01..B-07 missing specification clauses (new author drafts)

### B-01. Account, executable quote and instrument geometry — TYPES ONLY

`AccountIdentityEvidenceV1` is an immutable, source-bound tuple of `environment`, pseudonymous `account_scope_sha256`, `source`, `observed_utc`, `recorded_utc`, `observed_account_relation_evidence_ref`, `role_capability_class`, `evidence_digest` and `uncertainty`. A missing or mismatched account scope produces `UNKNOWN/deny`; it never falls back to another account or switches account via IG. G1 must have no credentials/proxy and therefore cannot populate a real broker identity.

`ExecutableQuoteEvidenceV1` records `instrument_definition_sha256`, `listing_sha256`, `bound_account_scope_hash`, `quote_source_id`, `source_clock_raw`, `observed_utc`, `recorded_utc`, `bid`, `ask`, `price_unit`, `quote_currency`, `basis` (`BID/ASK/UNKNOWN`), `executable_side` (`BUY/SELL/UNKNOWN`), `source_revision`, `evidence_ref`, `uncertainty`, `validity_policy_hash_or_UNSET`. Decimal price fields are fixed-format strings; do not assume price positivity. Bid/ask ordering and currency conversion need signed instrument geometry and validated same-scope evidence. No executable price, spread/slippage bound, mark, anchor, stop distance or post-fill loss value is inferred from offline fixture quotes.

`PostFillAdjustmentEvidenceV1` must distinguish pre-send estimate from broker-confirmed fill `deal_id`, `filled_quantity`, actual currency units, stop details, conversion evidence and risk-policy fingerprint, or produce `UNKNOWN`. The typed interface is not a G1 quote validator nor a G3 economic approval. This fills **draft text** for `OC-D03-02` and `OC-D04-02`, with the quote/anchor runtime still excluded.

### B-02. Source observation identity, run and expiry

A canonical `source_event_id` is derived (proposed SHA-256 identity rule) from canonical instrument/listing, source namespace, bar interval + source interval boundary in UTC, provider revision and raw completed-observation digest. Model, policy, build and inference-run hashes are **excluded** from the observation identity; they belong to `SourceRunV1` lineage (`source_run_id`, source_snapshot_sha256, model/policy/build hashes, received/observed times, completed-input proof, decision id). An observation bucket with contradictory bytes becomes a conflict requiring a new source revision and explicit provenance, never overwrite of the old event.

`SignalExpiryV1` records `source_run_id`, `source_event_id`, immutable eligibility timestamp and event-time basis, source validity/expiry policy id, observed completedness, last checked time and `VALID/EXPIRED/UNKNOWN`; no expiry interval or strategy time-to-live is chosen. Unknown completion, stale macro revision, model/side missing or clock error denies. Source-run and expired-signal event names are **draft only**, not in WDA-08 registered event catalogue; exact names/producer/stream require controlled follow-on registration.

### B-03. One transaction and gross UNKNOWN exposure

The **transaction boundary** is one fenced writer, one transactional store and one atomic commit containing (a) aggregate state + version append, (b) gross exposure reservation by account/instrument/intent/currency, (c) committed transition event in the V3 instrument stream, (d) correlated portfolio audit entry, and (e) the version’s `applied_event_id`. The independent watchdog store is outside that transaction. If any part cannot commit, nothing is represented as committed; a separately persisted restrictive latch is allowed, not a broker action.

`UNKNOWN` reservations represent **possible** exposure: hold the full unresolved claim rather than netting by a presumed hedge or a predicted rejection. If an operation may have left V3, a lost response is UNKNOWN, not a resend. An external manual/V2/orphan transaction is unattributed until a canonical V3 intent/account/deal/leg chain proves ownership. For partial fills/partial closes, update remaining quantity and reservation with exact decimal units and authoritative broker evidence. Partial close never stops protection observation. Releasing a claimed unit requires either (i) fresh broker evidence resolving that exact claim, or (ii) for an attempt that was never sent, positive audited local never-sent evidence for every linked attempt, with no possible-wire sibling and no contradictory broker fact (master V1.8 §3.3 attempt-abort and intent-release invariant); absence from a broker list is neither. A release happens only inside the same atomic commit as the transition that justifies it, exactly once. Owner choice E-4 on stale snapshots/late fills/conflicting evidence remains OPEN. Realised P&L requires authoritative close, cost, FX and transaction evidence and is never inferred from a local quote.

`DENY_NEW_ENTRY` is the provisionally preferred response spelling, with `NO_NEW_ENTRY`, `ENTRY_DENIED` and `DENY` as legacy documentary aliases. This does **not** rewrite source-agreed text or decide `OC-D03-05`; proposed additional safeguard is to **deny subminimum quantity without automatic uplift**, pending separate owner disposition.

### B-04. MARKET-only and role isolation

Under initial MARKET-only, V3 must have no working-entry order creation or manual V3 cancel/close/flatten endpoints. Edges `D03-SRC-007,010,012,013` are forbidden for V3-created entries. Foreign IG working orders may be observed later but are not converted into V3-owned rights. Broker-confirmed partial MARKET fills are not excluded. GBPUSD rejection strategy needing LIMIT entry is **ineligible at G3 under this strategy** unless separately resolved; never silently convert it to MARKET. All broker observations/mutations require new G2/G3 authorisations.

### B-05. Persistent entry Stop, not a monitoring Stop

An authenticated, durable local Stop prevents new entry admission across restarts, survives audit outage through an independent restrictive storage path, cannot be self-cleared and has no IG broker mutation side effect. Stop does not interrupt ongoing position/UNKNOWN supervision, reconciliation or incident logging when available. If its store cannot be read, start restrictive. Resume/reset identity, role and health-clearance checklist remain owner-OPEN. Missing or bad broker protection is an incident and a G3 protective-response question, **not** an implicit V3 power to act.

### B-06. WDA-08 supervision and six clock definitions

The WDA-08 §4 nine-part current-admission predicate `SUPERVISION_POSITIVE` is required, never sufficient; a stale, missing, signed-negative, wrong-account, wrong-roster, incomplete latest-due or untrusted-clock statement refuses. Pure fixture validator may be designed offline; no watchdog runtime or real delivery at G1. Future watchdog can *only* alert and request an entry breaker (if separately approved) and may never reset it, trade or assert breaker success without durable V3 evidence. Initial watchdog has no direct IG read, and independent failure-domain level, external witness and document-home decision remain open.

No second durable protective journal is proposed initially: if V3 audit is unwritable, **all automated IG broker actions are denied, including purported protective ones**, although a separate independently proven journal is a future owner alternative. The operator’s IG-platform manual intervention remains outside V3 and requires a later runbook. The six typed clock rows in `04_SIX_CLOCK_SCHEMA_DRAFT.json` retain D1/D2/D3/E1/E2/E3 and each open alternative, no numeric timer and no inferred pause. D2 explicitly depends on unselected A/B/C protective action and closed-market policy. E2 without proven delivery is `NOT_STARTED`, never PASS.

### B-07. Documentary repair proof

All 21 original repairs remain listed in the unchanged crosswalk; B-07 documentary repairs are source-backed closure tasks, not extra owner votes. A revision must state old/new interpretation, exact supporting source line, fingerprint and reviewer evidence. `R-01`/`R-21` need independent semantic review; performed code/crash/broker tests can only be claimed when actually executed under an authorised gate.

## 3. Stage D proposed registration: seven axes, 42 candidate edges and 3 ledger event types

**Seven axes:** the five Annex G axes `broker_operation`, `working_order`, `position`, `protection`, `realised_result`, plus the two independent axes that master V1.8 §3.3 defines as proposed and that EXT Annex C (ledger row) and WDA-08 §3.3 already require events for: `intent_lifecycle` (`∅`→`INTENT_ACTIVE`, `INTENT_ACTIVE`→`INTENT_CLOSED_NO_WIRE`, `INTENT_ACTIVE`→`INTENT_BROKER_OUTCOME_UNRESOLVED`, `INTENT_BROKER_OUTCOME_UNRESOLVED`→`INTENT_RESOLVED`) and `attempt_send_eligibility` (`∅`→`ELIGIBLE_NO_WIRE`, `ELIGIBLE_NO_WIRE`→`ABORTED_BEFORE_WIRE`, `ELIGIBLE_NO_WIRE`→`WIRE_ATTEMPTED`). These seven rows are candidate edges `D03-MST-036` to `D03-MST-042`, each with a guard, an effect, a positive and a negative oracle and tests; with their 25 denied pairs (16 intent, 9 eligibility) the graph is 122 pairs: 38 guarded, 84 deny (including the four excluded resting edges). Master rows for the manual Stop, automatic breaker, reset authorisation, supervision and alert axes are control or watchdog events (WDA-08 §3.3), not ledger transitions, and the protection-incident `ACTIVE`→`ARCHIVED` row is carried as a guard on `D03-SRC-018/019` (EXT Annex G, item 1); none of these is a ledger edge here. Where the master's proposed `ATTEMPTED/UNKNOWN`→`UNKNOWN` duplicate/conflict edge differs from CC1-NEG-018 (which denies `UNKNOWN`→`UNKNOWN`), CC1-NEG-018 stands: duplicate or conflicting evidence received while the operation is already UNKNOWN is recorded as evidence and an incident, not as a transition. This paragraph proposes a change to EXT Annex G ("five distinct state axes") and to the WDA-08 §3.1 closed list (ledger `axis`); both are pinned and unchanged here and need a controlled follow-on. The symbols and state pairs below are transcribed from EXT Annex G, unchanged. `∅` means no current V3-axis state, **not** proof of broker absence. A same-state edge is a real, versioned update, not a no-op; every edge requires a request, expected version, evidence and one atomic commit. A refused broker-observed transition never discards the observation: the refusal event keeps the evidence reference, and where the refused observation contradicts the current state the matching restrictive edge (D03-SRC-003, 016 or 025) is requested. A guard that depends on a timeout or freshness bound treats an UNSET, absent or non-evaluable bound as exceeded; this selects no number. These are **typed candidate contracts**, not an accepted runtime registry.

| ID | Axis | From → To | Proposed guard ID | Initial treatment |
|---|---|---|---|---|
| `D03-SRC-001` | `broker_operation` | `NOT_SENT` → `ATTEMPTED` | `BROKER_SEND_PRECOMMIT` | GUARDED · fixture-only |
| `D03-SRC-002` | `broker_operation` | `ATTEMPTED` → `BROKER_CONFIRMED` | `BROKER_CONFIRM_PROVEN` | GUARDED · fixture-only |
| `D03-SRC-003` | `broker_operation` | `ATTEMPTED` → `UNKNOWN` | `BROKER_OUTCOME_LOST` | GUARDED · fixture-only |
| `D03-SRC-004` | `broker_operation` | `UNKNOWN` → `BROKER_CONFIRMED` | `BROKER_UNKNOWN_RECONCILED_CONFIRM` | GUARDED · fixture-only |
| `D03-SRC-005` | `broker_operation` | `UNKNOWN` → `REJECTED` | `BROKER_UNKNOWN_RECONCILED_REJECT` | GUARDED · fixture-only |
| `D03-SRC-006` | `broker_operation` | `ATTEMPTED` → `REJECTED` | `BROKER_REJECT_PROVEN` | GUARDED · fixture-only |
| `D03-SRC-007` | `working_order` | `∅` → `WORKING` | `RESTING_ENTRY_EXCLUDED` | **EXCLUDED** V3 resting entry |
| `D03-SRC-008` | `working_order` | `∅` → `PARTIALLY_FILLED` | `MARKET_PARTIAL_FILL_INITIAL` | GUARDED · fixture-only |
| `D03-SRC-009` | `working_order` | `∅` → `FILLED` | `MARKET_FULL_FILL_INITIAL` | GUARDED · fixture-only |
| `D03-SRC-010` | `working_order` | `WORKING` → `PARTIALLY_FILLED` | `RESTING_ENTRY_EXCLUDED` | **EXCLUDED** V3 resting entry |
| `D03-SRC-011` | `working_order` | `PARTIALLY_FILLED` → `FILLED` | `PARTIAL_TO_FULL_FILL` | GUARDED · fixture-only |
| `D03-SRC-012` | `working_order` | `WORKING` → `FILLED` | `RESTING_ENTRY_EXCLUDED` | **EXCLUDED** V3 resting entry |
| `D03-SRC-013` | `working_order` | `WORKING` → `CANCELLED_PRE_FILL` | `RESTING_ENTRY_EXCLUDED` | **EXCLUDED** V3 resting entry |
| `D03-SRC-014` | `working_order` | `PARTIALLY_FILLED` → `REMAINDER_CANCELLED` | `REMAINDER_CANCEL_BROKER_PROVEN` | GUARDED · fixture-only |
| `D03-SRC-015` | `position` | `∅` → `OPEN_CONFIRMED` | `OWNED_POSITION_OPEN_PROVEN` | GUARDED · fixture-only |
| `D03-SRC-016` | `position` | `OPEN_CONFIRMED` → `BROKER_OUTCOME_UNKNOWN` | `POSITION_TRUTH_UNCERTAIN` | GUARDED · fixture-only |
| `D03-SRC-017` | `position` | `BROKER_OUTCOME_UNKNOWN` → `OPEN_CONFIRMED` | `POSITION_OPEN_RECONFIRMED` | GUARDED · fixture-only |
| `D03-SRC-018` | `position` | `OPEN_CONFIRMED` → `BROKER_CLOSED` | `FULL_CLOSE_PROVEN` | GUARDED · fixture-only |
| `D03-SRC-019` | `position` | `BROKER_OUTCOME_UNKNOWN` → `BROKER_CLOSED` | `UNKNOWN_FULL_CLOSE_PROVEN` | GUARDED · fixture-only |
| `D03-SRC-020` | `protection` | `∅` → `PROTECTION_UNVERIFIED` | `PROTECTION_FIRST_UNVERIFIED` | GUARDED · fixture-only |
| `D03-SRC-021` | `protection` | `∅` → `PROTECTION_VERIFIED` | `PROTECTION_FIRST_VERIFIED` | GUARDED · fixture-only |
| `D03-SRC-022` | `protection` | `∅` → `PROTECTION_DRIFT` | `PROTECTION_FIRST_DRIFT` | GUARDED · fixture-only |
| `D03-SRC-023` | `protection` | `PROTECTION_UNVERIFIED` → `PROTECTION_DRIFT` | `UNVERIFIED_DEFECT_PROVEN` | GUARDED · fixture-only |
| `D03-SRC-024` | `protection` | `PROTECTION_VERIFIED` → `PROTECTION_DRIFT` | `VERIFIED_DEFECT_PROVEN` | GUARDED · fixture-only |
| `D03-SRC-025` | `protection` | `PROTECTION_VERIFIED` → `PROTECTION_UNVERIFIED` | `VERIFIED_FRESHNESS_EXPIRED` | GUARDED · fixture-only |
| `D03-SRC-026` | `protection` | `PROTECTION_DRIFT` → `PROTECTION_UNVERIFIED` | `DRIFT_EVIDENCE_INCONCLUSIVE` | GUARDED · fixture-only |
| `D03-SRC-027` | `protection` | `PROTECTION_DRIFT` → `PROTECTION_VERIFIED` | `DRIFT_REMEDY_BROKER_PROVEN` | GUARDED · fixture-only |
| `D03-SRC-028` | `protection` | `PROTECTION_UNVERIFIED` → `PROTECTION_VERIFIED` | `UNVERIFIED_TO_VERIFIED` | GUARDED · fixture-only |
| `D03-SRC-029` | `realised_result` | `UNRESOLVED` → `RESOLVED` | `REALIZED_RESULT_RECONCILED` | GUARDED · fixture-only |
| `D03-ADD-030` | `broker_operation` | `∅` → `NOT_SENT` | `BROKER_OPERATION_DRAFT` | GUARDED · fixture-only |
| `D03-ADD-031` | `realised_result` | `∅` → `UNRESOLVED` | `REALIZED_RESULT_INITIAL` | GUARDED · fixture-only |
| `D03-ADD-032` | `working_order` | `PARTIALLY_FILLED` → `PARTIALLY_FILLED` | `PARTIAL_FILL_ADDITIONAL` | GUARDED · fixture-only |
| `D03-ADD-033` | `position` | `OPEN_CONFIRMED` → `OPEN_CONFIRMED` | `PARTIAL_CLOSE_STILL_OPEN` | GUARDED · fixture-only |
| `D03-ADD-034` | `protection` | `PROTECTION_VERIFIED` → `PROTECTION_VERIFIED` | `VERIFIED_PROTECTION_VERSION_UPDATE` | GUARDED · fixture-only |
| `D03-ADD-035` | `protection` | `PROTECTION_DRIFT` → `PROTECTION_DRIFT` | `DRIFT_PROTECTION_VERSION_UPDATE` | GUARDED · fixture-only |

Full per-edge evidence predicates, transactional effects and failures are in `01_EDGE_CONTRACTS_35_DRAFT.json`. Annex G is preserved as pinned source, not overwritten. The 59 other graph edges are preserved exactly from the historical negative complement (source hash recorded); see `02_NEGATIVE_GRAPH_COMPLEMENT_59_SOURCE_PRESERVED.json`. **The original five-axis 90-pair graph** remains source-preserved at 31 guarded and 59 denied (including the four resting-entry exclusions). The seven proposed master additions supply 7 guarded plus 25 denied pairs, giving **122 total = 38 guarded + 84 denied** across seven axes. This is a candidate documentary check, not a runtime proof or controlled source amendment.

### 3.1 Ledger event contracts — drafted, not registered

| Event | Scope/writer | Required predecessor | Effect / once-per |
|---|---|---|---|
| `LEDGER_TRANSITION_REQUESTED` | producer `fenced ledger transition producer` (Annex D); writer `The stream's writer` (WDA-08 §3.3); identities UNASSIGNED | Authenticated scoped request, or reconciliation observation accepted as local transition request | Durably records intent to apply a local transition; no ledger state or exposure release and no broker permit |
| `LEDGER_TRANSITION_COMMITTED` | producer `fenced ledger transition producer` (Annex D); writer `The stream's writer` (WDA-08 §3.3); identities UNASSIGNED | Linked durable REQUESTED event and evidence plus successful fenced expected-version compare | Exactly one transaction updates state, append-only version, reservation and V3 instrument + portfolio audit event, or all roll back |
| `LEDGER_TRANSITION_DENIED` | producer `fenced ledger transition producer` (Annex D); writer `The stream's writer` (WDA-08 §3.3); identities UNASSIGNED | Known request ID; validator failure, CAS losing writer or excluded edge; no COMMITTED evidence | Append denial if audit available; cannot change version or reservation; if audit unavailable local restrictive latch persists without fabricated event |

All three use the complete *proposed* WDA-08 event envelope and `WDA-CF-1` canonical hashing rules, one stream-sequencer per stream, no credentials in evidence, and a proposed type-specific payload digest. `REQUESTED` is **not** a broker-wire attempt. `COMMITTED` is the only event denoting an applied state transition and must match version-history `applied_event_id`; denials and requests never alter state. Candidate payloads and their deterministic SHA-256 schema digests are in `03_THREE_LEDGER_EVENTS_DRAFT.json`. The WDA `replay_sequence` alias remains dependent on controlled EXT amendment. **No circular hash references:** an event payload must not contain its own `event_hash`, an `EventRef` to itself, a digest of itself, or a postcommit stream-head hash that depends on itself; the ledger version stores the preassigned event ID and the verifier resolves it after commit. This is an author-proposed new invariant requiring independent review.

### 3.2 Crash/reconciliation admission rule

1. Persistent request record of identity, evidence, expected version and original gross claim. Pre-wire broker attempt and claim are durable **before** any future G3 send. 2. Fenced compare-and-set commits state, reservation, version and the two V3 audit streams together. 3. Losing CAS leaves **no** committed-transition event, optionally writes a separate denial; retries return identical committed result, never a second broker send. 4. On restart, check request→commit→version→reservation bijection and audit hashes. 5. Orphan state/event, multiple commit events per version or mismatched reservation => `LEDGER_AUDIT_DIVERGENCE_DETECTED`, incident and restrictive entry deny; no fabricated original event. 6. If audit store is unwritable, preserve restrictive local latch and refuse every automated broker mutation. The G1 proof is fixture-only; real store crash tests are later-gated.

### 3.3 Field-level registration acceptance prerequisites

For each edge: source ID/fingerprint; closed enum; actor and account scope; precise broker truth type; intent/attempt/deal/leg correlation; expected state/version and writer fencing; idempotency key; exact fixed-decimal quantity/currency/remaining exposure; source timestamp and credible uncertainty bracket; durability+audit effect; WDA enveloped event producer/writer/stream; positive and negative oracles; privacy validator; independent signed reviewer result; separately attributable owner acceptance against exact packet hashes. **Until all applicable prerequisites are satisfied the effective registry remains empty.** Four forbidden working-entry edges never become enabled under initial MARKET-only G3.

## 4. Verification and source authority

`06_DETERMINISTIC_TEST_PLAN_UNEXECUTED.json` provides **187 proposed unexecuted synthetic cases**: 38 guarded positives, 42 edge denials, 84 graph negatives (59 preserved + 25 proposed), 17 cross-contract negatives and six clock oracles. No implementation, broker call, real store crash, independent assessment or elapsed-time procedure is claimed. Existing G1R/V2CLS/V3EXT/WDA test IDs and owner decisions are unmodified.

### 4.1 Exact source pins verified before drafting

| Source | SHA-256 |
|---|---|
| Corrected V1.8 master | `dce9968ec3645cd03b786409c86eeb513826df9b6d14b340533973b7c08aafdd` |
| EXT-G0R-14 | `256ad6bd0d78f30e5e005f4fde64f13021d36286c8512640b2adf91a62153092` |
| WDA-08 | `01697219278154ac808cebdafc6575b93a5ea7ca9cbb2310331a5b30f78966c6` |
| BB-05 provisional response | `03106209b84783b0a27de4accc5997a9083f9eea208c95f9b89d63daa7d77d05` |
| 35-edge intake | `8e83b4db98ae3173e1fc4a600e6a0bc54f2a37905a8df9833977d77463377b20` |
| 3-ledger-event placeholders | `84bf1f0be66ca0af7b3c5f4633545e0331e662fef7c84a5f68de22bcfa5ed548` |
| Owner-43 crosswalk | `da66cdd8fd1927f1d359d4546e591b7b3916ffc57b135f96130b4525188d4b83` |
| Freeze-13 crosswalk | `eab726528dfc9ce28a3d33f221a50a995e6dc69208dde1724162e30bf1157992` |
| Repair-21 crosswalk | `14c0010cbb82de888a5a58ca6217297368d72cf6eb4342d01d5c9e23f4f2f28a` |

Additional source-negative complement SHA-256: `b5f0ed4bb540dc9255a85803197420735e196b927f7c92129cf86272c5e833bc`. The owner acceptance is source BB-05, not independent review.

## 5. Freeze gate checklist and status

| Gate/finding | Now | What would close it |
|---|---|---|
| 14 B choices | **Owner provisional** | Exact owner binding dispositions against reviewed fingerprint still required |
| 42 candidate edge guards | **42 guard/effect drafts / 0 enabled** (35 source + 7 master) | Exact reviewed guard+enum packet accepted, applicable negative oracles independently checked |
| 3 ledger event types | **3 design drafts / 0 registered** | Producer/writer+envelope+atomic effects independently reviewed, controlled D03/D06 approvals |
| Six clock schemas | **6 typed drafts / 0 operating values** | Agree or explicitly exclude the unsettled event alternatives for restricted freeze; no G3 operational timer |
| 43 owner questions | **0 binding closures** | Individually controlled or exactly enumerated deferred/excluded dispositions |
| 13 freeze findings | **13 open** | Each evidence-bound disposition / approved restricted exception |
| 21 repairs | **21 open** | Source/semantic independent review and recorded closure |
| Independent review | **Not complete** | R1 or controlled equivalent with proof of independence, defined scope, exact files |
| V3-GOV-48-01 | **Not adopted** | Separate governance source reconciliation, waiting requirement and formal acceptance |
| G0-R / G1 | **Not accepted / not authorised** | A separate fingerprinted owner action for each |

A freeze proposal must name its exact restricted module allowlist, extra unit `WD-OFF-01/02` exclusion/inclusion, G1 no-broker deny-egress proof, unselected risk/policy deferrals, authoritative WDA home, and R1 review/custody. It must not treat schema completion as an implementation test.

## 6. 14 owner-only decisions to resolve or explicitly defer (grouped)

These are **new recommended candidate directions**, not selections by the owner or R2. They can be addressed as a group with a separate substantive decision register; none changes the formal 43/13/21 immediately.

| ID | Issue | Candidate treatment until separately decided |
|---|---|---|
| `OD-01` | G0-R route and exact expanded/offline scope | R + C provisionally preferred; exact included modules / disabled policy list to be frozen by owner |
| `OD-02` | OC-D03-05: subminimum stakes | DENY_NEW_ENTRY; never automatically increase to broker minimum (not among 14) |
| `OD-03` | GBPUSD rejection strategy / MARKET-only incompatibility | DISABLE_GBPUSD_STRATEGY_G3 until distinct limit-entry change or independent market-compatible strategy approval |
| `OD-04` | US500 directional policy | DISABLE_PRODUCTION_DIRECTION until long-only owner policy chosen and independent evidence exists |
| `OD-05` | Stop type / monetary risk maximum / margin/size/FX | Keep all real values and real risk permission UNSET |
| `OD-06` | Unprotected position protective response A/B/C and closed market | V3 takes no protective action of its own (no automatic stop repair, close or cancel). If a position is found unprotected, V3 records an incident and tries to alert you; the only remedy is you acting by hand in IG's own platform, under a runbook that does not exist yet. If you cannot be reached, nothing acts until you can. Clocks D2 and E3 then measure your response time. Choosing protection A, B or C is still open and would need its own authority. |
| `OD-07` | Ledger evidence conflict U/X, late fills, stale snapshots | Unknown + gross held, no auto-retry or unproven release. This package holds per-edge evidence rules and one B-03 paragraph only; a full conflict-case policy (late fills after close, U/X, stale snapshots, release) is not yet drafted and stays owner-OPEN (E-4). |
| `OD-08` | Seven PARTIAL B-row contract/exclusion decision | Admit this package type-only schemas into restricted offline design subject to independent review |
| `OD-09` | WDA-08 §10 decisions 1, 3, 9 | Propose independent verified failure domain and WDA-08 canonical home; late cycles never retroactively count; level, authority and max freshness unset |
| `OD-10` | Clock alternatives D1..E3 and operational timing | Accept event definitions & negatives only in offline scope; defer operational A/B meanings/durations by exact exclusion |
| `OD-11` | Stop Resume, watchguard breaker reset authority | No automatic Resume or watchdog reset; future owner authenticated separate procedure |
| `OD-12` | Review/witness/custody and design-freeze hash control | Propose original R1 under separately evidenced appointment; standing K1/H13/independence requirements preserved |
| `OD-13` | G1-only cooling-off placement | Owner provisionally prefers pre-G1 only; V3-GOV-48-01 REV3 still pending |
| `OD-14` | Stage D ledger and three event type registration | Adopt only after independent checks and fingerprinted owner register acceptance. The document is a draft; independent review findings are open until fixed and replayed. |

Complete alternatives and missing acceptance evidence are in `07_OWNER_DECISIONS_FOR_CONTROLLED_DISPOSITION.json`. The following remain especially critical before **G3**: emergency/manual IG runbook, protective response A/B/C, stop type and finite risk bound, independent watchdog deployment, authenticated alert delivery/ACK, broker account identity, GBPUSD LIMIT incompatibility and US500 directional policy. These are not silently waived by a restricted G0-R freeze.

## 7. Effect, non-supersession, reviewer handoff

All sources above are read-only. This package supplies a **proposed, reviewable Stage D registration dossier** and technical clause candidates; it does not patch EXT, WDA or V1.8, does not create an effective register, and does not claim review or acceptance. Independent review must verify the edge guards, event schema, original source semantics (including external broker observations), clock alternatives, 90 graph pairs, 43/13/21 coverage and G1-R forbidden dependency boundary; only genuinely new content needs new technical review.

**Author-side test result:** static schema/manifest/provenance checks only. **Owner binding approval:** `OPEN`. **R1:** `NOT_APPOINTED`. **R2:** `NOT_REVIEWED_THIS_PACKAGE`. **G0-R:** `NOT_FROZEN`. **G1:** `NOT_AUTHORISED`. **IG/DEMO/LIVE:** `FORBIDDEN`. **48h timer:** `NOT_STARTED`.



## 7. Stage D02 controlled boundary — R2 D01-F1 through D01-F9 author revision

- Combined candidate state graph: **7 axes; 42 edge contracts** (35 pinned Annex G identities and seven NEW_MASTER_ROW_CANDIDATE edges); **38 guarded and four excluded resting-entry** edges; **84 denied state pairs** (59 preserved Annex G-derived negative pairs and 25 newly proposed master-axis negatives); **122 enumerated pairs**. All entries remain UNREGISTERED_NOT_ENABLED, runtime_enabled=false, and unsigned.
- This specification proposes the EXT-G0R-14 Annex G seven-axis amendment and WDA-08 §3.1 ledger axis enum extension; **neither pinned source is modified or accepted**. Controlled source incorporation remains a blocker to effective graph registration.
- Ledger events REQUESTED/COMMITTED/DENIED are payload-only proposals; their digests are derived from sorted-key UTF-8 compact JSON of payload_fields and do not confer producer, writer, review or runtime authority.
- Tests are synthetic fixture designs, not executed checks or coded implementations. Same-transaction multi-axis transitions and the single-writer CAS are proposed requirements; they have no deployed broker path.
- No R2 finding is declared closed by this author revision; the owner decisions OD-01 through OD-14 and all binding master questions remain OPEN pending distinct controlled disposition.
