# War Rig V3: Independent Watchdog and Audit Schema Contract

**Version:** WDA-08 (changes to the new text of WDA-06 and to stale references, for findings 2 and 8 of the independent re-check and the author's concurrency case), 12 November 2026.
**Status:** DESIGN_ONLY / PROPOSED / NONBINDING / NOT_FROZEN / NOT_AUTHORISED.
**Roles:** design owner R2, assigned by the owner-approver on 11 November 2026; reviewer the author; independent check R1. The owner-approver alone selects and approves. Reviewers check the design; as the author's annex notes, none of them stands in for an independent human signatory where one is required.
**Direct parent:** WDA-06, SHA-256 `7de7e6c1c54c3ad3fbd58338e211d4bc63447b5983807ec854a43d5407cdc29c`. A draft WDA-07 (`814266890845fd6949ddc57a4d471c971162a93ddbbb4c804ca47d25c7759755`) was issued earlier the same day, was never reviewed, and is withdrawn in favour of this version. Sections 13A and 13B list the changes made since WDA-05. WDA-05 (`8dc5f9be04985a3371452b8a71cd687dcc31febc9b20764f2377198b061bb9fd`) and WDA-04 (`a0b3100801598b64330a892949a6b9f3c71d41fd375ec4bc2ae947b9777444fc`) are earlier parents; section 13 lists the changes from WDA-04 to WDA-05. Apart from the header, the places named in section 13B and the new section 13B, this document is word for word WDA-06.
**Reviews answered:** (1) the author's technical review `Author_Review_R2_Watchdog_Audit_Proposal_20261111.md` (SHA-256 `bca8852d0d8a7df603b560ff51e7e3522d535632da23984ee9afeb27bc171969`, findings WD-A01 to WD-A13) and its integration annex `Watchdog_Audit_Integration_Annex_PROPOSED_20261111.md` (SHA-256 `d754f70d698b1acdb40fcbf9e5cc93c66e0031365a4dfb4a93f377bca152b41a`). The author reviewed the original proposal (`417c9970...`), not WDA-01. All thirteen findings are accepted. Section 14 says where each is answered. (2) The author's technical review of WDA-02, `War_Rig_V3_Author_Review_of_WDA_02_20261111.md` (SHA-256 `a1aacea17abd13bcc7bc21533696b9b56fd3265e8f3dce193b508bc89155e448`). Section 15 answers it. (3) The author's review of WDA-01, `War_Rig_V3_Author_Technical_Review_of_R2_WDA_01_20261111.md` (SHA-256 `e689d549a0d7b601ec005d81f6f717b365d907eaaa68446a37c060387c12822f`, findings `WDAREV-01` to `-12`). It has now been received, and section 17 answers it from its own text. (4) The author's review of WDA-03, `War_Rig_V3_Author_Review_of_WDA_03_20261111.md` (SHA-256 `3c91df85ab45e98343913affcbd5de0e087cc343d32ef35a432f7b1800039fcb`, findings `WD03-A01` to `-A08`). Section 18 answers it. (5) The author's acceptance review of WDA-04, `01_WDA04_AUTHOR_COMPREHENSIVE_REVIEW.md` (SHA-256 `a19c9c40e860842fbc2ee4d1be510241023be02f22ceca1ea4d96ff4a395ae2e`, findings `WDA04-F01` to `-F12`). Section 20 answers it. This version changes only what those findings require.
**What this is:** the proposed single home for the audit event schema, the health events, the six clocks' event definitions and the independent watchdog. It selects no option and no value, closes no owner question, and grants nothing.
**Precedence:** the corrected V1.8 master (`dce9968e...`) and the original owner records govern wherever this is silent or in conflict. Sections 4.4 and 4.5 of the extension contract EXT-G0R-05 (SHA-256 `202a100475cacd7da9eaa74241de42cec1c598fd94cf3b67b49616365bf7866d`), including its watchdog boundary paragraph (its line 282), cover some of the same ground. Until this document has been reviewed and the owner-approver says which text is the home, nothing here overrides the extension contract. The author's integration annex covers the same ground a third time. The author has asked that it is not retired yet, so it stays as source evidence, and section 16 shows where each part of it is carried here. The current extension contract is EXT-G0R-09 (SHA-256 `67ba2105e64b41b9c11dd9a2ce63e561f23ee3085f9f994c9d2dea5c18d42159`). It pins WDA-05, not this version (its lines 134, 142 and 297), and says that a conflict between the two documents stays an open conflict, not a merged approval (its line 297). Section 19 lists the differences, with EXT-G0R-09's line numbers. References elsewhere in this document to EXT-G0R-05 answer earlier reviews of that version and are history, not the current state. Neither document takes precedence over the other until the owner-approver selects. **Proposed lineage rule, for the owner-approver to select:** this document is the one home for the technical definitions of the audit record, the health events, supervision, alerts and the clocks' events; the extension contract points to one exact fingerprint of it and says only where its pure modules fit the offline build; V1.8 and the owner records keep precedence over both.
**Sources used:** the corrected V1.8 master (line numbers are the master's); R1's research text, section 7; the extension contracts EXT-G0R-03 (`0386ed87...`), EXT-G0R-04 (`4f5a850f...`) and EXT-G0R-05 (`202a1004...`); the two clock worksheets bundled with EXT-G0R-04 (`02_SEVEN_OWNER_CHOICE_WORKSHEET.md`, `04_UNSELECTED_PROTECTION_OPTIONS_AND_SIX_CLOCKS.md`); the V2 handover zips; the author's five reviews and the annex named above.

## 1. In plain words

V3 needs two things that V2 did not have in a trustworthy form.

- **An audit record that can be relied on.** Every decision, order, broker answer, protective action and failure is written down once, in order, and cannot be changed afterwards without the change being detectable. From it you can reconstruct why any trade happened or did not happen.
- **A watchdog that does not depend on V3 being healthy.** A separate program, on separate equipment, notices when V3 stops doing its work or when a safety deadline is missed, and makes sure a human hears about it. It never trades.

The two are one design because the watchdog works by reading the audit record. If V3 goes quiet, the missing records are the alarm. That only holds if the watchdog can tell "V3 did no work" apart from "I could not read V3's record". Section 4 names those states separately, and neither is ever treated as healthy. What the watchdog concludes is written to a record of its own, never into V3's (section 3.7).

One limit to be clear about: **the watchdog tells you; it does not rescue a position.** If V3 dies with a trade open, the defences are a stop the broker has confirmed it holds, and your own action. Even a confirmed stop can fill at a worse price than requested, and a stop that was only requested may not exist at all. So the exposure stays recorded as unresolved until the broker's own evidence settles it. The watchdog's job is to make sure you know quickly.

## 2. Principles

| # | Principle | Source |
|---|---|---|
| 1 | Absence is failure. The watchdog alarms on evidence that did not arrive, not on a message saying something is wrong. | R1 section 7.2 |
| 2 | No self-attestation. V3 saying it is healthy is not proof. | Master line 254: "cannot self-attest only" |
| 3 | Completed work, not signs of life. A heartbeat is sent only after a completed cycle is recorded, never on start-up. | R1 section 7.2 |
| 4 | Accepted is not delivered, and delivered is not acknowledged. | Master line 140 |
| 5 | If the audit record cannot be written, no new entry is allowed. | Master line 159; R1 section 7.4 |
| 6 | The watchdog can only make V3 safer. It can raise an alarm and ask for new entries to stop. It can never deal, and never clear a stop or a breaker. | Master line 253; test `G1R-05-B` |
| 7 | Keep every timestamp as received, next to the local time it was recorded. The state of the clock itself is an audited event. | R1 section 7.5 |
| 8 | No secrets in the audit record. | Master line 255 |
| 9 | An unknown outcome stays unknown. Neither the watchdog nor a dashboard may upgrade it. | Master, unknown-outcome rules (for example tests `G1R-03-B` and `G1R-03-C`) |
| 10 | No automated broker action without a durable record written first. An audit failure is a hard boundary for every automated broker action, protective ones included. | Clock worksheet `04`, line 12; the master's journal-before-wire rule (lines 140 and 207) |

## 3. Audit schema

The master asks for the audit event, identity and correlation schema to be fixed before the freeze, with retention and custody later (`OC-D06-07`, line 68). EXT-G0R-05 section 4.4 already lists the fields of one event. This section keeps those fields and adds what is missing: their types and checks, how events are grouped, the list of event types, who may write each, and the integrity rules.

### 3.1 Event envelope

EXT-G0R-05 section 4.4 lists 27 fields by name (its line 261). This section keeps all of them, adds the fields this design needs, and gives every field a type and a check, so that a validator can accept or reject any event whose type is registered (section 3.3) without judgement. An event type with no registry row is rejected. The types of the 27 inherited fields are my proposal: the extension contract names them but does not type them. The author has confirmed that all 27 names are present here and that these types are not yet accepted.

**Value types.**

| Type | Meaning |
|---|---|
| `Id` | An opaque identifier: 1 to 64 characters from `A-Z a-z 0-9 _ -`. Immutable once written |
| `Sha256` | 64 lowercase hexadecimal characters |
| `UtcTime` | A UTC time in RFC 3339 form ending in `Z`, with a fixed number of fractional digits set by the schema version (six proposed) |
| `Int` | A whole number. No floating-point number appears anywhere in hashed content; decimal quantities in payloads are fixed-format strings |
| `Enum` | One value from a closed, registered list. An unregistered value is rejected |
| `Text(n)` | UTF-8 text, normalised, at most n bytes, with no control characters |
| `EventRef` | A reference to another event that is unambiguous across both records: `record_id`, `stream_id`, `stream_sequence`, `event_id` and `event_hash`. All five must agree with the event found. The scope of a per-instrument stream is part of its `stream_id` |
| `Head` | The end of a stream at one moment: `stream_id`, `stream_sequence` and `event_hash` |
| `Watermark` | How far a reader had read: `heads` (a list of `Head`) and `read_at` (the reader's own `UtcTime`) |
| `Actor` | `kind` (an `Enum`) and `id` (an `Id`) |
| `Reason` | `code` (an `Enum`), with optional `text` (`Text(256)`) |
| `EvidencePointer` | A pointer to restricted evidence: `store_id`, `object_id`, `sha256`, `scope` and `access_class`. A bare address or an account number is never an evidence pointer |
| `UnresolvedEvidence` | A record that expected evidence was not found: `expected` (the `cycle_id` or other expected key), `record_id`, `stream_id`, `watermark` and `why` |

Size limits are part of the schema version. The figures below are proposed format limits, not operating thresholds, and are open to review.

**Fields.** "Inherited" means the field is in EXT-G0R-05 section 4.4.

| Field | Type | May be empty | Check |
|---|---|---|---|
| `schema_version` (inherited) | `Int`, 1 or more | No | A registered envelope version. An unknown one is rejected |
| `payload_schema` | `Enum` | No | The registered payload shape for this `event_type` at this version |
| `canonical_form` | `Enum` | No | Names the encoding and hash rules used (below) |
| `record_id` | `Enum`: `V3` or `WATCHDOG` | No | Which record the event belongs to (section 3.7) |
| `stream_id` | `Text(96)` | No | A registered stream kind, with a scope hash where the kind is per instrument and account. The kind must belong to `record_id` |
| `stream_sequence` | `Int`, 1 or more | No | Exactly the previous value plus one within the stream. The first event is 1 |
| `prior_event_hash` (inherited) | `Sha256` | No | Equals the `event_hash` of the previous event in the stream; 64 zeros for the first event |
| `event_hash` | `Sha256` | No | Recomputed by the verifier from the canonical form of every other envelope field |
| `event_id` (inherited) | `Id` | No | Unique in the record. The same identifier with identical content is a retry and is not written again; with different content it is rejected |
| `event_family`; `event_type` (inherited) | `Enum`; `Enum` | No | The type must be registered under that family (section 3.3) |
| `aggregate_id`, `intent_id`, `attempt_id`, `client_correlation_key`, `source_event_id` (inherited) | `Id` | By event type | Each event type's schema says which are required. An event missing a required one is rejected as uncorrelated |
| `instrument_definition_sha256`, `effective_policy_sha256`, `model_sha256`, `build_sha256`, `active_contract_listing_sha256`, `portfolio_context_sha256` (inherited) | `Sha256` | By event type | Each must name a registered artefact |
| `actor` (inherited) | `Actor` | No | A human, a component or an outside source |
| `actor_authority` (inherited) | `Enum` | No | A registered authority that this actor holds for this event type |
| `writer_identity` | `Id` | No | The authenticated service identity. It must be the one permitted writer of `stream_id` (section 3.7) |
| `account_scope` (inherited) | `Sha256` | Only on global streams | A scope hash, never an account number |
| `UTC_event_time` (inherited) | `UtcTime` | No | When the thing happened, by the writer's clock |
| `UTC_recorded_time` (inherited) | `UtcTime` | No | When the event was durably written. Order always follows `stream_sequence`; a recorded time earlier than the previous event's is kept and flagged as a clock anomaly |
| `source_time_raw`; `source_id` | `Text(64)`; `Id` | Both or neither | The outside source's timestamp exactly as received, and which source gave it. Never silently converted into the event time |
| `monotonic_ns`; `source_clock_id` | `Int`, 0 or more; `Id` | Both or neither | An elapsed-time counter and the clock that produced it. Compared only with values from the same `source_clock_id`, never across machines |
| `clock_sync_ref` | `EventRef` | Yes | Must point to a `CLOCK_SYNC_STATE` event in the same record |
| `cycle_id`; `cycle_attempt` | `Sha256`; `Int`, 1 or more | Both or neither | The expected-cycle key and the attempt number (section 4). Required on cycle and heartbeat events |
| `incident_id`; `unprotected_episode_id` | `Id`; `Id` | Yes | Link the events of one incident, and of one continuous period without verified protection, so that E3 can be measured across repairs, alerts and restarts. EXT-G0R-05 uses `unprotected_episode_id` in its clock events |
| `from_state`; `to_state` (inherited) | `Enum`; `Enum` | Both or neither | Must be a transition the V1.8 matrix allows for that aggregate |
| `reason` (inherited) | `Reason` | By event type | A registered reason code |
| `evidence_refs` (inherited) | A list of `EventRef`, `EvidencePointer` or `UnresolvedEvidence`, at most 32 (a proposed format limit) | Yes | Every `EventRef` must resolve to a committed, hash-verified event at the watermark the writer names. Absence is recorded as `UnresolvedEvidence`, never as an `EventRef`. Restricted evidence is pointed to, never embedded |
| `payload_digest` (inherited) | `Sha256` | No | The digest of the canonical payload |
| `uncertainty` (inherited) | `Enum` | No | A closed list defined with the extension contract. "Unknown" is a value, never an empty field |
| `redaction_class` | `Enum` | No | Must agree with the output validator's own result. The label alone is not proof that a payload is free of secrets |
| `replay_sequence` (inherited) | See "One counter" below | | |

**One counter.** `stream_sequence` is the single stored, hash-covered order within a stream. I propose that `replay_sequence` becomes another name for it and is not stored as a second counter. The author concurs as a proposal. The extension contract owns that field, so the change can only be made in a later version of it (section 19). A replay across several streams orders events in a fixed way: by checkpoint watermark first, then by the references between events, then by stream identifier and sequence. It never treats a clock time as if it were a single global order.

**Canonical form.** `canonical_form` names one registered set of encoding and hash rules. The first, `WDA-CF-1`, is:

1. The event is one JSON object in UTF-8, with member names in ascending order of Unicode code point and no white space between tokens. Nested objects follow the same rules.
2. Text is normalised to NFC. Only the quotation mark, the backslash and control characters below U+0020 are escaped, the last as `\u` and four lowercase hexadecimal digits.
3. Whole numbers are written in base ten with no leading zero, no plus sign and no exponent. Zero is `0`. There are no other numbers, and `true`, `false` and `null` never appear.
4. A field that is empty is left out. It is never written as null, as empty text, as an empty list or as an empty object.
5. Lists keep their order.
6. The hash is SHA-256 over those bytes, written as lowercase hexadecimal.

The event hash covers every envelope member except `event_hash` itself, and covers the payload through `payload_digest`, which is computed in the same way over the payload. A field made of several parts (`Actor`, `Reason`, `EventRef`, `Head`, `Watermark`, `EvidencePointer`, `UnresolvedEvidence`) is a nested object whose member names are the part names given with its type. These rules stand on their own; nothing here depends on RFC 8785.

**Input that is not canonical.** The writer normalises three things: the order of member names, white space, and text that is not yet in NFC. It rejects everything else before anything is appended:
- a member name that appears twice in one object;
- a number with a fraction, an exponent, a leading zero or a plus sign, and minus zero;
- `true`, `false` or `null`;
- an empty text, list or object;
- a lone surrogate, or bytes that are not valid UTF-8;
- a member that is not registered for the event type;
- an unknown `schema_version`, `payload_schema` or `canonical_form`;
- a reference that lacks any of its parts.

An event written under an unknown `canonical_form` cannot be replayed or signed as current. Section 21 gives test vectors with exact bytes and hashes. They are part of this contract's fingerprint.

**What each family must carry.** Beyond the fields that may never be empty, each event family requires some of the optional ones. Anything not listed is optional for that family. An event type's `payload_schema` may add requirements and may not remove any. The first seven rows cover events whose meaning V1.8 and the extension contract define; those rows are my proposal and are for the author to confirm.

| Family | Must carry | Must not carry |
|---|---|---|
| Decision | `source_event_id` and `aggregate_id`; the definition, policy, model and build fingerprints; `account_scope`; the cycle fields | States |
| Eligibility | As Decision, plus `portfolio_context_sha256`; `reason` on a denial | States |
| Ledger | `aggregate_id` and `intent_id`; `attempt_id` and `client_correlation_key` from the first attempt onward; the definition, policy and build fingerprints; `account_scope`; both states; `reason` on a denial or an unknown outcome | |
| Broker evidence | `aggregate_id`; `account_scope`; the outside time and its source; the listing fingerprint | States |
| Protection | `aggregate_id`; `account_scope`; `unprotected_episode_id` and `reason` on a defect; the outside time and its source where the evidence is the broker's | |
| Reconciliation | `aggregate_id`; `account_scope`; `reason` where unresolved | |
| Registry | `aggregate_id` for the item registered, and that item's fingerprint; both states on a change of state | Cycle fields; incident fields |
| Control, changes of state (`STOP_SET`, `BREAKER_TRIPPED`, and any reset or resume outcome that V1.8 defines) | Both states; `reason`; `evidence_refs` naming the persistent state that changed | |
| Control, requests and receipts (`RESUME_REQUESTED`, `BREAKER_RESET_REQUESTED`, `BREAKER_TRIP_REQUESTED`, `BREAKER_TRIP_REQUEST_RECEIVED`) | `reason` on a rejection; `source_event_id` where it answers an earlier event. The request identifier is in the payload | States |
| Health | The cycle fields on cycle, heartbeat and finding events; `build_sha256`; `reason` on any result other than complete | States |
| Alert | `incident_id`; `source_event_id` for the event that caused the alert; the outside time and its source on provider, handoff and delivery evidence | States |
| Incident | `incident_id`; `source_event_id`; both states | |
| Clock | `incident_id`; `source_event_id` for the trigger; `unprotected_episode_id` for D1, D2 and E3 | States |
| Integrity | `reason` on a gap, a break or a failed write | |

**Registries.** Every `Enum` is a registered list with a name and a version. Values are added, never renamed and never reused. `schema_version` fixes the version of every registry it relies on. A value that is not on its list is rejected.

| Registry | Values | Defined in |
|---|---|---|
| `record_id` | `V3`, `WATCHDOG` | 3.7 |
| Stream kinds | The ten in the stream table | 3.2 |
| `event_family`, `event_type` | The thirteen families and the registered types | 3.3 |
| `canonical_form` | `WDA-CF-1` | 3.1 |
| `Actor` `kind` | Human, component, outside source | 3.1 |
| `redaction_class` | Reference only; operational; restricted pointer | 3.3 |
| Cycle results | The eight results | 4 |
| Supervision checks | The nine checks of the admission test, by name | 4 |
| `mark_state` | Recovered, lost, none yet | 4 |
| Health `state` | Healthy, degraded, unavailable, unknown | 3.3 |
| Cycle `failure_code` | Input unavailable, calculation error, time budget exceeded, dependency unavailable, internal error | 3.3 |
| Send `failure_code` | Rejected by provider, unreachable, timed out, credentials refused, rate limited, internal error | 3.3 |
| `AUDIT_WRITE_FAILED` `failure_code` | Unknown schema, unregistered event type, wrong type, missing field, forbidden field, oversize, unregistered value, wrong producer, sequence conflict, hash mismatch, unresolved reference, redaction failure, duplicate member, invalid text, store unavailable | 3.1 |
| `UnresolvedEvidence` `why` | Not found at the watermark, feed unavailable, hash mismatch | 3.1 |
| Witness `kind` | Watchdog heartbeat missing, watchdog heartbeat resumed | 3.3 |
| Escalation `trigger` | Send failure, E1 limit, E2 limit | 7 |
| `incident_class` | Protection defect, supervision loss, audit failure, integrity finding, alert route failure, clock or data fault | 3.3 |
| Incident `change` | Evidence added, severity changed, scope changed | 3.3 |
| Integrity `finding` | Verified, gap, break | 3.3 |
| `correction_class` | Wrong value, wrong reference, duplicate record | 3.3 |
| Ledger divergence `reason` | State without event; event without state; version conflict; reservation conflict | 3.4 |
| Ledger `axis` | The five axes of EXT-G0R-09 Annex G (proposed, not selected) | EXT-G0R-09 Annex G |
| `observed_state` | The ledger-state values, a closed list that is not yet complete (see the ledger states row above) | 3.4 |
| Breaker request `action`; `outcome`; `reject_reason` | Trip; accepted, duplicate, rejected; bad signature, wrong target, expired, unknown schema | 5.7 |
| `time_quality` | Bounded, unbounded | 7 |
| Yes-or-no members (`reports_healthy`, `retrospective`) | Yes, no | 3.3 |
| Clock results | Pass, fail, unknown, not started, not applicable | EXT-G0R-05 section 4.5 |
| `actor_authority` | The 36 authorities of EXT-G0R-09 Annex D (proposed, not selected) | EXT-G0R-09 Annex D |
| `uncertainty` | As V1.8 and the extension contract define them | Those documents. Not yet listed anywhere as a closed list |
| Ledger states | The five axes and the 35 candidate transitions of EXT-G0R-09 Annex G (proposed; the ledger registry stays disabled) | EXT-G0R-09 Annex G. Not closed until the owner-approver closes `D03-FREEZE-06` |
| Alert `severity` and `route`, acknowledgement `method`, `access_class` | Not selected | Section 10, decisions 5 and 7 |

**References and absence.** The two records are not written together, and one may lag the other. A finding that says something good must rest on references that resolve to committed, hash-verified events at a watermark it names, with record, stream, sequence and hash all matching. A finding that evidence is missing, or could not be read, cites an `UnresolvedEvidence` record, never an `EventRef`. It is recorded as unknown, missed or feed unavailable, as the evidence allows, and it can never satisfy the admission test in section 4. When the missing event appears later, a new revision is written at the later watermark. The earlier one is not edited, and a breach already recorded is not erased. Nothing here assumes one clock order across the two records, or that both can be written in one step.

**Rejection.** An event that fails any check is not appended, and no substitute or corrected event is written in its place. Where the store allows, the failure is recorded as `AUDIT_WRITE_FAILED` with its reason. The action that needed the record does not proceed (section 3.4 rule 5).

### 3.2 Streams

EXT-G0R-05 has one `prior_event_hash` per event. I propose several chains instead of one, so that a fault in one instrument cannot stall another instrument's record (the isolation rule in EXT-G0R-05 section 4.3).

| Stream | Record | Holds |
|---|---|---|
| One per instrument and account scope | V3 | Decisions, checks, eligibility, and that instrument's intents, attempts and outcomes |
| Portfolio | V3 | Shared-ledger reservations, portfolio arbitration and its rejected contenders |
| Control | V3 | Stop, resume request, breaker trip and reset request, and the receipt of any watchdog request |
| Registry | V3 | Instrument definitions, state transitions, policy revisions, listings and rolls, manifest changes |
| Health | V3 | V3's own cycle and heartbeat events, data freshness, clock sync, storage, and its record of the supervision statements it has observed and tested |
| Alert and incident | V3 | Alerts and incidents that V3 itself raises, and their acknowledgements |
| Integrity | V3 | Checkpoints, verification results, gaps and breaks |
| Watchdog findings | Watchdog | Cycle findings, missed cycles, feed and clock findings, supervision statements issued, the watchdog's own heartbeats |
| Watchdog alert and incident | Watchdog | Alerts, escalations and incidents the watchdog raises, their acknowledgements, clock measurements, evidence imported from the outside witness, and any breaker request it sends |
| Watchdog integrity | Watchdog | Checkpoints of the watchdog's own streams, and the V3 stream heads it has seen |

The two records, and who may write to each, are set out in section 3.7.

**One writer per stream.** Each stream has one authoritative sequencer. Writing the sequence number, the event and the previous hash is a single transaction, or an equivalent fenced compare-and-set. A retried write is recognised by its event identifier and is not written twice. That applies to the audit write only; it is never a reason to send anything to the broker again. A forked head or a duplicated sequence number is rejected.

**A producer is not a writer.** A worker that runs a cycle submits its observation and appears as the event's `actor`. It holds no credential that can append to a stream. The stream's single writer authenticates the producer, appends the event with the next sequence number and hash, and appears as `writer_identity`. A producer's retry is recognised by `cycle_id`, `cycle_attempt`, `event_type` and the producer's `event_id`. The same key with a different payload is a conflict and is rejected; it is never a second completion. A submission that the writer has not appended has not been recorded, and the producer treats it so. The watchdog only reads V3's health stream; its own findings go through its own writer.

**Shared decisions stay in one place.** Portfolio admissions and exposure reservations are decided by one fenced portfolio ledger, never by instrument streams competing with each other. Events in different streams refer to each other by event identifier and head hash.

**Checkpoints.** A checkpoint event in the integrity stream records a consistent, watermarked set of stream heads. It does not make one instrument wait for another. A head that is missing, unavailable or inconsistent makes the dependent actions unknown, and they are refused.

**What isolation does and does not mean.** If one instrument's stream cannot be written, that instrument's dependent actions are refused. Another instrument may carry on only if its own stream and every shared safety prerequisite (the portfolio ledger, the control stream, account equity) are healthy. A shared failure refuses entries for every instrument that depends on it.

**What hash chains do not prove.** Someone who can rewrite a whole chain can also recompute its hashes. Detecting that needs checkpoints that are signed, witnessed or copied outside V3, which is later-gate work. The two records help each other here. The watchdog record keeps the V3 head hashes it has seen, and V3 keeps the watchdog head named in each supervision statement it accepts, so rewriting one record without the other shows. That is evidence across two failure domains. It is not custody.

The alternative to several streams is a single chain, which is simpler but makes every instrument wait on one writer. Whether the extra complexity is justified is a question for R1.

### 3.3 Event families and types

Names are proposals. The ledger transitions are defined by V1.8's state matrix and are only referenced here. Naming an event type never creates a lifecycle transition; every type must map to that matrix and to a stated writer. One vocabulary is used throughout. Names in the author's annex and reviews that differ are listed as aliases at the end of this section and are not additional events.

| Family | Event types |
|---|---|
| Decision | `DECISION_SNAPSHOT_FROZEN`, `CHECK_RESULT_RECORDED`, `DECISION_RECORDED` |
| Eligibility | `RISK_RESULT_RECORDED`, `ELIGIBILITY_ASSESSED`, `PORTFOLIO_ARBITRATION_RECORDED` |
| Ledger | Every intent, attempt and operation transition in the V1.8 matrix |
| Broker evidence | `OBSERVATION_RECORDED`, `CONFIRMATION_RECORDED`, `EVIDENCE_CONFLICT_RECORDED` |
| Protection | `PROTECTION_EVIDENCED`, `PROTECTION_DEFECT_CLASSIFIED`, `PROTECTIVE_RESPONSE_REQUESTED`, `PROTECTIVE_RESPONSE_OUTCOME_RECORDED` |
| Reconciliation | `RECONCILIATION_STARTED`, `RECONCILIATION_RESOLVED`, `RECONCILIATION_UNRESOLVED`, `CLOSE_PROVEN`, `PNL_RECONCILED` |
| Registry | `DEFINITION_REGISTERED`, `REGISTRY_STATE_CHANGED`, `POLICY_REVISION_REGISTERED`, `LISTING_REVISION_RECORDED`, `CONTRACT_ROLL_RECORDED`, `MANIFEST_CHANGED` |
| Control | `STOP_SET`, `RESUME_REQUESTED`, `BREAKER_TRIPPED`, `BREAKER_RESET_REQUESTED`, `BREAKER_TRIP_REQUESTED`, `BREAKER_TRIP_REQUEST_RECEIVED` |
| Health | `CYCLE_STARTED`, `CYCLE_COMPLETED`, `CYCLE_FAILED`, `HEARTBEAT_EMITTED`, `CYCLE_FINDING_RECORDED`, `CYCLE_MISSED`, `SUPERVISION_STATEMENT_ISSUED`, `SUPERVISION_STATEMENT_OBSERVED`, `SUPERVISION_PROOF_ACCEPTED`, `SUPERVISION_PROOF_REJECTED`, `SUPERVISION_PROOF_ABSENT`, `WATCHDOG_HEARTBEAT_EMITTED`, `WITNESS_EVIDENCE_IMPORTED`, `DATA_FRESHNESS_STATE`, `CLOCK_SYNC_STATE`, `STORAGE_STATE`, `DEPENDENCY_STATE` |
| Alert | `ALERT_GENERATED`, `ALERT_SEND_ATTEMPTED`, `ALERT_PROVIDER_ACCEPTED`, `ALERT_SEND_FAILED`, `ESCALATION_HANDOFF_EVIDENCED`, `ALERT_DELIVERY_EVIDENCED`, `ALERT_ACKNOWLEDGED`, `ALERT_ESCALATED` |
| Incident | `INCIDENT_OPENED`, `INCIDENT_UPDATED`, `INCIDENT_CLOSED` |
| Clock | `CLOCK_STARTED`, `CLOCK_STOPPED`, `CLOCK_BREACHED`, `CLOCK_RESULT_RECORDED` |
| Integrity | `CHECKPOINT_SEALED`, `CHAIN_VERIFIED`, `GAP_DETECTED`, `CHAIN_BREAK_DETECTED`, `AUDIT_WRITE_FAILED`, `CORRECTION_RECORDED`, `LEDGER_AUDIT_DIVERGENCE_DETECTED`, `CUSTODY_EXPORT_RECORDED` |

**Registered event types.** This is the single registry. An event type exists for a validator only if it has a row here. A type with no row, or with a row that conflicts with another, is invalid and is rejected; it is never given a guessed default. Before any event type is admitted into a fingerprinted offline manifest, its row must be complete and its payload schema must have an identifier and a hash.

Four things hold for every row and are not repeated in the table:
- The writer is the single sequencer of the stream. The "Producer" column says who submits the event and appears as `actor`.
- `schema_version` is 1. The payload schema identifier is `wda.`, the event type in lower case, and `.v1`. The hash of each payload schema is recorded when the registry is fingerprinted in an offline manifest. None exists yet.
- The envelope fields required for the family (section 3.1) apply as well.
- Payload members use the value types and registries in section 3.1. Any list in a payload has a fixed maximum length set with its schema.

Streams are abbreviated. V3-H, V3-A, V3-C and V3-I are V3's health, alert and incident, control and integrity streams. W-F, W-A and W-I are the watchdog's findings, alert and incident, and integrity streams. "Own" means the matching stream of whichever record the event belongs to. Redaction classes are R (reference only), O (operational) and P (restricted pointer). The "Oracle" column gives the tests in section 9 that exercise the row; `V3WDA-022` and `-053` apply to every row.

| Event | Family | Stream | Producer | Must follow | Once per | Payload | State change | Redaction | Oracle |
|---|---|---|---|---|---|---|---|---|---|
| `CYCLE_STARTED` | Health | V3-H | The cycle's worker | A roster row that yields this `cycle_id` | `cycle_id` and `cycle_attempt` | `roster_fingerprint` | No | R | 001, 023, 052 |
| `CYCLE_COMPLETED` | Health | V3-H | The cycle's worker | `CYCLE_STARTED` with the same key | The same key | `completion_rule_id`; `heads` (a list of `Head`) for the streams the cycle wrote to | No | R | 001, 052 |
| `CYCLE_FAILED` | Health | V3-H | The cycle's worker | `CYCLE_STARTED` with the same key | The same key | `failure_code` | No | R | 002 |
| `HEARTBEAT_EMITTED` | Health | V3-H | The manager | `CYCLE_COMPLETED` with the same key, durably written | The same key | `completed` (an `EventRef`); `head` (a `Head`) | No | R | 001 |
| `SUPERVISION_STATEMENT_OBSERVED` | Health | V3-H | V3's supervision check | Nothing | The watchdog identity, the target and `statement_sequence` | `watchdog_identity`, `target`, `statement_sequence`, `statement_digest`, `reports_healthy` | No | R | 036, 047 |
| `SUPERVISION_PROOF_ACCEPTED` | Health | V3-H | V3's supervision check | `SUPERVISION_STATEMENT_OBSERVED` for that statement | The admission check, named by `source_event_id` | `statement_sequence`, `statement_digest`, `checked_at`, `scope`, `heads_checked` (a list of `Head`) | No | R | 046 |
| `SUPERVISION_PROOF_REJECTED` | Health | V3-H | V3's supervision check | As accepted | As accepted | As accepted, plus `failed_check` | No | R | 034 to 039, 045, 048, 049 |
| `SUPERVISION_PROOF_ABSENT` | Health | V3-H | V3's supervision check | Nothing | The admission check | `checked_at`, `scope`, `mark_state` | No | R | 025, 037, 047 |
| `CYCLE_FINDING_RECORDED` | Health | W-F | The watchdog evaluator | The expected cycle falling due, or new evidence about it | `cycle_id` and `revision` | `revision`, `result`, `watermark`, `evidence` (an `EventRef` or an `UnresolvedEvidence`), `previous` (an `EventRef`) | No | R | 026, 040, 055 |
| `CYCLE_MISSED` | Health | W-F | The watchdog evaluator | The allowance running out with no completion | `cycle_id` | `watermark`; `unresolved` (an `UnresolvedEvidence`) | No | R | 002, 040 |
| `SUPERVISION_STATEMENT_ISSUED` | Health | W-F | The watchdog evaluator | A completed evaluation pass | `statement_sequence` | The statement fields in section 4 | No | R | 034 to 038 |
| `WATCHDOG_HEARTBEAT_EMITTED` | Health | W-F | The watchdog runtime | A completed evaluation pass | The pass | `pass_id`; `head` (a `Head`) | No | R | 019 |
| `WITNESS_EVIDENCE_IMPORTED` | Health | W-A | The watchdog runtime | Nothing | The witness's own reference | `witness_id`, `witness_reference`, `kind`, `pointer` (an `EvidencePointer`) | No | P | 019 |
| `DATA_FRESHNESS_STATE`, `CLOCK_SYNC_STATE`, `STORAGE_STATE`, `DEPENDENCY_STATE` | Health | Own: V3-H or W-F | The component that measures | Nothing | The change of state | `subject` (an `Id`), `state`, `measured` (`Text(64)`) | No | O | 012, 029 |
| `ALERT_GENERATED` | Alert | Own: V3-A or W-A | The side's alert component | An open incident | `alert_id` | `alert_id`, `severity`, `content_digest` | No | O | 009 |
| `ALERT_SEND_ATTEMPTED` | Alert | Own | The side's alert component | `ALERT_GENERATED` | `alert_id`, route and attempt number | `alert_id`, `route`, `attempt` | No | O | 010 |
| `ALERT_PROVIDER_ACCEPTED` | Alert | Own | The side's alert component | `ALERT_SEND_ATTEMPTED` | `alert_id`, route and the provider's reference | `alert_id`, `route`, `provider_reference` | No | P | 009 |
| `ALERT_SEND_FAILED` | Alert | Own | The side's alert component | `ALERT_SEND_ATTEMPTED` | `alert_id`, route and attempt number | `alert_id`, `route`, `attempt`, `failure_code` | No | O | 009 |
| `ESCALATION_HANDOFF_EVIDENCED` | Alert | W-A | The independent alert path | A failed or unconfirmed remedy, and the alert raised for it | `incident_id`, `alert_id` and route | `alert_id`, `route`, `recipient_ref`, `sender_identity`, `receiver_identity`, `request_id`, `result_id`, `receipt` (an `EvidencePointer`) | No | P | 028 |
| `ALERT_DELIVERY_EVIDENCED` | Alert | Own | The side's alert component | `ALERT_SEND_ATTEMPTED` | `alert_id` and route | `alert_id`, `route`, `receipt` (an `EvidencePointer`), `receipt_time`, `time_quality` | No | P | 009, 056 |
| `ALERT_ACKNOWLEDGED` | Alert | Own | The acknowledgement path | `ALERT_GENERATED`. Delivery evidence is not required first, so that an acknowledgement without it can be recorded as what it is | `alert_id`. Only the first authentic one counts | `alert_id`, `method`, `proof` (an `EvidencePointer`) | No | P | 020, 021 |
| `ALERT_ESCALATED` | Alert | W-A | The watchdog runtime | A send failure, or a limit passing with no authentic acknowledgement | `incident_id` and escalation step | `step`, `trigger`, `backup_route` | No | O | 027 |
| `INCIDENT_OPENED` | Incident | Own: V3-A or W-A | The side's detector | The event that revealed the condition | `incident_id` | `incident_class`, `severity` | Yes: none to open | O | 044 |
| `INCIDENT_UPDATED` | Incident | Own | The side's detector | `INCIDENT_OPENED` | `incident_id` and update number | `update_number`, `change` | No | O | 044 |
| `INCIDENT_CLOSED` | Incident | Own | The side's detector | Evidence that the condition has ended | `incident_id` | `closing_evidence` (an `EventRef`) | Yes: open to closed | O | 044 |
| `CLOCK_STARTED`, `CLOCK_STOPPED`, `CLOCK_BREACHED` | Clock | W-A | The watchdog evaluator | The event that caused it | The clock, the incident and that event | The clock fields of EXT-G0R-05 line 269 | No | R | 011, 012 |
| `CLOCK_RESULT_RECORDED` | Clock | W-A | The watchdog evaluator | A clock start, or evidence that the clock could not start | The clock, the incident and `revision` | The same clock fields with their result, plus `revision` and `retrospective` | No | R | 009, 044, 056 |
| `CHECKPOINT_SEALED` | Integrity | Own: V3-I or W-I | The record's checkpoint step | Nothing | The checkpoint number | `checkpoint_number`; `heads` and `other_record_heads` (lists of `Head`) | No | R | 005 |
| `CHAIN_VERIFIED`, `GAP_DETECTED`, `CHAIN_BREAK_DETECTED` | Integrity | Own | The verifier | A verification run | The run, and for a gap or break the stream and sequence | `run_id`, `stream_id`, `from_sequence`, `to_sequence`, `finding` | No | R | 004, 038 |
| `AUDIT_WRITE_FAILED` | Integrity | Own | The stream's writer | Nothing | The rejected submission's `event_id` | `rejected_event_id`, `failure_code`, `submitted_digest` | No | R | 007, 022 |
| `CORRECTION_RECORDED` | Integrity | The stream of the event corrected | The producer of the original | The original event | The original and a correction number | `original` (an `EventRef`), `correction_number`, `correction_class` | No | O | 004 |
| `LEDGER_AUDIT_DIVERGENCE_DETECTED` | Integrity | Own: V3-I | V3's recovery step | A recovery run at start-up | The aggregate and the observed version | `run_id`, `aggregate_id`, `axis`, `observed_state`, `observed_version`, `reason`, `watermark` (a `Watermark`); `expected_applied_event_id` (an `Id`), `evidence` (an `EvidencePointer`) and `unresolved` (an `UnresolvedEvidence`), each left out when it does not exist | No | R | 057, 058, 059 |
| `CUSTODY_EXPORT_RECORDED` | Integrity | Own | The custody export step | `CHECKPOINT_SEALED` | The checkpoint number and the custodian | `checkpoint_number`, `custodian_ref`, `receipt` (an `EvidencePointer`) | No | P | None offline. Later gate only |
| `BREAKER_TRIP_REQUESTED` | Control | W-A | The watchdog runtime | An open incident | `request_id` | `request_id`, `incident_id`, `target`, `action`, `issued_at`, `expires_at` | Never | R | 041, 050 |
| `BREAKER_TRIP_REQUEST_RECEIVED` | Control | V3-C | V3's control service | Nothing in V3's record. It names the request identifier | `request_id` | `request_id`, `outcome`, `reject_reason` | Never | R | 041, 050, 051 |

The breaker request rows exist only if the policy in section 5.7 is selected.

**Not registered here.** Events of the decision, eligibility, ledger, broker evidence, protection, reconciliation and registry families, and the control events `STOP_SET`, `RESUME_REQUESTED`, `BREAKER_TRIPPED` and `BREAKER_RESET_REQUESTED`, take their meaning from V1.8 and the extension contract. Their rows are the author's to supply. Until they exist, those event types are not registered and cannot be admitted to an offline manifest.

Four rules:
- No event may be submitted by a producer, or appended by a writer, other than the ones registered for it.
- Where the source of a health, storage or integrity fact cannot be seen, the event records unknown, never a pass.
- A request or a receipt never carries a change of state and proves none. Only `BREAKER_TRIPPED`, tied to the breaker's persistent state, shows that the breaker tripped.
- Family and stream are separate things. `BREAKER_TRIP_REQUESTED` is a control-family event registered to the watchdog's alert and incident stream only. No watchdog event of any family may appear in a V3 stream.

**Aliases.** These names appear in the author's annex and reviews. They are other names for the same things, not further events.

| Name used elsewhere | Name here |
|---|---|
| `HUMAN_ACKNOWLEDGED` | `ALERT_ACKNOWLEDGED` |
| `BACKUP_ESCALATED` | `ALERT_ESCALATED` |
| `GENERATED`, `SEND_ATTEMPTED`, `PROVIDER_ACCEPTED`, `DELIVERY_EVIDENCED`, `SEND_FAILED` | The same, with the `ALERT_` prefix |
| `MISSED`, `MISSING_CYCLE` | The result "missed". The event is `CYCLE_MISSED` |
| `AUDIT_FEED_UNKNOWN`, `FEED_UNAVAILABLE` | The result "feed unavailable" |
| `WATCHDOG_UNAVAILABLE` | Evidence from the outside witness, imported as `WITNESS_EVIDENCE_IMPORTED`. V3's own, narrower observation is `SUPERVISION_PROOF_ABSENT` |
| `E2_NOT_STARTED` | The clock result "not started" for E2 (section 7) |
| `WATCHDOG_SELF_UNOBSERVABLE` | The same fact as `WATCHDOG_UNAVAILABLE`: the watchdog cannot observe its own absence, so the outside witness reports it |
| `SUPERVISION_PROOF_ISSUED` (WDA-03) | `SUPERVISION_STATEMENT_ISSUED` |
| `CLOCK_UNKNOWN` (WDA-03) | `CLOCK_RESULT_RECORDED` with the result "unknown" |
| `SUPERVISION_POSITIVE` | The author's proposed name for the extension contract's admission check that uses the result of the test in section 4 |
| `DENY_NEW_ENTRY` | The admission decision's refusal, which belongs to the extension contract. Here it corresponds to a negative or absent result of that test |

### 3.4 Integrity rules

1. **Append only.** Events are never edited or deleted. A mistake is fixed by a `CORRECTION_RECORDED` event that points to the original.
2. **Chained.** Each event carries the SHA-256 of the previous event in its stream and the next sequence number. Hashes are computed over one fixed, versioned, canonical form of the event, and cover the stream identifier, the sequence number, the previous hash and the payload. An event with an unknown schema version is rejected.
3. **Sealed in batches.** Checkpoints close a batch. At a later gate, sealed batches are copied to custody outside V3 (section 3.6).
4. **Verifiable by replay.** A verifier reads the streams and checks hashes, sequence numbers, schema versions, that every referenced identifier exists, and that every state change is one the V1.8 matrix allows. Its result is itself an event.
5. **Write before acting.** An action that needs a record does not proceed until the record is durably written. If the record cannot be written, new entries are refused.
6. **An audit failure never opens a way round the record.**
   - New entries are refused.
   - A local stop or breaker may still move to its more restrictive state, through its own authenticated and persistent control path, with the failure and the recovery recorded. The more restrictive state must survive a restart while the audit store is still unavailable. The stop and breaker must not depend only on the device that holds the audit record, and if their own store cannot be read at start-up, V3 starts in the restrictive state. That is a local control, not a broker action.
   - No automated broker action of any kind proceeds without a durable record written first. That includes a protective close, a stop repair, a cancel and an emergency flatten. A second, alternate durable journal could meet this only if it were separately approved and proven: durability, the same identity recorded before sending, sequence, permissions, fencing, crash recovery, reconciliation, tamper tests, separate custody and no resend. Even then the action would still need verified account and position ownership, a single authorised writer and the G3 dealing grant. An intention to reduce risk is not a permit. None is proposed or selected here.
   - You can still act by hand on IG's own platform under a separately approved runbook. That is outside V3's automated authority, and nothing is recorded as closed until the broker's evidence is reconciled.
   - If the watchdog cannot read the record, its finding is "feed unavailable", never a pass.
7. **No secrets.** Credentials and tokens never appear. Accounts are referred to by a scope hash. Authenticated broker evidence is kept in restricted storage, and projections such as the dashboard are typed views that show only pseudonymous scope identifiers and references.
8. **A ledger transition, its event and the store.** This item applies to every change of ledger state that is not itself a broker send (a confirmation, a reconciliation result, a protection finding, a close).
   - **One transaction domain.** V3's ledger (state and version history), its exposure reservations and V3's own audit streams, instrument and portfolio, are written in one transactional store. A store that cannot commit all of them in one transaction is not admitted to the offline scope. An alternative that keeps two durable stores joined by an outbox or write-ahead log would need its own approval and a written proof that it gives every guarantee below. None is proposed. The watchdog's record is never part of the transaction. It reads a read-only copy (section 5.5), so lag in that copy gives `GAP_DETECTED` or an `UnresolvedEvidence` record, never a permission.
   - **Request.** The writer first records a typed transition request: a unique request identifier, the source evidence, the expected state and version, and the account and intent binding. A request is not a transition. It never conveys a permit, a confirmed broker outcome or a released reservation.
   - **Commit.** In one transaction the writer checks the expected state, version and authority, changes the state and the reservation, appends the committed-transition event with the request identifier, the transition identifier and the resulting version, and records that event's identifier as the new version's `applied_event_id` in the ledger's append-only version history. Everything commits or nothing does.
   - **A losing writer.** The transaction rolls back, including its committed-transition event. A denial event naming the request and the reason may then be appended. A crash before the denial leaves an unresolved request and no transition. A retry of a request that was committed returns the committed result and never makes a second transition. A losing writer is ordinary contention and blocks nothing.
   - **What readers accept.** Projections, the verifier and the watchdog accept as a state change only a committed-transition event whose identifier is in the version history. Requests and denials are never state changes. After the ledger has moved on, the version history, not the current version, shows that an earlier event was applied.
   - **Recovery on restart.** The recovery step checks the chain of requests, commits and denials against the version history and the reservations. A committed event with no state, a state with no committed event, two committed events for one version, or a reservation that does not match is a divergence. The recovery step then writes `LEDGER_AUDIT_DIVERGENCE_DETECTED`, which names no original event and never fabricates one. It also opens an incident of class integrity finding, holds the intent as unresolved, counts nothing as confirmed, released or closed on its strength, and refuses new entries. The hold ends only when an authenticated reconciliation or fresh evidence is recorded and applied through the commit rule above, and the incident is then closed with that as its closing evidence. If the divergence event cannot be written, the hold and the refusal stand and the local restrictive control stays latched (item 6).
   - **Corrections.** `CORRECTION_RECORDED` is for a real, existing event only.
   - **A broker send** follows item 5 and cannot share the local transaction. The attempt record and the exposure claim are committed before the request leaves. A crash after the request has left, and before any reply is recorded, leaves the outcome UNKNOWN with the claim kept. It is never read as rejected and never as confirmed, and nothing is sent a second time. A broker confirmation that was seen but not yet recorded is not a confirmation. It is re-established by reconciliation, and nothing is made up.
   This is a design rule only. It does not choose the store. The names of the request, committed-transition and denial events are proposals, and their rows are the author's to supply; until the rows exist they are not registered (section 3.3).

### 3.5 Completeness: the trade dossier

For every candidate and every trade, the record must contain a set of links that depends on how far it has got. A link that should exist and does not is shown; it never silently disappears.

| Stage | Required links |
|---|---|
| Rejected candidate | Frozen inputs; configuration, model and policy fingerprints; check results; the denial and its reason; portfolio context; the audit receipt |
| Intent recorded | The above, plus risk result, eligibility and the durable intent. No close proof is expected yet |
| Position open or outcome unknown | The above, plus broker outcome, ownership and quantity, protection status, and any uncertainty and reservation |
| Position closed with broker proof | The above, plus the broker's close evidence, quantities, reconciled cost and result, and the final signed links |

Each dossier has a status: in progress, complete, incomplete or unknown. It is judged against the links required for its stage and a stated evidence watermark. An open position is never shown as finished, and an unknown outcome is never dropped from results. Whether DEMO evidence may count only complete dossiers is an owner policy and is not selected here.

### 3.6 Retention and custody (later gates; the schema must already allow them)

- **Retention** periods are owner values and are not selected.
- **Custody** has two levels. A locked store in your own account is tamper-evident but is not independent custody; independence needs a separate custodian account (master line 663; R1 section 7.4). The unit that is exported is a sealed checkpoint batch. This applies to both records: the watchdog record needs custody outside the watchdog's failure domain as well as V3's.
- **Restore** from custody is proven at G3, not before.

### 3.7 Two records, and who may write to each

There are two append-only records, not one. The V3 record is written by V3. The watchdog record is written by the watchdog, in the watchdog's own failure domain (section 5.4). Both follow the envelope in 3.1 and the rules in 3.4. Neither writer holds a credential that can append to the other record.

| Who | V3 record | Watchdog record | Controls | Broker |
|---|---|---|---|---|
| V3's stream writers, one per stream | Append to their own stream only | Read the supervision statements only | As V1.8 defines | As the V1.8 gates allow |
| The watchdog runtime | Read a copy only | Append to its own streams only | Only the one-way breaker request, if selected at G3 (section 5.7) | None. Under option B (section 5.6) it reads through the read proxy and never holds a token |
| The outside witness | None | None | None | None |
| The verifier (`WD-OFF-02`) and the audit viewer | Read | Read | None | None |
| You | Read. You act through V1.8's authenticated controls | Read. You acknowledge alerts through the authenticated acknowledgement path | Stop, resume and breaker reset, as V1.8 defines | By hand, on IG's own platform |

Four consequences:
- A watchdog finding about V3 is an event in the watchdog record that points to V3 events by identifier and hash. It never becomes a row in V3's ledger, registry or streams. This is the writer boundary the author found missing in WDA-02.
- A single timeline of both records is a view built when reading. It is never written back.
- An alert and its acknowledgement live in the record of whichever side raised the alert.
- The outside witness is the authority on the watchdog's absence. Its evidence lives in its own service, which this design does not control. It is brought into the watchdog record afterwards as `WITNESS_EVIDENCE_IMPORTED`, with its source and raw times, and is never rewritten as if the watchdog had seen it.

Where the watchdog record is stored, and who administers it, are part of the failure-domain decision (section 10, decision 1). They are not selected here.

## 4. Health events and the supervision list

`OC-D06-01` asks for the "Manager/scheduler calendar and supervision population" (master line 518). I read that as a list of everything that must happen on schedule. I propose it as one owner-tier record, the **supervision roster**: signed, versioned and held independently by the watchdog, with one row per supervised cycle:

| Field | Meaning |
|---|---|
| `cycle_type` | For example: manager and scheduler tick, instrument evaluation, protection management, reconciliation, portfolio snapshot, audit checkpoint, clock-sync check, data-freshness check, watchdog self-check |
| `scope` | One instrument, or global |
| `expected_cadence` | Taken from the instrument's calendar rule and bar interval, or a fixed period |
| `grace` | How late is too late. UNSELECTED |
| `severity_if_missed` | UNSELECTED |
| `completion_semantics` | What counts as the cycle having completed |
| `mandatory_for` | Which new entries depend on this row: those of one instrument and account scope, or all of them. Such a row is a mandatory row in the admission test below |
| `calendar_ref` | The exact calendar this row is evaluated against: its identifier, version and hash, and the time-zone database version it was built with |
| `signer` and `source_hash` | Who signed this version of the roster, and the hash of what was signed. That hash is the roster fingerprint |

The important rule is **who works out what should have happened**. The watchdog holds its own copy of the signed supervision roster and the calendar, and computes the expected cycles itself. V3 only reports that a cycle started, completed or failed, and that report is an observation, not proof that the work was right. If V3 also announced what to expect, a stalled V3 would announce nothing and nothing would be missed.

The process being supervised cannot change the roster. A roster whose signature or version does not match is treated as unknown, and dependent actions are refused.

**Minimum duties (`WDA-MD-1`).** A roster is valid only if it has at least one mandatory row for each duty on this list: the manager and scheduler; reconciliation; the audit checkpoint; the alert route check; clock sync; data freshness; and, for every instrument and account scope that the registry shows as enabled, its evaluation and its protection monitoring. The list follows the author's review of WDA-01 and the extension contract's boundary paragraph (EXT-G0R-05 line 282). Duties you require can be added in a later version of the list. Check 5 of the admission test below enforces it.

**The expected-cycle key.** Every expected cycle has one identifier, `cycle_id`, that both sides can work out for themselves. It is the SHA-256 of the canonical form of six things:

1. the roster fingerprint;
2. the calendar hash, which fixes the market calendar version and the time-zone database version;
3. the cycle type;
4. the scope: an instrument and account scope hash, or global;
5. the scheduled occurrence: a bar identifier, or the scheduled start and end in UTC;
6. the identifier of the completion rule.

V3 quotes the `cycle_id` on its cycle and heartbeat events. The watchdog derives the same value from its own copies and matches on it. A `cycle_id` the watchdog did not derive is "unknown", never "complete". A second run of the same occurrence keeps the `cycle_id` and raises `cycle_attempt`. For a cycle that is triggered by an event and not by the calendar, item 5 is the identifier of the triggering event, and the watchdog expects the cycle from the moment it sees that event. A trigger that never reached the record cannot be expected, so every safety duty also needs a calendar-driven cycle.

**The calendar.** The calendar is a signed, versioned artefact: sessions and holidays for each instrument, and the time-zone database version it was built with. The master asks for the calendar's shape to be fixed with its numerical schedules disabled (`OC-D06-06`, line 64), and the offline calendar predicate is unit 06 (line 161). This document uses that calendar by reference and does not define it. If V3 and the watchdog hold different roster, calendar or time-zone database versions, the finding is "unknown" and dependent actions are refused.

**Time.** The watchdog decides whether a cycle is due from its own clock, and only while its own clock-sync evidence is current. Otherwise the finding is "clock untrusted". The allowances for lateness and for clock difference are values, and are unset. They are fields of the roster, so the roster fingerprint covers them.

**Findings.** The watchdog's finding for an expected cycle has one of eight results. Each occurrence has a due time; `grace` is the further allowance before it is declared missed.

| Result | Meaning | Final |
|---|---|---|
| Complete | A completion was recorded by the due time | Yes |
| Late | The due time has passed, no completion is recorded, and the allowance has not run out | No |
| Missed | The allowance has run out with no completion. `CYCLE_MISSED` is written | No. A completion may still arrive |
| Completed late | A completion was recorded after the due time | Yes |
| Failed | V3 reported that the cycle failed | No. A later attempt may complete |
| Feed unavailable | The watchdog could not read V3's record. That is a different fact from V3 having done no work | No |
| Clock untrusted | The watchdog's own clock evidence was not current | No |
| Unknown | Anything else, including a roster, calendar or key mismatch | No |

Only "complete" is healthy, and none of them grants any permission to trade.

A finding can change as evidence arrives, so findings are kept as **revisions** and are never overwritten. Each `CYCLE_FINDING_RECORDED` event carries the `cycle_id`, a revision number that rises by one, the result, and an evidence watermark: the V3 stream heads the watchdog had read, and its own evaluation time. Evaluating again at the same watermark writes nothing new. A different result at a later watermark writes the next revision. A `CYCLE_MISSED` event is never removed. If the cycle completes afterwards, the next revision says "completed late", never "complete", and points back to it.

The watchdog's own absence is not one of its findings, because it cannot report it. Two other observers can each say something narrower. The outside witness can say that the watchdog's expected heartbeat did not arrive; that is the authoritative statement. V3 can say only that it holds no statement, or none that passes the admission test below (`SUPERVISION_PROOF_ABSENT`, `SUPERVISION_PROOF_REJECTED`). That does not show the watchdog has failed: the cause could equally be the network, the feed or a signature. V3 never records more than that.

**The supervision statement, and when it proves supervision.** As I read the master, it already records that new entries are forbidden during supervision loss, and asks for supervision proof inside the admission decision, with its freshness and source and with fail-closed tests (`D06-FREEZE-02`, lines 87 and 546). The author agrees with that reading and adds that the finding stays open. WDA-03 let V3 accept any statement that was signed, in date and matched on roster and calendar. That was wrong: a correctly signed statement reporting a missed cycle would have passed. A signature shows who said something, not that what was said is good news.

*What the watchdog signs.* A supervision statement is issued after every evaluation pass, whatever it found. It carries:

| Field | Content |
|---|---|
| `statement_sequence` | The sequence number its issuance event will take in the watchdog findings stream |
| `prior_head` | The stream, sequence and hash of the last event committed to that stream before the issuance event |
| `previous_statement` | The sequence and digest of the statement before this one |
| `target` | The environment and account scope of the V3 it describes |
| `roster_fingerprint`, `calendar_hash` | What it was evaluated under |
| `evaluated_at`, `expires_at` | The watchdog's trusted time at evaluation, and the end of validity. The length of validity is a value and is unset |
| `watchdog_state` | Whether its read of V3's record and its own clock evidence were healthy for this pass |
| `rows` | For every mandatory roster row: the `cycle_id` of the latest occurrence whose due time had passed, its result, and either a reference to V3's `CYCLE_COMPLETED` event or, where there is none, an `UnresolvedEvidence` record |
| `v3_heads` | The V3 stream heads it had read |
| `signature` | Over the canonical form of all the fields above |

*No circular reference.* The statement names the head before its own issuance event, and the sequence that event will take. It never contains that event's hash. The issuance event, `SUPERVISION_STATEMENT_ISSUED`, is then appended with the statement as its payload, and its hash is computed afterwards in the ordinary way. A statement is released to V3 only after that event is durably written. One that was signed but not recorded before a restart is discarded and never released.

*The admission test.* For a new entry on a given instrument and account, supervision is proven only if every one of these holds at the moment of the admission check. If any fails, or cannot be worked out, the check fails closed and the failing item is recorded. The same statement may be used for more than one admission check while it remains current, and it is tested afresh each time.

1. **Authentic.** The signature verifies against the pinned watchdog key, and the schema is known.
2. **For this V3.** `target` is this environment and account scope.
3. **Same rules.** The roster fingerprint and calendar hash equal V3's own. Outside the offline fixture path, the roster must be the owner-signed one; a fixture roster can never produce a real admission.
4. **Not superseded.** V3 keeps a high-water mark for each watchdog identity, environment and account scope: the sequence and digest of the highest statement whose signature it has verified, whether that statement was good news or bad. The mark is written durably before the statement is used, and is recorded as `SUPERVISION_STATEMENT_OBSERVED`. A statement below the mark is stale and fails. The same sequence with a different digest fails and is reported as an integrity finding. The same sequence with the same digest is the same statement and may be used again. A newer statement raises the mark even when it reports a failure, and no earlier statement is usable after that.
5. **Valid roster.** V3 checks the roster itself, not only that two copies agree. Every duty in `WDA-MD-1` has a mandatory row. Every instrument and account scope that the registry shows as enabled has its own mandatory rows. Each mandatory row can be scheduled and has a completion rule. No row is duplicated or contradicts another. A roster that fails any of these is invalid, even when the watchdog holds the identical copy.
6. **Coverage at the moment of admission.** V3 works out for itself, from its own roster and calendar, the latest occurrence of every mandatory row, for this instrument and shared, whose due time has passed at the moment of the check. `rows` must contain each of those occurrences by its `cycle_id`. A statement evaluated before one of them fell due does not contain it and fails, however long it has left before `expires_at`. A mandatory row that has not yet had an occurrence attested, as after a new deployment or a newly enabled instrument, fails until one has. No start-up exception is defined.
7. **All complete.** Every one of those rows has the result "complete", and `watchdog_state` is healthy. Late, missed, completed late, failed, feed unavailable, clock untrusted and unknown all fail. No allowance is given for a cycle that is due and not complete.
8. **Real evidence.** Each completion event the statement points to exists in V3's record with that hash, and the `v3_heads` are heads V3 recognises.
9. **Fresh.** V3's own clock evidence is current, and the time is before `expires_at`. Being in date never makes up for a failure of any other check.

*After a restart.* V3 holds no statement and refuses entries until one arrives and passes. It recovers the high-water mark from its own durable record. If it cannot, the test fails closed and the loss is recorded as an integrity finding. A new mark can then be set only by a statement that was evaluated after the restart, by V3's own trusted clock with the stated skew allowance, and that passes every other check. A watchdog whose sequence has gone backwards stays rejected. Recovering from that is an owner-level action recorded as an incident.

*What the test hands on.* The result is positive, negative with the failing check, or absent. With it go the statement's sequence and digest, the moment of the check, the instrument and account scope, the roster fingerprint and calendar hash, and the V3 heads that were checked. V3 records this as `SUPERVISION_PROOF_ACCEPTED`, `SUPERVISION_PROOF_REJECTED` or `SUPERVISION_PROOF_ABSENT`, once for each admission check and before any intent. A positive result satisfies the supervision check and nothing else. It is one input to the admission decision and never a permit, and using a statement again is not a repeated intent. The test is a pure check on its inputs, so it can be exercised offline with fixture statements and fixture keys.

*What this costs.* Under check 6, entries are refused from the moment a mandatory cycle falls due until a statement that contains it arrives. If a shared mandatory cycle falls due at the same moment an instrument decides, that entry is refused. Due times are roster values and are yours. This design adds no rule for waiting.

*What is not settled here.* How long a statement stays valid, and whether "completed late" may ever count, are yours. With check 6 in place, a statement stops being usable at the next mandatory due time or at `expires_at`, whichever comes first. Signing keys, their custody and their rotation are later-gate matters. The admission decision itself belongs to the extension contract, which does not yet name a supervision check; the author has proposed one, `SUPERVISION_POSITIVE`, for a later version (section 19). The master's question about broker orders already resting when supervision is lost stays with `D06-FREEZE-02`; nothing here selects a cancellation.

A heartbeat carries the `cycle_id` it follows and the current head hash of the stream, and is valid only when the matching completion and that head hash are both durably recorded. The watchdog keeps these. That gives a second, outside record of what the audit chain looked like over time, at almost no cost.

## 5. The independent watchdog

### 5.1 What it does

| # | Responsibility | How |
|---|---|---|
| 1 | Notices cycles that did not complete | Compares expected cycles with `CYCLE_COMPLETED` events |
| 2 | Notices a damaged or stalled audit record | Checks sequence gaps, hash chains and checkpoint timing |
| 3 | Notices a missed safety deadline | Measures the six clocks from the recorded events (section 7) |
| 4 | Makes sure an alert reaches a human | Follows each alert to acknowledgement and escalates if it stalls (section 6) |
| 5 | Notices stale inputs | Data freshness, clock sync, storage; later the IG proxy and stream |
| 6 | Proves it is itself alive | Sends its own heartbeat to an outside witness, which alarms through its own channel if the watchdog goes quiet |

### 5.2 What it must never do

- Hold any dealing capability, the mutation gateway or dealing credentials.
- Clear a stop or a breaker, or write to any part of V3's record (section 3.7).
- Treat an unknown outcome as resolved.
- Own a general write interface to V3's ledger, or any broker token.
- Be the only route by which its own failure is reported.

### 5.3 Two parts

- **The evaluator.** A pure function: given a slice of the event record, the supervision roster, the calendar and the current time, it returns findings (section 4), incidents to open and clocks breached. It has no network, no credentials and no side effects, so it can be written and tested offline against synthetic event records. It works to explicit time budgets, so a calculation that never returns cannot hang it.
- **The runtime.** The separately deployed program that reads the event feed, runs the evaluator on a timer, sends alerts through its own channels and emits its own heartbeat. This is G3 work.

The master currently excludes the watchdog runtime from the offline slice and allows alert events as schema only (line 279). Following the author's review, two pure modules are proposed as separately listed candidates: `WD-OFF-01`, the expected-cycle evaluator, and `WD-OFF-02`, the audit-chain and checkpoint verifier. Neither is inside the eight original units or the twelve candidate extension units. Each needs its own place in a fingerprinted scope, with tests showing it has no network, no broker access and no notification code. They exist only if the owner-approver chooses a scope that includes them.

### 5.4 Failure domain

"Independent" has degrees. V2's watchdog was a script on the same host, alerting through one channel; the master lists that as a hazard (line 589).

| Level | Arrangement | What it still shares with V3 |
|---|---|---|
| 0 | Inside the V3 process | Everything. Not a watchdog |
| 1 | Separate process, same host | Host, disk, network, power |
| 2 | Separate host, same cloud account | Account administration, provider, possibly region |
| 3 | Separate account or provider | Little beyond the internet and IG |
| Plus | An outside dead-man's-switch service watching the watchdog | Little of V3's. It still depends on the internet, on its own provider and on reaching you |

Whatever level is chosen, the design should carry a written list of what the watchdog still shares with V3 (provider, region, network, DNS, time source, alert provider, recipient, administrator credentials, secrets, power). Each shared item is a known blind spot. The level is an owner choice under `OC-D06-01`.

### 5.5 How events reach the watchdog

The watchdog pulls events from a read-only copy of the audit record. It has no write access to V3. Everything it concludes is written to its own record (section 3.7). If it cannot read V3's copy, it records "feed unavailable" and alarms from its own durable evidence; it does not assume V3 is healthy. Separately, V3's heartbeats go to the watchdog and the watchdog's own heartbeats go to the outside witness.

### 5.6 Should the watchdog be able to see the broker?

| Option | What it can report when V3 is down | Cost |
|---|---|---|
| A. Evidence only | "V3 stopped at this time; these positions were open as last recorded" | None; no IG access |
| B. Independent broker read | The actual current positions and stops | A second reader through the read proxy at G2 or later, sharing IG's per-account request allowance with V3 |

Neither option lets the watchdog deal. This is an owner choice.

### 5.7 One-way controls

Two controls only ever make V3 more cautious. Neither runs before G3.
- **No supervision proof, no new entries.** WDA-02 offered this as an open policy. As I read the master, it is already on the project record: new entries are forbidden during supervision loss, and the proof belongs inside the admission decision (`D06-FREEZE-02`, lines 87 and 546). Section 4 defines the statement and the admission test. What remains yours is closing that finding and setting how long a statement stays valid. The author has since agreed with this reading, with the qualification that the finding stays open until its evidence, freshness, admission wiring and resting-order rules are complete.
- **Breaker request.** An owner-tier policy, not selected, and G3 only. If it is selected, this is the whole of it:
  1. The watchdog writes `BREAKER_TRIP_REQUESTED` to its alert and incident stream before it sends anything. The request carries a request identifier, the incident that caused it, the target environment and account scope, the single action "trip", the time issued, an expiry and a signature.
  2. V3 exposes one endpoint that accepts this one message and nothing else. It has no reset, resume, dealing or read function.
  3. V3 checks the signature against the pinned key, the target, the expiry, and whether it has seen the request identifier before.
  4. V3's control service writes `BREAKER_TRIP_REQUEST_RECEIVED` to V3's control stream, with the request identifier and the outcome: accepted, duplicate, or rejected with the reason. The watchdog never writes to that stream.
  5. If the request is accepted, V3 trips the breaker through its own breaker logic and writes `BREAKER_TRIPPED`, pointing to the received event. If the breaker is already tripped, nothing else changes. A duplicate returns the earlier outcome and changes nothing.
  6. Only you can reset the breaker, as V1.8 defines.
  7. The two records are reconciled by request identifier. A request with no receipt after its expiry, or a receipt with no matching request, is reported as an integrity finding.

**When V3's record cannot be written.** The breaker request is a separate, optional G3 capability. It is not the local stop or breaker of section 3.4, and an audit failure gives the watchdog nothing new. Neither side may claim that a request was accepted, or that the breaker tripped, without the durable evidence for it. The endpoint's reply is never that evidence. The watchdog treats a trip as shown only when it reads `BREAKER_TRIPPED`, pointing to the receipt of its own request, in V3's record. Until then it records the request as not proven and alerts through its own channel. It never sends the request as anything else, and never as a broker action.

| What fails | What V3 does | What the watchdog records |
|---|---|---|
| V3's control stream cannot be written when the request arrives | Writes no receipt and claims nothing. New entries are already refused by the audit failure (section 3.4). The local breaker may move to its restrictive state through its own persistent path | Not proven. It alerts |
| The receipt is written, then V3 fails before the breaker changes | On restart the breaker's own store decides. If that store cannot be read, V3 starts in the restrictive state | A receipt with no trip: not proven. It alerts |
| The breaker changes, then writing `BREAKER_TRIPPED` fails | The restrictive state persists. The event is appended once the store returns, marked as recorded late, with the recovery evidence | Not proven until it reads the late event |
| V3 restarts while its record is still unavailable | The restrictive state is kept | Not proven. It alerts |

None of these paths can reset the breaker, resume trading or send anything to IG. On replay the record keeps three things apart: the receipt of a request, the change of the breaker's persistent state, and the reconciliation after recovery.

## 6. Alerts

The master's alert sequence is: generated, then accepted by the provider, then either delivery separately evidenced or a direct authenticated human acknowledgement (line 140). An acceptance by the provider is neither delivery nor acknowledgement.

| State | Evidence required |
|---|---|
| Generated | The alert event, tied to an incident |
| Send attempted | The attempt, kept as an event. Not proof that anything was sent |
| Provider accepted | The provider's own acceptance record |
| Delivery evidenced | Independent evidence of receipt, not the provider's acceptance |
| Acknowledged | An authenticated human action quoting the alert's identifier; repeating it changes nothing (`G1R-04-D`) |
| Escalated | The backup channel's own generated and accepted records |
| Send failed | The error, kept as an event |

Design rules:
- **One incident, many alerts.** Alerts are grouped by incident so that a burst of failures does not flood the channel or hit provider rate limits (R1 section 7.3).
- **The backup channel is not V3's.** It belongs to the watchdog or the outside witness, uses a different provider and different credentials, and is used when a send on the primary fails, or when a limit passes with no authentic acknowledgement (section 7).
- **Acknowledged is not resolved.** An incident closes only on evidence that the condition has ended.
- **A sole operator.** With one person, the primary and backup recipients are the same human on different channels or devices. That is channel redundancy, not a second person, and the design should say so plainly. Two devices in one person's hands are not two independent responders. Whether to add a second human is an owner choice.
- **Message content.** Incident identifier, severity, scope, what was expected and what was seen, the time, a summary of last-known exposure, the action needed and how to acknowledge. No account numbers and no secrets.
- **Canary.** A periodic end-to-end test alert through every channel, proven at G3.
- **Nothing here is proven.** No provider behaviour, channel or recipient is verified by this document. Real end-to-end proof needs a separately authorised G3 test with a real recipient.

## 7. The six clocks

EXT-G0R-04 restored the six purposes the project already had on record, and EXT-G0R-05 keeps them. This table uses those purposes and names the events that start and stop each clock. Values stay UNSET. The meanings, and the open alternatives marked below, are an owner selection.

| Clock | Starts | Stops | Open for the owner-approver |
|---|---|---|---|
| D1 | For a trade never protected: the verified fill, or the earliest credible evidence of exposure. For protection lost later: somewhere inside a bracket that runs from the last verified-good observation to the first credible bad one | The first credible, durably recorded detection of the defect | How the bracket becomes a start time |
| D2 | The first credible detection | Broker proof that valid protection is in place, or that the remaining position is closed. A request sent, an API acceptance, a timeout or a missing position row does not stop it | Which protective response applies (protection A, B or C), and which broker evidence takes precedence |
| D3 | The first failed, rejected, timed-out or unconfirmed remedy | Alternative A: an authenticated handoff of the failed-remedy escalation to the independent alert path (`ESCALATION_HANDOFF_EVIDENCED`). Alternative B: evidenced delivery of it. `ALERT_GENERATED` and `ALERT_SEND_ATTEMPTED` are never enough | A or B |
| E1 | The first credible detection of the incident | Alternative A: evidenced delivery of the first owner-visible alert, and nothing else. Alternative B: that, or an authenticated acknowledgement | A or B (third point below) |
| E2 | The first evidenced delivery | A separately authenticated human acknowledgement. If delivery is never evidenced, E2 is "not started", which is not a pass | What happens when you cannot be reached |
| E3 | As D1 | Broker proof that protection is restored or the position is fully closed. It never resets on a restart, a repeated alert or a market close | The bracket convention; whether a closed market pauses it |

Proposed event bindings, using the names in section 3.3. Detection is `PROTECTION_DEFECT_CLASSIFIED`. An effective remedy is a `PROTECTIVE_RESPONSE_OUTCOME_RECORDED` backed by broker proof (`PROTECTION_EVIDENCED` or `CLOSE_PROVEN`); a failed or unconfirmed remedy is the same event without that proof. Delivery is `ALERT_DELIVERY_EVIDENCED`, acknowledgement is `ALERT_ACKNOWLEDGED`, and a handoff under D3 alternative A is `ESCALATION_HANDOFF_EVIDENCED`. Every start, stop and breach is itself written as a clock event that points to the event that caused it, and every result as `CLOCK_RESULT_RECORDED`. The payload of a clock event is the set of clock fields in EXT-G0R-05 section 4.5 (its line 269), including its five results: pass, fail, unknown, not started and not applicable. This document does not define a second set.

Seven points:
- **The start of D1 and E3 is a bracket, not a known moment.** When protection is lost after having been verified, the record holds two times: the last observation that proved protection, and the first that credibly showed it missing. The loss happened between them. The record keeps both, never presents the earlier one as the known time of loss, and never counts time that was proven protected. Which end of the bracket the clock uses is a convention for you to select. WDA-01 used the earlier end as if it were a rule; that is withdrawn.
- **D3's endpoint is open.** Both readings are kept and neither is selected. Under alternative A the stopping event is `ESCALATION_HANDOFF_EVIDENCED`: an authenticated receipt from the independent alert path for this particular escalation. It must carry the incident and alert identifiers, the route and recipient, the identities of sender and receiver, the request and result identifiers, and a trusted time. A provider's acceptance can count only if it is authenticated and tied to that escalation in this way. A generated alert, a send attempt, a queue write or an unverified provider reply cannot. This follows the author's answer and replaces my earlier suggestion.
- **E1 has two readings, and neither is selected.** Alternative A, in the worksheets, EXT-G0R-04 and the annex: only evidenced delivery stops E1. Alternative B, which is how EXT-G0R-05 now writes E1 (its line 276) and which the master's wording supports (line 140): an authenticated acknowledgement also stops it. Under B the acknowledgement must be bound to the alert and the incident and must not be a replay. E1 then stops at the acknowledgement's own time and is never backdated to a presumed delivery. It proves receipt, not when or by which route the alert arrived. E2 is recorded as not started, which is not a pass. The incident stays open either way.
- **If delivery is never evidenced, E2 does not start.** Provider acceptance never starts E2. What then happens to E1, the incident and the backup escalation depends on the alternative, and is set out case by case below. WDA-03 said here that the missing delivery always stays an open E1 incident; that was wrong under alternative B once an acknowledgement exists.
- **Three auxiliary measures.** Alert transport, backup escalation and manual action are recorded, carry no deadline, and never replace D3, E2 or E3. The time from provider acceptance to backup escalation is one of them.
- **One alert can satisfy D3 and E1 only if it proves both.** Nested intervals are never added together as if they ran one after the other.
- **The watchdog measures; V3 and the alert service stamp.** The component where an event happens writes it with its own time. The watchdog computes the intervals from the two records and writes the results to its own, using elapsed-time counters only within one clock and recorded times with a stated skew allowance across machines. Where the skew is not bounded, the result is unknown, not a pass.

**E1, E2, the incident and the backup escalation, case by case.** Where the two alternatives agree, the entry says "same".

| Case | E1 under A | E1 under B | E2 | Backup escalation |
|---|---|---|---|---|
| 1. Delivery evidenced, then acknowledged | Stops at the evidenced delivery | Same | Runs from the delivery to the acknowledgement | None, unless E2 passed its limit first |
| 2. Delivery evidenced, never acknowledged | Stops at the evidenced delivery | Same | Runs, and breaches at its limit | Starts when E2 passes its limit |
| 3. No delivery evidence, acknowledged | Does not stop, and breaches at its limit. The acknowledgement is kept as evidence of receipt | Stops at the acknowledgement's own time | Not started | None once the acknowledgement exists |
| 4. No delivery evidence, no acknowledgement | Runs, and breaches at its limit | Same | Not started | Starts on a send failure, or when E1 passes its limit |
| 5. Acknowledged only after E1 had breached | The breach stands. E1 does not stop | The breach stands. E1 stops at the acknowledgement's own time | Not started | Already running. Ends at the acknowledgement |
| 6. Delivery evidence arrives after the acknowledgement | A new, retrospective result: E1 stops at the delivery time, if that time is proven (below) | A new, retrospective result: E1 stops at the earlier of the proven delivery time and the acknowledgement | A new, retrospective result: it runs from the proven delivery time to the acknowledgement, if the delivery came first | None |

Four rules hold in every case:
- The incident stays open. Neither delivery nor an acknowledgement closes it; only evidence that the condition has ended does.
- An acknowledgement never changes or backdates a delivery time.
- Backup escalation is started by a send failure, or by a limit passing with no authentic acknowledgement. An authentic acknowledgement ends it under either alternative.
- A result already recorded is never overwritten. A later one is a new clock result that points to the evidence that changed it.

**Evidence that arrives late.** A delivery proof that arrives late carries several times, and they are kept apart: the provider's own timestamp as received and which provider gave it; the time the receipt was authenticated; the time it was recorded; and whether the difference between the clocks involved is bounded. An earlier delivery time may be used for a new result only when independent evidence proves when the delivery happened, within a bounded clock difference. That result is marked as retrospective. The breach or unknown result recorded at the time stays in the record and stays visible. Without such proof, the time the evidence was first recorded is used, or the interval is unknown. A breach is never turned into a pass after the event. Under neither alternative does provider acceptance start E2. This rule selects neither alternative.

## 8. What can be built offline, and what waits

| Piece | Offline build (G1-R) | G2 | G3 |
|---|---|---|---|
| Audit envelope, streams, event types | Schema and writer on synthetic events, within unit 04's authorised scope only | | Real broker evidence |
| Chain and checkpoint verifier (`WD-OFF-02`), gap and tamper tests | Pure, if admitted to scope | | Outside-witnessed checkpoints; restore from custody |
| Health events and heartbeat rule | Schema and emitters on synthetic cycles | | Real schedules |
| Supervision roster | Schema, with fixture rosters only | | Owner-signed roster |
| Watchdog evaluator (`WD-OFF-01`) | Pure, on synthetic records, if admitted to scope | | |
| Watchdog record and its writer | Schema and synthetic writer, if admitted to scope | | A real store in the watchdog's failure domain |
| Supervision statement and its admission test | Schema and a pure check, with fixture statements and fixture keys only | | Signed by the real watchdog |
| Breaker request | Schema only | | The endpoint, if the policy is selected |
| Watchdog runtime, separate host, outside witness | No | | Yes |
| Alert events | Schema only, no provider calls | | Real channels and canary |
| Broker read by the watchdog | No | Possible, if option B | |
| Custody export | No | | Yes |

## 9. Test oracles (design only; none executed)

The author's annex proposed eighteen identifiers in a new `V3WDA` namespace. They are adopted here with their numbers and meanings unchanged. The design owner proposed three more in WDA-02, twelve in WDA-03, eleven in WDA-04 and twelve here, for cases the author's reviews asked for. One earlier oracle, `V3WDA-036`, is revised here and says so in its row. None replaces an inherited test or a `V3EXT` test, and none is admitted to any scope by being listed.

| ID | Oracle |
|---|---|
| `V3WDA-001` | A heartbeat only after a durably completed cycle; one at start-up or without completion is rejected |
| `V3WDA-002` | The independent roster detects a missing cycle even when V3 reports itself healthy |
| `V3WDA-003` | A stalled Brent worker does not block Gold; a failure of shared state refuses entries for every dependent instrument |
| `V3WDA-004` | A duplicated or skipped sequence number and a broken hash are detected; replay rejects an altered previous hash |
| `V3WDA-005` | A whole history truncated and rehashed cannot be claimed intact without a trusted outside checkpoint; a later outside-witnessed checkpoint would detect the rollback |
| `V3WDA-006` | Portfolio admission and reservation stay atomically fenced while instrument streams append independently |
| `V3WDA-007` | An audit-write outage refuses new entries; no synthetic automated broker write and no false claim of a durable record |
| `V3WDA-008` | A stop or breaker moves only to a more restrictive local state under its approved control; it never clears itself or grants broker dealing |
| `V3WDA-009` | A provider-accepted alert with no delivery never becomes delivered or acknowledged; E2 stays not started and E1 stays unresolved |
| `V3WDA-010` | A failed remedy plus `ALERT_GENERATED` fails both D3 alternatives; the sent and delivered cases are separate oracles |
| `V3WDA-011` | An at-entry unprotected episode and a later ambiguous loss keep their uncertainty bounds; no zero-length D1 or E3 pass |
| `V3WDA-012` | Clock skew across machines gives unknown, not a pass; elapsed time within one clock domain is used only when justified |
| `V3WDA-013` | Out-of-order or duplicated provider and broker observations create no lifecycle transition and no duplicate acknowledgement |
| `V3WDA-014` | The audit viewer cannot reach stop, resume, dealing, the read proxy, outbound network or the V2 database |
| `V3WDA-015` | Dossier completeness follows the stage; an open position is not shown as finished; missing close evidence stays incomplete |
| `V3WDA-016` | A wrong-scope or unsigned supervision roster, or a fixture policy offered as live authority, is rejected |
| `V3WDA-017` | The roster cannot be changed by the process it supervises; a signature mismatch gives unknown and refuses |
| `V3WDA-018` | The offline import graph contains no watchdog transport, real broker observer, mutation gateway, notification SDK or credentials |
| `V3WDA-019` | Proposed by the design owner. The watchdog's own heartbeat is missing: the finding comes from the outside witness, never from the watchdog itself |
| `V3WDA-020` | Proposed by the design owner. A forged acknowledgement is rejected and recorded, and stops no clock; a repeated authentic one changes nothing |
| `V3WDA-021` | Proposed by the design owner. An alert acknowledged with no delivery evidence, run under both open readings of E1; the result stays open until one is selected, and E2 is never recorded as a pass |
| `V3WDA-022` | Envelope validation. A wrong type, an unregistered value, an empty required field, an oversize field or an unknown schema is rejected and nothing is appended; a repeated event identifier with different content is rejected |
| `V3WDA-023` | Expected-cycle key. V3 and the watchdog derive the same `cycle_id` from the same roster, calendar and occurrence; a different roster, calendar or time-zone database version gives unknown, never complete |
| `V3WDA-024` | Write boundary. The watchdog's identity cannot append to any V3 stream, and no V3 writer can append to the watchdog record; a watchdog finding points to V3 events by identifier and hash |
| `V3WDA-025` | With no valid, fresh supervision proof the admission check fails closed, and V3 records only that proof is absent, never that the watchdog failed |
| `V3WDA-026` | The watchdog's read path is down while V3 keeps completing cycles: the finding is feed unavailable, not missed, and the alarm is still raised |
| `V3WDA-027` | Delivery evidenced and never acknowledged: E2 starts and runs to breach, the backup escalation follows, and nothing is recorded as acknowledged |
| `V3WDA-028` | A generated or attempted alert, a queue write, or an unauthenticated or uncorrelated provider reply produces no `ESCALATION_HANDOFF_EVIDENCED` |
| `V3WDA-029` | With the audit store unavailable, a stop or breaker set to its more restrictive state survives a restart, and the failure and recovery are recorded once the store returns |
| `V3WDA-030` | A crash between a portfolio reservation and its record leaves both or neither; replay never shows an admission without its reservation |
| `V3WDA-031` | A projection or dossier view carries references only; an event whose payload fails the redaction validator is rejected whatever its label says |
| `V3WDA-032` | The same trade judged at two evidence watermarks is in progress and then complete; a closed trade with one required link missing is incomplete |
| `V3WDA-033` | Bracket boundaries for D1 and E3. Where the last verified-good and first credible-bad observations coincide, or no good observation exists, both bounds are still recorded; under either convention no interval is negative and no proven-protected time is counted |
| `V3WDA-034` | An authentic, in-date supervision statement that reports any mandatory row as other than complete is rejected, and the entry is refused |
| `V3WDA-035` | An otherwise valid statement that leaves out one mandatory instrument row, or one shared row, is rejected |
| `V3WDA-036` | Revised in WDA-05, because the earlier wording also rejected an equal sequence. A statement below the highest sequence V3 has observed is rejected, including an older healthy one presented after a newer unhealthy one; the same sequence with a different digest is rejected and reported as an integrity finding |
| `V3WDA-037` | Restart. A statement signed but not durably recorded before a watchdog restart is never released; V3 after a restart holds no statement and refuses entries until a fresh one passes |
| `V3WDA-038` | Crossed head. A statement whose `prior_head` is not the event before its issuance event, or a statement V3 accepted that has no matching issuance event, is reported by the verifier |
| `V3WDA-039` | With V3's own clock evidence not current, or after `expires_at`, the statement is rejected |
| `V3WDA-040` | A cycle found missed and later completed keeps both: the `CYCLE_MISSED` event stays, and a later revision says "completed late", never "complete"; evaluating again at the same watermark writes nothing |
| `V3WDA-041` | Breaker request. A duplicate trips once and is recorded as a duplicate; a forged, expired or wrong-scope request is rejected, recorded and trips nothing; a request without a receipt, or a receipt without a request, is reported |
| `V3WDA-042` | A reference that names the wrong record, stream or sequence for an existing event identifier is rejected |
| `V3WDA-043` | If the stop or breaker's own store cannot be read at start-up, V3 starts in the restrictive state |
| `V3WDA-044` | Each of the six cases in section 7, under each alternative, gives the E1, E2 and escalation states in the case table; the incident stays open, and an acknowledgement never backdates a delivery |
| `V3WDA-045` | Offline fixture. A healthy statement still in date is rejected once a mandatory occurrence it does not contain has fallen due, for the instrument's own row and for a shared row; a row that is mandatory only for another instrument does not affect this one; a later statement that contains the occurrence passes the supervision test and nothing more |
| `V3WDA-046` | Offline fixture. The same current statement is used for two separate admission checks; each is tested afresh and recorded separately, and neither is treated as a repeated intent |
| `V3WDA-047` | Offline fixture; real persistence at G3. After a restart with the high-water mark recovered, an older statement is still rejected. With the mark lost, the test fails closed until a statement evaluated after the restart passes. A watchdog sequence that has gone backwards stays rejected, and a statement for another account scope is rejected |
| `V3WDA-048` | Offline fixture. A signed roster that both sides hold identically, but that omits protection monitoring, the audit checkpoint or the manager and scheduler row, is invalid and the test fails |
| `V3WDA-049` | Offline fixture. A newly enabled instrument without its own mandatory rows, a duplicated cycle identity, and a mandatory row with no occurrence yet attested each fail the test |
| `V3WDA-050` | Offline fixture. A request or receipt event that carries a change of state is rejected; a rejected or duplicate request records no change of breaker state; only `BREAKER_TRIPPED` shows a trip |
| `V3WDA-051` | Offline fixture with a simulated store failure; G3 for the real endpoint. Each of the four failures in section 5.7 gives the stated outcome; a reply from the endpoint saying "tripped" is not treated as evidence; no path resets, resumes or sends anything to IG, and your own later action on IG's platform creates no V3 broker action |
| `V3WDA-052` | Offline fixture. Two workers submit to one stream at the same moment and each event gets one sequence number; the same key with a different payload is a conflict; a producer cannot append directly; a submission interrupted before the append leaves no event and is reported to the producer as not recorded |
| `V3WDA-053` | Offline fixture. An event type with no registry row, an unknown payload schema, an unregistered reason or value, the wrong producer, a malformed evidence pointer, a missing required payload member or a wrong redaction class is rejected |
| `V3WDA-054` | Offline fixture; a second, independently written encoder is still needed. The vectors in section 21 reproduce byte for byte, every input on the reject list is rejected, and an event under an unknown `canonical_form` is not replayed or signed as current |
| `V3WDA-055` | Offline fixture. A feed that lags and a cycle that is truly missed give different findings; a finding of absence cites an `UnresolvedEvidence` record, never a reference, and can never satisfy the admission test; a reference with the wrong stream or hash is rejected; an event that arrives later gives a new revision and the earlier one stays |
| `V3WDA-056` | Offline fixture. A late delivery proof with a proven earlier time gives a new result marked retrospective, and the earlier breach stays; with an unproven time, the recorded time is used or the interval is unknown; provider acceptance never starts E2 |
| `V3WDA-057` | Offline fixture. Two workers start from the same expected version: exactly one committed-transition event and one new version exist. The loser's transaction rolls back with its event, a denial is appended or, after a crash, an unresolved request remains, and no stream holds two committed events for one version. A retry of a committed request returns the same result. After the ledger has moved on, restart uses the version history to recognise an earlier event as applied and does not apply it again |
| `V3WDA-058` | Offline fixture. A crash before the request leaves no change and no send. A crash after the request and before the commit leaves a pending request, no transition, no permit and no release. A crash inside the commit leaves all of the state, the reservation, the committed event and the version history entry, or none of them. A crash after the commit and before the watchdog's copy catches up leaves the local record intact, and the lag in the copy gives a gap or an unresolved record, never a permission |
| `V3WDA-059` | Offline fixture. A state changed by hand with no event, a committed event with no state, two committed events for one version and a reservation that does not match each give `LEDGER_AUDIT_DIVERGENCE_DETECTED` with no original event named, an incident, an unresolved hold and refused entries. `CORRECTION_RECORDED` offered for them is rejected. With the stream unwritable the hold, the refusal and the latch still stand. A tampered event or a wrong previous hash is a chain break, not a recovery. A send whose request leaves and whose reply is lost ends as UNKNOWN with the claim kept and no second send, and a broker confirmation seen but not yet recorded is not made up |

**Stage labels.** Every oracle has an offline form on synthetic records and fixture keys, for whichever unit is admitted to scope. Passing that form proves the logic only. These also need a counterpart with real evidence at a later, separately authorised gate before they can be called proven: 005 (an outside-witnessed checkpoint), 017 and 024 (real permissions), 019 (the real outside witness), 020, 034 to 039 and 045 to 049 (real keys and real authentication), 029, 043, 047 and 051 (a real store failure and real persistence), 041 and 051 (the real endpoint), 054 (a second, independently written encoder), and 057 to 059 (a real store, with real crashes). Tests that need a custody seal, a third-party receipt or broker proof belong to that later gate as well.

## 10. Decisions that are yours

| # | Decision | Plain meaning |
|---|---|---|
| 1 | Failure-domain level (5.4) | How separate the watchdog's equipment is from V3's |
| 2 | Broker visibility (5.6) | Whether the watchdog can look at IG itself, or only at V3's record |
| 3 | Supervision proof for new entries (4; 5.7) | As I read the master, it already records that V3 opens no trade while supervision is lost (`D06-FREEZE-02`). Yours: closing that finding, how long a statement stays valid, and whether a cycle completed late may ever count |
| 4 | Automatic breaker request (5.7) | Whether the watchdog may block new entries without asking you |
| 5 | Channels and recipients (6) | Which alert routes, in which order, and whether a second person is involved |
| 6 | Clock meanings (7) | What each of the six deadlines measures. This includes whether D3 ends when the escalation is sent or when it is delivered, how the bracket for D1 and E3 becomes a start time, whether an acknowledgement stops E1 (alternative A or B), and whether a closed market pauses E3 |
| 7 | Custody (3.6) | Your own locked store, or a separate custodian |
| 8 | Alternate durable journal (3.4) | Whether to commission a second, separately proven journal so that automated protective actions could continue during an audit failure. The default is none |
| 9 | Home of this text (header) | Whether this document is the one home for the audit, supervision, alert and clock definitions, with the extension contract pointing to one exact fingerprint of it |

Grace periods, thresholds, severities, clock values and retention periods are also yours, but belong to later gates and are deliberately left unset.

## 11. What I have not verified

- The original D06 wording behind `OC-D06-01`, `-02`, `-03` and `-07`. I used the master's summaries of them.
- Every statement about an outside service (the dead-man's-switch service, the alert provider's behaviour and limits, the locked storage). These are R1's reported findings; I did not check them.
- Whether `WD-OFF-01` and `WD-OFF-02` fit the scope the owner-approver chooses.
- The original D03 and D06 submissions that the author's review refers to. I relied on the clock worksheet and the master.
- EXT-G0R-05 as a whole. I have read the parts this document depends on (sections 2.2 and 4.3 to 4.5, and the Annex B rows for this workstream). I have not reviewed the contract.
- The types of the 27 inherited envelope fields, and the family profiles for the seven families that V1.8 and the extension contract define. They are my proposal.
- That the encoding rules in 3.1 are complete enough for two independent implementations to agree. I computed the vectors in section 21 once, with two short encoders of my own that agree with each other. That is not an independent check, and nothing has been implemented.
- The registry rows for the seven families and four control events that V1.8 and the extension contract define. They do not exist yet.
- That this document is complete. The author has reviewed the original proposal, WDA-01, WDA-02 and WDA-03, not this version. R1 has reviewed nothing in this line.

## 12. What I ask the reviewers to check

1. Every cited master line says what this document says it says.
2. Section 3.2: several chains with checkpoints, against one chain. Is the extra complexity justified by instrument isolation?
3. Section 3.3: are any event types missing for the V1.8 ledger, the registry or the roll events in EXT-G0R-05? Are any redundant?
4. Section 3.4 rule 6: does the rewritten rule now match the original D03 and D06 clauses on writing a record before any automated broker action?
5. Section 4: can the watchdog really compute expected cycles from the supervision roster and calendar alone, for every cycle type?
6. Section 5.3: are `WD-OFF-01` and `WD-OFF-02` truly free of side effects, so that they could be admitted to the offline scope?
7. Section 7: does the clock table agree with EXT-G0R-05 section 4.5, the two worksheets and the author's annex? Are the two E1 alternatives fairly put, and is the case table right under each?
8. Does anything here select a value, a channel, a threshold or an option? Nothing should.
9. Which text should be the home: this document, with the extension contract pointing to it, or the reverse.
10. For the author: do sections 17 and 18 answer the two reviews as intended, and is section 19 a complete list of the differences from EXT-G0R-05?
11. Section 3.1: is each type, check, family profile and encoding rule right?
12. Section 3.7: does the two-record split cover every writer, and can any identity still write where it should not?
13. Section 4: is the expected-cycle key complete, and can both sides always derive it? Is my reading of `D06-FREEZE-02` right?
14. Section 4: can any signed statement that ought to fail the admission test pass it? Section 5.7: can the breaker request do anything other than trip?
15. Section 3.3: is any registered row, payload member or closed list wrong or missing? Section 21: do the vectors reproduce with an encoder you wrote yourself?

## 13. Changes from WDA-04

Every change answers a finding in the author's acceptance review. The finding is named in brackets.

- Header: version, direct parent, the fifth review answered.
- Section 3.1: six value types added (F08, F10); references and absence (F10); encoding rules completed and the handling of non-canonical input stated (F09); the control family split into changes of state and requests (F05); the registries given as closed lists (F08).
- Section 3.2: a producer is not a writer (F07); three stream rows worded to match.
- Section 3.3: the three catalogue tables are replaced by one registry of 41 event types with their payload members (F07, F08); `SUPERVISION_STATEMENT_OBSERVED` added (F02); four rules in place of two (F05); two aliases added (F03).
- Section 4: the minimum-duty list named `WDA-MD-1` (F04); the admission test now has nine checks, with a durable high-water mark (F02), a check of the roster itself (F04) and coverage at the moment of admission (F01); a restart rule (F02); what the test hands to the admission decision (F03); what check 6 costs (F01).
- Section 5.7: four failure cases when V3's record cannot be written (F06).
- Section 7: case 6 and a rule for evidence that arrives late (F11).
- Section 9: `V3WDA-036` revised (F02); twelve oracles added, `V3WDA-045` to `-056`, each with its stage; stage labels updated.
- Sections 11 and 12: updated.
- Section 18: one number updated. Section 19: two cells updated and a mapping of clock oracles added (F12).
- Sections 20 and 21 are new.

## 13A. Change from WDA-05 (WDA-06)

One finding, from an independent review forwarded on 12 November 2026 as the owner-approver's input, with no reviewer label and no document hashes. I take it as `R1-F2`.

- **Finding.** A crash between a ledger state change and its audit event can leave a state with no evidence, or an event with no state. The finding blames section 3.2's statement that the two records may lag. That statement is about V3's record and the watchdog's record, not about the ledger and V3's own stream, so the reason given is not right. The gap is real all the same. Item 5 of section 3.4 covers actions that need a record before they proceed, and `V3WDA-030` covers a reservation and its record. Nothing fixed the order of a state change that is not a send, or what recovery does after a crash between the two writes.
- **Change.** Section 3.4, new item 8. Section 9, new oracles `V3WDA-057` to `-059`, with their stage in the stage labels. Section 3.1, table of closed lists: the row for `actor_authority`, `uncertainty` and ledger states is split in three, because EXT-G0R-09 now supplies Annex D and Annex G.
- **Not changed.** No other section. The six unaffected findings of that review are answered in my owner response and need no change here. Section 19 still compares with EXT-G0R-05 and is stale; it is updated at the next change that has another reason.

## 13B. Change from WDA-06 (WDA-08)

Three findings: two from the independent re-check of 12 November 2026, as the owner-approver forwarded it, and one concurrency case from the author's assessment of WDA-06. All three are defects in the text I added in WDA-06 or in stale references. A draft WDA-07 answered the first two, was never reviewed, and is withdrawn. This version replaces it and adopts the author's single-transaction recommendation.

- **Finding 2, part one, and the author's case.** WDA-06 said a change whose event was not applied is applied once if the prior version still holds, and otherwise reported. It could not tell "applied, then the ledger moved on" from "never applied". The author's case is worse: two workers both see version 7, both events are appended before either compare-and-set, one wins, and the stream holds two events that look like committed transitions. **Change:** section 3.4 item 8 is rewritten. One transaction domain; a typed request that is not a transition; one transaction that changes the state and reservation, appends the committed event and records it as the version's `applied_event_id`; a losing writer rolls back with its event; readers accept only committed events found in the version history; a divergence blocks new entries, and a losing writer does not.
- **Finding 2, part two.** WDA-06 said a state with no event is "explained by a `CORRECTION_RECORDED` event". That event requires an original `EventRef` and none exists. **Change:** a new registered type, `LEDGER_AUDIT_DIVERGENCE_DETECTED`, with four reasons in a closed list; the hold ends only on fresh evidence applied through the commit rule. The author proposed five reasons. I omit `OUTBOX_GAP` because the watchdog pulls a read-only copy (section 5.5): there is no outbound item to lose, and a lagging or gapped copy already gives `GAP_DETECTED` or an `UnresolvedEvidence` record. The registry is now 42 types. Oracles 057 to 059 are rewritten; the author's matrix AC-01 to AC-10 maps to them as follows: AC-01 to AC-03, AC-05 and AC-10 to 058 and 059; AC-04 and AC-06 to 057; AC-07 to 059; AC-08 to 059 and the existing chain oracle 004; AC-09 to 059.
- **Finding 8.** The header and section 19 still named EXT-G0R-05 as current. **Change:** both now name EXT-G0R-09 and use its line numbers. Row 1 of section 19 lists what the author changes when the extension contract names this version: its lines 134, 142 and 297 (the hash, including the pinned `wda_contract_sha256` value in line 142), and lines 103, 291, 295, 342, 346 and 448, which rely on WDA-05's content or its count of 56 oracles, now 59. The author decides which of the other lines naming WDA-05 are history.
- **Not changed.** Everything else. The ledger event rows (request, committed, denial) and everything the owner-approver or G2 decides are not WDA text.

## 14. Answer to the author's review of the original proposal

| Finding | Answer | Where |
|---|---|---|
| WD-A01, audit-failure bypass | Accepted in full. My rule conflicted with the clock worksheet (`04`, line 12), which makes an audit outage a hard boundary for every automated broker action. The emergency journal is withdrawn | 3.4 rule 6; principle 10; decision 8 |
| WD-A02, D3 endpoint | Accepted. WDA-01 had already replaced `ALERT_GENERATED` with the two open alternatives; this version adds that generated and send-attempted are never enough | 7 |
| WD-A03, E2 origin | Accepted. WDA-01 had already withdrawn the start from provider acceptance; it is now only an auxiliary measure | 7 |
| WD-A04, start of D1 and E3 | Accepted. The start is a bracket with both bounds kept, and the convention is yours to select | 7 |
| WD-A05, missing log against missing runtime | Accepted. Seven named results; feed unavailable is its own state; the watchdog's absence is reported by the outside witness | 1; 4; 5.5 |
| WD-A06, multi-stream integrity | Accepted. One writer per stream, causal references, watermarked checkpoints, and a plain statement that local hashes do not detect a full rewrite | 3.2 |
| WD-A07, privileged controls | Accepted. Owner-tier, authenticated, fenced, one-way; no general write interface and no broker token | 5.2; 5.7 |
| WD-A08, dossier status | Accepted. Stage-aware, with four statuses | 3.5 |
| WD-A09, notifications and self-observation | Accepted. Most was already present; the wording on one person with two devices and on unproven providers is added | 6 |
| WD-A10, independence against portfolio consistency | Accepted. One fenced portfolio ledger; a shared failure refuses every dependent instrument | 3.2 |
| WD-A11, timestamps and confidentiality | Accepted. Source identity kept with raw times; the redaction label is checked, not trusted; restricted storage for broker evidence | 3.1; 3.4 rule 7 |
| WD-A12, scope and modules | Accepted. `WD-OFF-01` and `WD-OFF-02` are separate candidates that need their own scope admission | 5.3; 8 |
| WD-A13, the watchdog does not guarantee protection | Accepted. The plain-words claim is corrected | 1 |

One point is left open rather than agreed: whether an authenticated acknowledgement can stop E1 (section 7, third point). The annex does not address the case, and the master's wording supports it. It is put to R1 and to the owner-approver, and is not adopted.

## 15. Answer to the author's review of WDA-02

| Item | Answer | Where |
|---|---|---|
| OR-1, acknowledgement and E1 | The author supports the same reading. It is still the owner-approver's to select. Written as alternatives A and B with the author's conditions | 7 |
| OR-2, D3 handoff | Accepted. `ESCALATION_HANDOFF_EVIDENCED` is defined with the author's conditions; my earlier suggestion is withdrawn | 3.3; 7 |
| OR-3, names | Accepted. One vocabulary, an alias table, and a catalogue for every health and alert event | 3.3 |
| OR-4, watchdog unavailable | Accepted. V3 records only that proof is absent; the witness is the authority; the watchdog writes to its own record | 3.7; 4 |
| OR-5, the annex | Accepted. The annex is not retired. The typed field table is added, and section 16 maps the annex | 3.1; 16 |
| Open area (a), watchdog-owned record and permissions (`WDAREV-06`) | Addressed | 3.2; 3.7; 5.5 |
| Open area (b), expected-cycle identity and calendar versions (`WDAREV-05`) | Addressed | 4 |
| Open area (c), typed envelope (`WDAREV-04`) | Addressed. The proposal on `replay_sequence` needs the author's agreement | 3.1 |
| Open area (d), clock alternatives (`WDAREV-03`) | Written as checkable alternatives. Selection stays with the owner-approver | 7; 10 |
| Open area (e), home and precedence (`WDAREV-12`) | A lineage rule is proposed. Selection stays with the owner-approver | Header; 10, decision 9 |
| Recommended correction 4, edge cases | Oracles `V3WDA-021` and `-025` to `-028`, and `-033` | 9 |
| Recommended correction 5, unsupported claims | The outside service's remaining dependencies are stated | 5.4; 6 |
| `WDAREV-07`, `-08`, `-11`, remaining tests | Oracles `V3WDA-029` to `-032` | 9 |
| `WDAREV-09`, failure domain and alerts | No further change is possible in text. Hosts, accounts, recipients and canaries are later choices and later proofs | 10 |

One point is put back to the author and R1: my reading of `D06-FREEZE-02` (sections 4 and 5.7). The author's review lists "watchdog required for entries" as open. The master appears to record it already. The author has since agreed with the reading, adding that the finding itself stays open (section 18). Section 17 now answers `WDAREV-01` to `-12` from their own text, not from the summary used above.

## 16. Where the author's annex is carried

| Annex section | Carried in | Note |
|---|---|---|
| A, boundaries and phases | 5.3; 8 | Kept by meaning, not row for row |
| B, envelope and chain | 3.1; 3.2; 3.3; 3.4 | Field types and checks are now given |
| C, audit failure and protective actions | 3.4 rule 6; principle 10 | |
| D, expected cycles and health evidence | 4 | The cycle key and calendar versions are added |
| E, alerts and the six clocks | 6; 7 | E1 is put as two alternatives; the annex gives one |
| F, stage-aware dossier | 3.5 | |
| G, test oracles | 9 | Numbers and meanings unchanged |
| H, open choices | 10; header | |

The annex stays as source evidence. Marking it superseded belongs to a later lineage record that the owner-approver approves.

## 17. Answer to the author's review of WDA-01, from its own text

| Finding | Answer | Where |
|---|---|---|
| `WDAREV-01`, audit-failure rule | Accepted. The instruction that a protective close must go ahead is gone. Every condition the review lists for an alternate journal is named, with ownership checks and the G3 grant | 3.4 rule 6 |
| `WDAREV-02`, onset of D1 and E3 | Accepted. A bracket with both bounds; the episode has its own identifier; E3 runs across failed repairs, alerts and restarts and ends only on broker proof | 3.1; 7 |
| `WDAREV-03`, D3, E1 and E2 | Accepted. The handoff has its own event; E2 is not started without evidenced delivery; the unusual order of events is in the case table and the oracles | 3.3; 7; 9 |
| `WDAREV-04`, integrity | Accepted. One fenced writer and an atomic write; encoding rules and algorithm stated; the claim about truncation is conditional on heads kept outside; a checkpoint failure neither stalls instruments nor passes the portfolio ledger | 3.1; 3.2; 3.4 |
| `WDAREV-05`, supervision | Accepted. Signed roster and calendar versions, the cycle key, the completion rule, trusted time and minimum coverage. `WATCHDOG_SELF_UNOBSERVABLE` is the outside witness's to report | 3.3; 4 |
| `WDAREV-06`, writer boundary | Accepted. A separate watchdog record with no V3 write or control permission; the trip request has its own narrow endpoint; custody covers both records | 3.6; 3.7; 5.7 |
| `WDAREV-07`, dossiers | Accepted | 3.5 |
| `WDAREV-08`, redaction, clocks and the stop store | Accepted. The stop and breaker store fails closed and does not rest only on the audit device | 3.1; 3.4 rules 6 and 7 |
| `WDAREV-09`, failure domains and alerts | Accepted. Recipient, secrets and power added to the shared list. Real proofs stay at G3 | 5.4; 6 |
| `WDAREV-10`, scope and tests | Accepted. Two separate candidates, stable identifiers and stage labels | 5.3; 9 |
| `WDAREV-11`, isolation | Accepted | 3.2 |
| `WDAREV-12`, one home | Open for the owner-approver. Nothing here is copied into V1.8 or the extension contract | Header; 10, decision 9; 19 |

## 18. Answer to the author's review of WDA-03

| Finding | Answer | Where |
|---|---|---|
| `WD03-A01`, a signed statement need not be good news | Accepted. An admission test, with nine conditions since WDA-05. An authentic statement that reports any mandatory row as other than complete, or leaves one out, is rejected | 4; oracles 034, 035, 039 |
| `WD03-A02`, circular head | Accepted. The statement names the head before its own issuance event and is released only once that event is durable | 4; oracles 036 to 038 |
| `WD03-A03`, alignment with the extension contract | Accepted. Section 19 lists nine differences with line numbers. No precedence is claimed, and neither document is changed by the other | Header; 19 |
| `WD03-A04`, E1 consistency | Accepted. The inconsistent sentence is corrected, and a case table covers both alternatives | 6; 7; oracle 044 |
| `WD03-A05`, references and schema | Accepted. A five-part reference, family profiles, registries and written-out encoding rules. The profiles for seven families are for the author to confirm | 3.1; oracle 042 |
| `WD03-A06`, findings that change | Accepted. Findings are revisions with a watermark; "completed late" is its own result; a missed event is never removed | 3.3; 4; oracle 040 |
| `WD03-A07`, breaker request | Accepted. One seven-step transaction. The policy stays unselected and G3 only | 3.3; 5.7; oracle 041 |
| `WD03-A08`, traceability | Done in section 17 | 17 |

The author's answers to my four questions are taken as follows. On the supervision rule, the reading is agreed and the finding stays open (section 4). On the single counter, the replay order the author asked for is stated (3.1). On the 27 fields, the types are recorded as not yet accepted (3.1). The two missing documents have been received.

## 19. Differences from EXT-G0R-09

Line numbers are EXT-G0R-09's (SHA-256 `67ba2105e64b41b9c11dd9a2ce63e561f23ee3085f9f994c9d2dea5c18d42159`). This section replaces the earlier comparison with EXT-G0R-05, whose rows are answered in sections 15 to 18 and 20. Nothing in this table changes either document.

| # | Subject | EXT-G0R-09 | This document | Standing |
|---|---|---|---|---|
| 1 | Which version is referenced | Lines 134, 142 and 297 pin the WDA-05 hash. Lines 103, 291, 295, 342, 346 and 448 rely on its content or its count (line 448: "WDA-05 56-oracle namespace"). In all, 51 lines name WDA-05 | The current candidate is this version, with 59 oracles | **Open, and the author's.** The next extension contract names this version's exact fingerprint in those places. The count in line 448 becomes 59 |
| 2 | Sequence counter | Line 295: `replay_sequence` is a documentary alias for the one stored `stream_sequence` | 3.1: the same | Aligned |
| 3 | When E1 stops | Lines 305 and 312: alternatives A and B both kept, neither selected | 7: the same two alternatives | Aligned. The owner-approver selects |
| 4 | Clock fields and results | Line 303 lists the fields and the five results | 3.3 and 7 use them by reference | One difference: line 303 has `last_verified_good_utc_or_NULL`, and 3.1 leaves an empty field out and never writes null. The author's wording to change |
| 5 | Emergency journal | Line 297: withdrawn. Line 318: no automated broker mutation unless a separately approved durable evidence path exists | 3.4 rule 6 says the same and proposes no such path | Aligned |
| 6 | Supervision in the admission decision | Section 2.2.1 and line 132 name `SUPERVISION_POSITIVE`; lines 136 to 152 map the nine-part test; line 342 places it in EXT-11 | 4: the statement, the admission test and what it hands on | Aligned in content. The pin in line 142 is to WDA-05 |
| 7 | Field types | Line 295 names 26 fields and gives no types | 3.1 gives types | No conflict in content. Two places could come to define the same thing, which is the home decision |
| 8 | Clock oracles | `CLK-01` to `CLK-06` (line 320), `V3EXT-072` (line 438) and `V3EXT-081` (line 447) | Oracles 009 to 012, 021, 027, 028, 033 and 044 cover the same ground | Mapped below. Nothing is renumbered |
| 9 | Ledger event rows | Annex C gives 28 event rows and leaves a ledger placeholder blocked | 3.3 registers 42 types and says the ledger rows are the author's to supply | **Open, and the author's.** The rows follow the owner-approver's closing of `D03-FREEZE-06`. Until then those types are not registered |
| 10 | Ledger and audit order | Line 295 says the pre-send journal and no-resend rules follow V1.8's atomic ledger definitions | 3.4 item 8: one transaction domain, a request, one commit, a denial for a losing writer, and recovery | Open, and the author's: map oracles 057 to 059 into the ledger unit and its test list |

Proposed wording for the future reference in row 1, with nothing filled in: "The audit, supervision, alert and clock event definitions are those of WDA-NN, SHA-256 [fingerprint], selected by the owner-approver on [date]."

**Clock oracles in both documents.** As I read the order of EXT-G0R-09 line 320, `CLK-01` to `CLK-06` are D1, D2, D3, E1, E2 and E3 in that order.

| Extension contract | What it asserts | Oracles here on the same ground |
|---|---|---|
| `CLK-01` (D1) | An uncertain earlier loss is a bracket, never a zero-length pass | 011, 033 |
| `CLK-02` (D2) | Failed or absent broker proof does not stop the clock | None. Broker proof is the extension contract's to test |
| `CLK-03` (D3) | Both unselected endpoints, sent and delivered | 010, 028 |
| `CLK-04` (E1) | Sent or accepted by the provider is not delivered | 009, 021, 044, 056 |
| `CLK-05` (E2) | Delivered and not acknowledged; no delivery means not started | 009, 027, 044 |
| `CLK-06` (E3) | Risk continues across a failed repair, repeated alerts, weekends, a restart and an uncertain loss | 011, 033 |
| `V3EXT-072` | Document review of the acknowledgement reading of E1 | 021, 044 |

The `CLK` identifiers and `V3EXT-072` are documentary oracles of the extension contract. The `V3WDA` identifiers are fixture oracles for the candidate offline modules. Where one executed test is evidence for both, it is cited under both identifiers and counted once in any acceptance total. The starts and stops that remain the owner-approver's to select are selected by neither set.

## 20. Answer to the author's acceptance review of WDA-04

No finding is rejected. "R1" in the last column means the independent check that the author's closure rule requires before a finding can be called closed.

| Finding | Answer | Where | Oracle | What remains, and whose it is |
|---|---|---|---|---|
| `WDA04-F01`, a statement outliving a newly due cycle | Accepted. Check 6 tests coverage at the moment of admission, and being in date never overrides it | 4 | 045 | R1. The author's admission check (F03) |
| `WDA04-F02`, reuse and rollback | Accepted. A durable high-water mark of every statement observed; the same statement may be used again; a restart rule; `V3WDA-036` revised | 4 | 036, 046, 047 | R1 |
| `WDA04-F03`, the admission decision does not use the proof | Accepted as the author's to fix. This document now states what the test hands to the admission decision | 4; 19, row 6 | The author's, in the extension contract's namespace | The author: a later extension contract |
| `WDA04-F04`, roster completeness | Accepted. Check 5 tests the roster itself against `WDA-MD-1` and the enabled instruments. No start-up exception | 4 | 048, 049 | R1 |
| `WDA04-F05`, requests carrying states | Accepted. The control family is split; a request or receipt carries no state and proves none | 3.1; 3.3 | 050 | R1. The author: rows for the four V1.8 control events |
| `WDA04-F06`, breaker request during an audit outage | Accepted. Four failure cases with their outcomes; the endpoint's reply is never evidence | 5.7 | 051 | R1. Proof at G3 |
| `WDA04-F07`, one writer against many workers | Accepted. Workers submit; one writer per stream appends | 3.2; 3.3 | 052 | R1 |
| `WDA04-F08`, schemas and lists | Accepted. One registry of 41 event types with payload members, and closed lists. Unregistered types are rejected | 3.1; 3.3 | 053 | The author: rows for seven families and four control events, and closed lists for `actor_authority`, `uncertainty` and ledger states. A later manifest: payload schema hashes. The owner-approver: severity, routes, acknowledgement method, access class. R1 |
| `WDA04-F09`, encoding | Accepted. Rules for input that is not canonical, and six vectors with bytes and hashes | 3.1; 21 | 054 | R1 or the author: recompute with an independently written encoder |
| `WDA04-F10`, references across records | Accepted. Good findings need resolved references at a named watermark; absence is recorded as such and can never pass the admission test | 3.1 | 055 | R1 |
| `WDA04-F11`, late delivery evidence | Accepted. The times are kept apart, and a retrospective result never replaces a recorded breach | 7 | 056 | R1 |
| `WDA04-F12`, differences from the extension contract | Not this document's to close. The mapping of clock oracles the finding asks for is added | 19 | None | The owner-approver: the home and the clock readings. The author: a later extension contract |

## 21. `WDA-CF-1` test vectors

I computed these once, with two short encoders of my own that agree with each other. That is not an independent check, and no implementation test is claimed. Member names and values are test data only. They register nothing.

**V1. Order of member names, and white space.** Input: `stream_sequence` 7, `event_type` "CYCLE_COMPLETED", `cycle_attempt` 1, in that order and with spaces between tokens. Canonical bytes (70):

```
{"cycle_attempt":1,"event_type":"CYCLE_COMPLETED","stream_sequence":7}
```

SHA-256 `b40eda57ac8cfcec7dda1a1a03b282abfb22e9f1b18b15a3507e0ed6b698002d`.

**V2. Text normalised to NFC.** Input: one member, `text`, given once as "Caf" followed by U+00E9, and once as "Cafe" followed by U+0301. Both give the same 16 bytes, in hexadecimal:

```
7b2274657874223a22436166c3a9227d
```

SHA-256 `85094b1744c1c9ef3c01c1157f7857d26080e4b1d73c279cb84bccbf550b1a47`.

**V3. Escaping.** Input: one member, `text`, holding these eleven characters: a, quotation mark, b, backslash, c, U+000A, d, U+0009, e, U+007F, f. Canonical bytes (34), in hexadecimal:

```
7b2274657874223a22615c22625c5c635c7530303061645c7530303039657f66227d
```

SHA-256 `4400a7bdf0a4fe2f134adb78942adf1c5eb61fa04280d67149f2341261f4c60a`.

**V4. Whole numbers.** Input: `a` 0, `b` minus 5, `c` 1000000. Canonical bytes (26):

```
{"a":0,"b":-5,"c":1000000}
```

SHA-256 `fbbbe287f52c437db665ab0744de51bbef349dbe2e66f13719eaf56aa4d5f667`.

**V5. Nested objects, list order, and upper case before lower case.** Input: `refs`, a list of two objects in the order shown, then `Z`. Canonical bytes (116):

```
{"Z":"upper sorts first","refs":[{"event_id":"evt-b","stream_sequence":9},{"event_id":"evt-a","stream_sequence":3}]}
```

SHA-256 `092490de2a362f1f5fd5f9f6f0f015656f368883af0614deb967269ec6ae3bcf`.

**V6. A whole event.** A `CYCLE_COMPLETED` event, the first in its stream. Its payload, in canonical bytes (245):

```
{"completion_rule_id":"eval-bar-close-v1","heads":[{"event_hash":"4444444444444444444444444444444444444444444444444444444444444444","stream_id":"instrument:1111111111111111111111111111111111111111111111111111111111111111","stream_sequence":41}]}
```

`payload_digest` is `5fd0dd1fba159d1174886254b6fdb3292417380d8fc4bb7473982565ed0e3f4e`. The envelope without `event_hash`, in canonical bytes (929):

```
{"UTC_event_time":"2026-11-11T10:00:00.000000Z","UTC_recorded_time":"2026-11-11T10:00:00.250000Z","account_scope":"1111111111111111111111111111111111111111111111111111111111111111","actor":{"id":"worker-eurusd","kind":"COMPONENT"},"actor_authority":"CYCLE_WORKER","build_sha256":"3333333333333333333333333333333333333333333333333333333333333333","canonical_form":"WDA-CF-1","cycle_attempt":1,"cycle_id":"2222222222222222222222222222222222222222222222222222222222222222","event_family":"HEALTH","event_id":"evt-0001","event_type":"CYCLE_COMPLETED","payload_digest":"5fd0dd1fba159d1174886254b6fdb3292417380d8fc4bb7473982565ed0e3f4e","payload_schema":"wda.cycle_completed.v1","prior_event_hash":"0000000000000000000000000000000000000000000000000000000000000000","record_id":"V3","redaction_class":"REFERENCE_ONLY","schema_version":1,"stream_id":"health","stream_sequence":1,"uncertainty":"NONE","writer_identity":"v3-health-writer"}
```

`event_hash` is `2d0c6cbe54411829ecca286b273fef73992ab60f2f8a671692de9798838a9d9c`.

**Rejected inputs.** Each of these is rejected before anything is appended: a member name given twice in one object; the numbers 1.5, 1e3, 007 and +1, and minus zero; `true`, `false` or `null` as a value; an empty text, an empty list or an empty object; a lone surrogate such as U+D800, or the bytes C3 28; a member that is not registered for the event type; an unknown `schema_version`, `payload_schema` or `canonical_form`; and a reference that lacks any of its five parts.
