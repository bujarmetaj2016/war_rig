# R2 final mechanical rerun of V3 Stage D03 (13 November 2026)

Review only. It selects no option, grants nothing and starts no timer. State unchanged: 0/43 binding dispositions closed; 13/13 freeze findings open; 21/21 repairs open; all 14 Stage D owner decisions OPEN; six clocks UNSET; the 42 edges and three event types stay unregistered; no code, broker, DEMO or LIVE authority; no design freeze; no cooling-off timer.

Rerun: `06678562-War_Rig_V3_StageD03_Bounded_Mechanical_Residual_Fixes_20261113.zip`, SHA-256 `23bdbe3b7d0d34b8b1d19fd78daf9990b7ea89b506634da7d4953cea9ef67ead` (30 ZIP entries, 29 manifest-verified files), against the Stage D02 package R2 replayed (`ed91fcf2...0d50d77`). Scope: acceptance predicates A1 to A11 and a member-by-member comparison with D02, as agreed. Nothing else was re-reviewed.

## In plain words (for Jon)

**Stage D03 passes. All nine of my D01 findings and the two leftovers are closed, and this package needs no further R2 review.** The author fixed exactly the two things I listed and changed nothing else: the six clock tests now each use their own fault and event list (my wording, word for word), and the 35-guard review sheet now shows the corrected guards. The old README is retired. I compared the new package with the previous one file by file: four files changed (the clock tests, the review sheet, the old README and the manifest), and no contract, owner decision or pinned source changed. 56 checks, 0 failed; all eleven acceptance tests are met.

**What this does and does not mean.** R2 has no open finding on Stage D. It does not mean the design is approved, frozen or authorised. Nothing has been run or built, the 187 tests are still unexecuted, and all 14 decisions are still yours.

**What comes to you now, in this order:**

1. **The 14 owner decisions** (table below, in plain words). Each is a proposal from the author; none is selected. Please read OD-06 first.
2. **The change to EXT-G0R-14 and WDA-08.** The package adds seven master rows (the life of a trade idea, and whether a send attempt may go out) as switched-off proposals. Making them real needs a controlled change to both contracts, because both list only five tracks. I recommended that route; the other is to change the master. WDA-08 is my design, so someone other than me must check that change. That is A-06, and it is yours to resolve.
3. **The 48-hour wait document (V3-GOV-48-01 REV3)** is separate: the author's fix round has not arrived, and when it does I run one mechanical replay.

**Corrections to my own earlier report.** My Stage D02 report left out items my own checker had recorded, and numbered its observations differently from my evidence file. Both are set right below: one consolidated list, with the two omitted items that matter first. Neither changes the verdict. While building this rerun, four of my own tamper-control expectations were wrong (I had mistaken which check owns what) and one planted control was too strict. I corrected them and the checker itself needed no change.

### The 14 owner decisions, in plain words (nothing to tick today)

This is my reading of the author's sheet, not a selection. "Author's lean" is the author's proposal; "my note" is where to take care.

| # | The question | Author's lean | My note |
|---|---|---|---|
| OD-01 | Which route to the first design freeze, and exactly which modules it covers | R + C: restricted, offline-only scope | Your earlier provisional preference. The module list is still to be written. |
| OD-02 | If the risk-sized stake is below IG's minimum, do we round up? | No: refuse the entry, never round up | Some small trades get skipped. |
| OD-03 | The GBPUSD strategy uses limit entries; V3 starts market-only | Switch that strategy off until a separate decision | No GBPUSD trading meanwhile. |
| OD-04 | US500: which direction may V3 trade? | Off until you choose a policy (for example long-only) | V3 will not guess a side. |
| OD-05 | Stop type, money risk limit, margin and size | Leave every real number unset | So no real-money risk permission exists yet. |
| OD-06 | What happens when a position is found unprotected? | V3 takes no protective action of its own: it records an incident and tries to alert you; you fix it by hand in IG | **Read this one carefully.** An unprotected position stays unprotected until you act, and if you cannot be reached nothing acts. The runbook does not exist yet. Choosing protection A, B or C is still open. The wording is now corrected (F9). |
| OD-07 | Conflicting evidence: late fills, stale snapshots, unknown outcomes | Stay UNKNOWN, keep the risk reserved, no automatic retry, no release without proof | The sheet now says plainly that a full conflict policy is not drafted and stays your decision (F9). |
| OD-08 | Seven contract rows the earlier review marked partial | Admit them as type-only offline designs, or exclude them from the freeze | The author should explain these rows in plain words before you decide. |
| OD-09 | WDA-08 decisions 1, 3, 9: independent watchdog, home document, late cycles | Independent failure domain; late cycles never count back | WDA-08 is my design. Someone else must check it. |
| OD-10 | Six clocks: accept the definitions, defer meanings and time limits | Accept definitions and tests only; no running clock | D3 and E1 keep the A-or-B choice open (F7). The six clock tests are now distinct. |
| OD-11 | Who may resume after a Stop, or reset the watchdog breaker? | No automatic resume; a separate authenticated procedure later | Typo "watchguard" in the topic line (polish). |
| OD-12 | Reviewer, witness, evidence custody, design-freeze control | The original R1 under a separately evidenced appointment | Bundles three decisions in one tick; consider splitting. |
| OD-13 | Where does the 48-hour wait sit? | Before the G1 grant only, not at G0-R acceptance | Your earlier provisional preference. The governance amendment is still pending; no timer. |
| OD-14 | Register the three ledger event types and the edge graph | Only after independent checks and your fingerprinted acceptance | The wording no longer says "complete now". It still says R2's findings are open until fixed and replayed, which this report now settles. |

## Result by acceptance predicate

| Predicate | Result | In one line |
|---|---|---|
| A1 (D01-F1) | Closed | Seven axes; 42 edges; 38 guarded, 84 denied, 122 pairs; master rows carried; never-sent release rule present. |
| A2 (D01-F2) | Closed | Duplicate-order and conflicting-order replies route to UNKNOWN; release in the same commit. |
| A3 (D01-F3) | Closed | Unset or untrusted bounds count as exceeded on edges 003, 016, 025; no number selected. |
| A4 (D01-F4) | Closed | Target state in the denial event; `NONE_UNLISTED`; `∅` rule; three digests reproduce. |
| A5 (D01-F5) | Closed | Producer and writer labels equal EXT Annex D and WDA-08; `actor_authority` separate. |
| A6 (D01-F6) | Closed | 187 rows, positives and denials pairwise distinct, zero broker calls. |
| A7 (D01-F7) | Closed | D3 and E1 end evidence UNSELECTED, A and B kept apart. |
| A8 (D01-F8) | Closed | The 28 EXT section 4.5 field names, `overlap_mode` included. |
| A9 (D01-F9) | Closed | OD-06, OD-07, OD-14 wording identical in the owner JSON, the review sheet and the specification. |
| A10 (D02-R1) | Closed | Six clock rows pairwise distinct; no fault joined by "or"; each equals my replacement text byte for byte; every other member of the rows unchanged. |
| A11 (D02-R2) | Closed | Guard, effect and denial text of all 35 edges equals file 08 verbatim; the README states none of 147, 90, 31. |

## Observations (all non-blocking; none is required for acceptance)

**Numbering correction.** My D02 change list and report numbered observations N10 to N14 with different content from the N10 to N16 in my D02 evidence file; only one item (the half-commit one) appeared in both. The D02 report therefore left out six items from my checker's list, two of which matter (N10 and N11 here); the other four are N13 to N16. This list is the single record and replaces both.

- **N10 (omitted from the D02 report).** In `SD1-BROKER-UNKNOWN` (file 06) the member `input.known_current_states` says `broker_operation` is `UNKNOWN`, but the row's own `sequence` starts from an attempt that is `ATTEMPTED` at version 7. A builder who follows the block builds a test that passes with no transition at all. I treat it as non-blocking: the sentence and `expected_version` 7 give the starting state, the row is unexecuted, and the fix is one word. Suggested edit, when the author next touches the file: in that row set `known_current_states.broker_operation` to `ATTEMPTED`, and set `position` and `protection` to `∅` (my reading: the entry has not filled; the author may choose other pre-fill states). The other five rows that share the block state no starting broker state in their sequences, so they do not contradict it.
- **N11 (omitted from the D02 report).** The four excluded-edge denial rows (`SD1-EDGE-007-NEG`, `-010-`, `-012-`, `-013-`) mutate `RESTING_LIMIT` into `RESTING_STOP` or back. Both are denied, so the mutation tests nothing the baseline does not already deny. Suggested edit: add to each row's `expected` the sentence "Unconditional denial: every resting order class is denied on this edge, so the mutation changes nothing."
- **N12 (was N10 in the D02 change list).** Edges 001 and 030 and master rows 036, 038, 040, 042 need one transaction across more than one axis (for example `NOT_SENT→ATTEMPTED`, `ELIGIBLE_NO_WIRE→WIRE_ATTEMPTED` and `INTENT_ACTIVE→INTENT_BROKER_OUTCOME_UNRESOLVED`). Each event names one axis, so nothing ties the several COMMITTED events of one such transaction together, and no test injects a fault so that exactly one of the rows would apply. Not a design-stage defect and not changed here (a new field changes the digests). Settle before implementation: one `transaction_group_id` or one composite event, plus a half-commit test.
- **N13.** File names still say D01, 35 and 59 (`00_STAGE_D01_...`, `01_EDGE_CONTRACTS_35_DRAFT.json` holding 42 edges, `02_..._59_...` holding 84). Harmless; rename at the next controlled register.
- **N14.** The optional polish from the D01 change list (OD-11 typo "watchguard", three "if unresolved" lines) was not applied. No effect.
- **N15, N16 (settled).** The stale statement about the BB-04 replay and the master `ATTEMPTED/UNKNOWN→UNKNOWN` edge against CC1-NEG-018 (D01 observations N7 and N9) are now addressed in the specification.
- **N17 (was N11 in the D02 change list).** The author's `all_test_inputs_nonempty` check cannot see duplicated inputs; a pairwise-distinct check per test kind would have caught R1.
- **N18 (was N12 in the D02 change list).** Files 10, 13 and 15 still say R2's replay is pending, and OD-14 says findings are open until fixed and replayed. After this report they read stale. Update the status wording together at the author's next revision; no count changes.

**Disclosure (A6).** My A6 test did not name the clock rows; that gap produced the D02-R1 leftover and is closed by A10. For the 187 rows I ran machine checks on every row and read fixture contents for a sample; N10 and N11 came from reading more rows. Other rows are held to the machine checks.

## What I checked

- **Package.** Zip hash equals the author's; 30 entries; manifest of 29 files; every hash and size; extracted copy equals the zip; 12 files byte-identical to D01 including all 11 pinned sources, which hash to the values I hold.
- **D03 against D02.** Same 30 members; exactly four differ. File 06: the same 187 ids in order; only the six clock rows differ, only in the two named members, each equal to my replacement text. File 08: same line count; the title and ten lines differ, nothing else. The old README equals my one-line replacement. The manifest differs only in the three changed files' hashes and sizes. Files 00 to 05, 07, 09 to 15 and the D02 README are byte-identical to D02.
- **Predicates.** A1 to A11 all met on D03; A10 and A11 fail on D02 as received, and A1 to A9 fail on D01, so the tests discriminate.
- **Controls.** 56 fact checks, 0 failed. 15 replay controls, 0 failed (D01 and D02 as received; D03 as base; 11 planted defects, each flipping exactly its own predicate; one more showing that a JSON-only change to edge 006 also flips A11 as it should). 9 tamper controls on a copy of D03, 0 failed (a clock row copied, a fault joined by "or", a clock result changed, a revised guard line shortened, a stale count back in the README, a status file edited, an edge changed, a pinned source edited, a test allowing a broker call).
Not checked: anything run or built (the 187 tests are unexecuted and stay so); the correctness of the master itself; WDA-08 independently (my own design).

## Owner items (listed once)

1. The 14 decisions above, starting with OD-06. Nothing starts until you decide and the controlled process runs.
2. The EXT-G0R-14 / WDA-08 alignment route, and who independently checks WDA-08 (A-06). Neither is selected.
3. Still yours, not answered here: the unprotected-position response (A, B or C), stop type and risk bound; `OC-D03-05`; the 48-hour placement.

## Next

Nothing further from R2 on Stage D. I will replay the author's REV3 fix round for V3-GOV-48-01 when it arrives (one mechanical replay), and help with the decisions if you ask.

## Evidence

`WarRig_V3_R2_StageD03_rerun_evidence_20261113.zip` holds the rerun script, the fixes modules, the tamper-control script, all outputs (56 checks and 24 controls, 0 failed) and this report, with a README and hashes.

