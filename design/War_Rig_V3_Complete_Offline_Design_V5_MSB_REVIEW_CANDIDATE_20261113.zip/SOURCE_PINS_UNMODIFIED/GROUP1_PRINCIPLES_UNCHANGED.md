# War Rig V3 / A0.10 — Group 1 principles (revised approval candidate)

**Date:** 27 October 2026  
**Status:** PROPOSED — NOT APPROVED  
**Scope:** DESIGN_ONLY; Group 1 principles, **not** a selection or closure of GOV-01–GOV-06.

## The principles proposed for your approval

1. **One final owner approver.** You are the sole person who makes final owner decisions on proposed War Rig designs and policies. I explain each choice in plain English, inspect evidence, challenge assumptions and recommend options. AI assistance is **not** an independent human review, signature or acceptance.

2. **Stronger scrutiny for safety-critical changes.** These include financial risk limits, margin, position sizing, broker access or communication, trade execution, production releases and cutover, **model changes or fitting**, and **policy changes or activation**. Unknown or unproven conditions remain blocked. A design approval never authorises fitting, activation, broker operations, deployment or trading.

3. **Explicit non-independent review controls.** The proposed single-owner process does **not** claim to replace an independent human with another independent reviewer. Instead, every review and approval record produced under it must be labelled `NOT_INDEPENDENT_SINGLE_OWNER_PROCESS` and identify any AI assistance. It must also have:
   - A **cooling-off gap**, measured between presentation of the final evidence-bound proposal and your final approval. **You will choose the duration; it is currently UNSET.** Until chosen, the timing control is not satisfied for later substantive approvals.
   - A **short approval checklist** confirming: (a) you understand the choice and alternatives; (b) you have seen evidence and unresolved gaps; (c) risks and fail-closed safeguards are explicit; (d) the exact permission granted and withheld is clear; and (e) the cooling-off interval and evidence fingerprints have been checked.
   - A **separate, user-controlled copy** of the decision register, approved decision text, relevant source fingerprints and the approval-record fingerprint, kept **outside this assistant's workspace**. External custody must be confirmed; it is not yet complete.

4. **Records must be unambiguous.** Each decision names its scope, selected option, supporting evidence and SHA-256 fingerprints, known uncertainties, safeguards, time and any outstanding prerequisites. A package or grouped decision cannot silently convert deferred, rejected or unreviewed requirements into accepted ones. A local chat record is not automatically a cryptographic signature.

5. **Existing two-person safeguards stay in force pending controlled change.** The proposed V32 acceptance standard's independent reviewer/quorum requirements, the **live system's release-signing and deployment-record two-person rules**, and **K1 and H13 owner signatures/independent countersignatures** are **not** waived by approval of these principles. The same reservation applies to the host-anchor approval path and other owner-value approvals. A sole-owner alternative must be explicitly reconciled, evidenced and adopted before it can be called effective.

## Still open from the GOV-01–GOV-06 brief

This Group 1 approval would **not** decide:

- **Contract adoption:** which exact acceptance contract is adopted **by SHA-256 fingerprint**, by whom, and how provenance-only version bumps and substantive amendments are treated.
- **Classification and quorum:** which of the **48 priority EXEC/RISK/MODEL/POLICY/MIG rows**, and which other items, count as safety-critical; how the proposed reviewer quorum is handled.
- **Roles:** the crosswalk among `Independent Architecture Reviewer`, `independent_reviewer` and `architecture_authority`, the complete permitted/prohibited overlap list, and human accountability for AI-prepared evidence.
- **Proof and signatures:** the approved authentication, signing, countersigning, custody and evidence-binding method, including the 20 owner-value approval-policy bindings, K1, H13, the host anchor and live release/deployment controls.
- **Row-to-package roll-up:** the rule for turning 166 individually adjudicated requirements into a separate architecture package decision, including deferred, rejected and unreviewed entries.

## Named next gate: CAR-01 — Controlled Acceptance and Live-Control Contract Decision

**CAR-01 is a proposed future controlled decision, not an approval granted here.** Before using the single-owner process as a replacement for current independent or two-person controls, CAR-01 must inventory and reconcile: the fingerprint-pinned V32 acceptance contract; reviewer quorum and role separations; release-signing and deployment-acceptance record rules (including any existing Ed25519 provisions); K1 default write SLA and its 20 overrides; H13 signatures/countersignatures; the host anchor and other owner-value bindings; authentication/custody; and the row-to-package acceptance rule. It must identify every clause changed, retained or left blocked, with explicit owner selection, independent evidence where required by the then-applicable contract, and controlled successor fingerprints. **Until that valid controlled change occurs, the existing rules and all blocking gates remain in effect.** CAR-01 itself grants no broker or production authority.

## Earlier procedural authority — supersession only if this text is approved

Your 26 October 2026 procedural DESIGN_ONLY authorisation included **preparation for independent human readjudication of V32**. **If you approve this exact Group 1 fingerprint, that earlier *workflow-authorisation clause* is superseded by preparation of the proposed sole-owner, explicitly non-independent process and CAR-01.** The prior decision remains preserved as historical evidence. This supersession **does not** amend V32, cancel substantive independent-review or two-person requirements, retroactively create acceptance, or change live controls. Those matters remain for CAR-01.

## Boundaries and approval method

This proposal does **not** adopt V32, dispose of GOV-01–GOV-06, establish the cooling-off duration, approve any owner monetary values, complete the 166-row review, grant architecture acceptance, or authorise model fitting, policy activation, broker activity, implementation, live release or cutover. AC-16 remains OPEN; 0/166 human semantic rulings have been completed; K1/K2 and H13 remain unresolved; the five instrument certifications remain `NOT_PROVEN`; `LIMITED_CUTOVER_BLOCKED` remains in effect.

**Approve only by referencing the full SHA-256 fingerprint of this exact UTF-8 file.** Until you do, there is no Group 1 approval record. After you approve, I will create and show the evidence-scoped approval entry **before** discussing Group 2. No approval will be inferred merely from this draft being prepared.
