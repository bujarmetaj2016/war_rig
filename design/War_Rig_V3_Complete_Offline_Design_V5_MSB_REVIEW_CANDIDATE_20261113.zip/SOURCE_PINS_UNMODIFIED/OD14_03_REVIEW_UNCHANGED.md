# WAR RIG V3 — Stage D owner decision review (OD-01 to OD-14)

**ID:** `V3-SD-OD14-01`  
**Date:** 13 November 2026  
**Status:** `DESIGN_ONLY / AUTHOR_RECOMMENDATIONS / 14_OF_14_NOT_SELECTED / NONBINDING / NOT_FROZEN / NOT_AUTHORISED`  
**Purpose:** One consolidated, plain-language owner decision sheet after Stage D03 R2's documentary replay. **No response is inferred from preparation of this document.**

## Grounding and decision boundary

- **Stage D03:** R2's 13 November final bounded replay reports A1–A11 satisfied, 56/56 checks and no outstanding R2 *documentary* findings. The 42 proposed edge IDs, 84 denied pairs, 3 event types and 187 test **specifications** remain disabled/unregistered/unexecuted. This is not independent acceptance of WDA-08, implementation testing, or an effective registry.
- **Earlier Batch B:** Your 14/14 Batch B choices were provisionally accepted in BB-05; these **14 Stage D decisions are different** and remain all OPEN. The 21 Batch B source questions and all 43 master binding dispositions remain open.
- **Frozen-source precedence:** Corrected V1.8 master, EXT-G0R-14 and WDA-08 are unchanged; the proposed seven-master-edge reconciliation is NOT adopted. Owner controls remain binding until changed through the controlled process.
- **Reading this sheet:** `RECOMMENDATION` is the author's proposed **provisional** direction, not an owner selection. An owner may choose it, modify it, or defer the ID. If an item has subdecisions, the subdecisions must be independently specified before binding treatment. A provisional direction alone closes no OC row or freeze finding.
- **No timer:** Nothing here invokes G0-R acceptance, G1 permission, IG, DEMO, LIVE or a cooling-off start. The proposed G1-only wait remains a pending controlled amendment.

## Decision groups at a glance

| Group | IDs | Principal decision | Main unresolved consequence |
|---|---|---|---|
| I — Restricted scope and instruments | OD-01–OD-04 | Restricted R+C; broker min; GBPUSD; US500 | No authority or strategy eligibility follows from scope preference |
| II — Protection, risk and reconciliation | OD-05–OD-08 | Risk values; unprotected positions; UNKNOWN; seven PARTIAL contracts | No G3 position safety policy / executable-risk proof |
| III — Watchdog, clocks and Stop | OD-09–OD-11 | WDA decisions 1/3/9; six clocks; Reset/Resume | Independent WDA review, actual deadlines and roles unresolved |
| IV — Reviewer, governance and registry | OD-12–OD-14 | Reviewer/custody/hash; 48-hour placement; controlled ledger registration | No binding freeze and no effective ledger/event registry |

### OD-01 — G0-R route and exact expanded/offline scope

**Owner question.** Which G0 route and exact offline module/capability scope should be prepared for owner acceptance?

**Recommended provisional direction:** `PROVISIONAL_PREFER_R_PLUS_C_SCOPE_SCHEDULE`  
Prefer restricted route R with expanded design-scope C, but only after attaching an exact capability-inclusion and exclusion schedule. This selects a design boundary, not an implementation grant.

**What accepting that provisional direction means / costs.** G0-R would freeze a deliberately incomplete, offline-only design; any later operational capability needs a separate gate and amendment.

**Alternative or deferral.** Choose strict/full route F; select a different scope A/B; or DEFER (no G0/G1).

**Still OPEN / not answered by a tick.** Exact owner-accepted module/disabled-policy manifest, 43/13/21 disposition, independent review, governing wait; G0 not accepted.

*Source anchors:* Master V1.8 §10; EXT-G0R-14 §§1,5; V3-BA-04 A-01/A-02; Stage D03 OD-01.  
**Owner response:** `NOT_SELECTED`.

### OD-02 — OC-D03-05: subminimum stakes

**Owner question.** If calculated stake falls below the IG broker minimum, may V3 automatically raise it?

**Recommended provisional direction:** `PROVISIONAL_PREFER_DENY_NO_STAKE_UPLIFT`  
No. Deny that new entry rather than increase stake and therefore breach risk sizing. A minimum stake is not permission to increase risk.

**What accepting that provisional direction means / costs.** Some signals will not trade. The precise broker minimum and budget evidence remain unverified for a future account/instrument.

**Alternative or deferral.** Specify a new risk-bound policy and verify it separately; do not silently assume one.

**Still OPEN / not answered by a tick.** No real minimum stake, risk amount or executable broker proof selected; OC-D03-05 formal row OPEN.

*Source anchors:* Master OC-D03-05; EXT risk-math / broker-budget evidence; Stage D03 OD-02.  
**Owner response:** `NOT_SELECTED`.

### OD-03 — GBPUSD rejection strategy / MARKET-only incompatibility

**Owner question.** What happens to the GBPUSD rejection strategy while V3 permits only MARKET entries?

**Recommended provisional direction:** `PROVISIONAL_PREFER_DISABLE_GBPUSD_G3_PENDING_COMPATIBILITY`  
Keep the strategy defined as research, but do not enable its present limit-entry form at G3. No silent conversion to MARKET.

**What accepting that provisional direction means / costs.** No DEMO trades from that strategy until an expressly reviewed limit-order capability or a separately validated market-compatible strategy exists.

**Alternative or deferral.** Later, separately design/verify working LIMIT entries; or review a genuinely new MARKET-compatible strategy.

**Still OPEN / not answered by a tick.** Strategy compatibility and G3 eligibility still OPEN; four resting-entry ledger edges remain excluded.

*Source anchors:* WG-00; EXT-G0R-14 PAPER-04/PAPER-11, V3EXT-068; BB-04 BF-1; Stage D03 OD-03.  
**Owner response:** `NOT_SELECTED`.

### OD-04 — US500 directional policy

**Owner question.** Which directional policy should apply to US500?

**Recommended provisional direction:** `PROVISIONAL_PREFER_US500_DIRECTION_DISABLED_PENDING_POLICY`  
Do not infer LONG_ONLY or allow either side from an old trading strategy. Keep any executable directional eligibility disabled until you select and evidence the policy.

**What accepting that provisional direction means / costs.** US500 remains ineligible for a future executable entry until a controlled direction policy is chosen.

**Alternative or deferral.** Later select LONG_ONLY with evidence and explicit negatives, or another bounded policy requiring review.

**Still OPEN / not answered by a tick.** US500 long-only/other policy and model/strategy eligibility OPEN; nothing is enabled.

*Source anchors:* Master DirectionEligibilityPolicy; Stage D03 OD-04.  
**Owner response:** `NOT_SELECTED`.

### OD-05 — Stop type / monetary risk maximum / margin/size/FX

**Owner question.** Do we set real stop type, monetary risk, margin, sizing or FX budget values now?

**Recommended provisional direction:** `PROVISIONAL_PREFER_ALL_REAL_RISK_VALUES_UNSET`  
Define typed fields and validation rules in the offline design but leave every real dealing parameter unset. Unknown means deny, not default.

**What accepting that provisional direction means / costs.** No authority to place any account-funded or broker order; no G3 readiness from a completed schema.

**Alternative or deferral.** Make separately reviewed numeric/account/instrument selections later with broker evidence and G3 safety proof.

**Still OPEN / not answered by a tick.** Stop type, finite risk maximum, margin, FX, minimums, leverage and risk tolerance all OPEN; six clocks numeric UNSET.

*Source anchors:* Master §10 C-04/C-05; EXT §2.2; Stage D03 OD-05.  
**Owner response:** `NOT_SELECTED`.

### OD-06 — Unprotected position protective response A/B/C and closed market

**Owner question.** Who actually remedies a broker position if protection is absent, invalid or lost?

**Recommended provisional direction:** `PROVISIONAL_PREFER_NO_V3_PROTECTIVE_MUTATION_OFFLINE_ONLY__G3_POLICY_DEFER`  
For restricted offline scope, keep every V3 protective broker action disabled: automatic stop repair, stop tightening or trailing, close and cancel. The proposed later operational fallback is an incident and attempted human alert, with manual rescue via the IG platform; neither alert delivery nor human response is guaranteed.

**What accepting that provisional direction means / costs.** If this manual-only approach were carried into G3 unchanged, the position could remain unprotected indefinitely if the operator is unreachable. It is NOT evidence of G3 safe readiness.

**Alternative or deferral.** Before G3 select and prove protection response A/B/C (and B-to-A) plus stop type, finite risk cap, operator/backup and closed-market behaviour; or explicitly defer enabling exposed trading.

**Still OPEN / not answered by a tick.** Manual runbook, assured alert/ACK, backup, independent review, closed-market response, broker-proven protection and actual A/B/C selection OPEN.

*Source anchors:* Master OC-D03-08, §10 C-01/C-04; WDA-08 §7; Stage D03 OD-06; R2 final review.  
**Owner response:** `NOT_SELECTED`.

### OD-07 — Ledger evidence conflict U/X, late fills, stale snapshots

**Owner question.** How does V3 treat late fills, UNKNOWN outcomes, conflicting U/X evidence and gross risk reservations?

**Recommended provisional direction:** `PROVISIONAL_PREFER_CONSERVATIVE_UNKNOWN__DEFER_FULL_E4_POLICY`  
UNKNOWN remains unresolved; retain gross reservations; do not blindly resend, infer close, net offset or release capital without sufficient proof. This does NOT establish the complete E-4 conflict policy.

**What accepting that provisional direction means / costs.** Trading may remain blocked until credible broker reconciliation. Any unproven release could understate live exposure.

**Alternative or deferral.** Draft and independently verify narrower evidence-specific release/attribution rules and full late-fill U/X cases before G3.

**Still OPEN / not answered by a tick.** Full E-4 conflict and release matrix absent; exact stale-snapshot/late-fill resolution, attribution and release proof owner-open.

*Source anchors:* Master §3.3; EXT §4.2; Stage D03 OD-07; R2 final review.  
**Owner response:** `NOT_SELECTED`.

### OD-08 — Seven PARTIAL B-row contract/exclusion decision

**Owner question.** How should the seven source-indexed PARTIAL Batch B contracts be treated in a restricted offline freeze?

**Recommended provisional direction:** `PROVISIONAL_PREFER_TYPE_ONLY_WITH_EXPLICIT_PER_ROW_EXCLUSION`  
Carry purely structural schemas and negative validators into the proposed design, only where independently proven and consistent with the excluded modules. Do not describe any absent operational quote/anchor, broker observer, protection or alert implementation as built.

**What accepting that provisional direction means / costs.** Seven items require individual scope treatment in the controlled G0-R schedule; a type is not a proven operational capability.

**Alternative or deferral.** Exclude any particular row entirely from the restricted G0-R design, with source-linked reason; or select full route F with all required contracts.

**Still OPEN / not answered by a tick.** Each of seven rows needs explicit type-only versus exclusion disposition and evidence. No missing text is silently repaired by a tick.

*Source anchors:* V3-DC-04 Batch B item 5; EXT Annex B; BB-03 seven PARTIAL row mapping; Stage D03 OD-08.  
**Owner response:** `NOT_SELECTED`.

### OD-09 — WDA-08 §10 decisions 1, 3, 9

**Owner question.** How should the independent watchdog be structured, how is admission evidence treated, and which contract is canonical?

**Recommended provisional direction:** `PROVISIONAL_PREFER_INDEPENDENT_FAILURE_DOMAIN__NO_LATE_BACKDATE__WDA_CANONICAL_CANDIDATE`  
Propose a verified separate failure domain (WDA decision 1), require genuinely completed and timely supervision evidence and never back-credit late cycles (decision 3), and propose WDA-08 as the technical home with EXT pointing to an exact hash (decision 9).

**What accepting that provisional direction means / costs.** Additional independent deployment/proof, evidence-custody and contract-lineage work; no watchdog runtime at G1.

**Alternative or deferral.** Explicitly select a different evidenced separation level, supervised cycle/freshness policy or canonical text home; DEFER remains available.

**Still OPEN / not answered by a tick.** Failure-domain level, real roster, authority, freshness interval, signed cycles, independent WDA reviewer and controlled EXT/WDA alignment OPEN.

*Source anchors:* WDA-08 §10 decisions 1,3,9; EXT §4.5; Stage D03 OD-09.  
**Owner response:** `NOT_SELECTED`.

### OD-10 — Clock alternatives D1..E3 and operational timing

**Owner question.** Can G0-R retain six clock contracts while deferring unresolved operational endpoints and all numbers?

**Recommended provisional direction:** `PROVISIONAL_PREFER_EXPLICIT_G0R_OFFLINE_EXCLUSION_FOR_UNSELECTED_CLOCK_MEANINGS`  
Preserve typed D1/D2/D3/E1/E2/E3 schemas and negative tests, but make specific unresolved A/B/bracket/closed-market alternatives documented exclusions from restricted offline runtime. No numerical timer operates.

**What accepting that provisional direction means / costs.** Before G3, endpoints, trusted clock/source, pause conventions, actual deadlines, alert delivery/ACK and protective remedy must all be selected and proven.

**Alternative or deferral.** Select and review every operational endpoint and numeric policy ahead of G0; or DEFER the restricted freeze.

**Still OPEN / not answered by a tick.** D1 start bracket; D2 A/B/C and closed market; D3 alternative A/B; E1 A/B; E2 missing delivery/ACK; E3 episode/market pause; six numeric values UNSET.

*Source anchors:* EXT-G0R-14 §4.5; WDA-08 §7; BB-05 choice 12; Stage D03 OD-10.  
**Owner response:** `NOT_SELECTED`.

### OD-11 — Stop Resume, watchguard breaker reset authority

**Owner question.** Who can resume after local Stop or clear an automatic entry breaker?

**Recommended provisional direction:** `PROVISIONAL_PREFER_NO_AUTOMATIC_RESUME_OR_CLEAR`  
Keep local authenticated, persistent Stop as entry-only. Continue monitoring existing positions. No watchdog or restart may reset a breaker; future resume/reset must have its own authenticated and auditable permission and independent prerequisites.

**What accepting that provisional direction means / costs.** Entries may remain blocked pending owner-authorised recovery, which is intentional.

**Alternative or deferral.** Define a narrowly authorised resume/reset actor, evidence checks and distinct safety-latch semantics now.

**Still OPEN / not answered by a tick.** Human resumer, reset procedure, authenticator, audit proofs and separate protective controls OPEN; no broker control granted.

*Source anchors:* Master C-09; WDA-08 decisions 4, admission; BB-05 choice 8; Stage D03 OD-11.  
**Owner response:** `NOT_SELECTED`.

### OD-12 — Review/witness/custody and design-freeze hash control

**Owner question.** Who provides independent review, who witnesses/custodies the evidence, and what exact hash constitutes an accepted freeze?

**Recommended provisional direction:** `PROVISIONAL_PREFER_R1_CANDIDATE_ONLY__SEPARATE_APPOINTMENT_CUSTODY_HASH`  
Keep original R1 as a candidate reviewer, conditional on documented independence, scope, conflicts and appointment. Separately settle witness/custody and owner-fingerprint approval; the three decisions are NOT one automatic approval.

**What accepting that provisional direction means / costs.** Binding acceptance cannot proceed without the required independently evidenced reviewer and unwaived witness/custody obligations. R2 authored WDA-08 and is not its independent checker.

**Alternative or deferral.** Select another independently qualified reviewer; or controlled amendment of review terms if valid and approved. Custody/witness/hash controls require separate dispositions.

**Still OPEN / not answered by a tick.** A-06 reviewer identity and independence; witness/countersignature requirements K1/H13; external evidence copy/custodian; exact-source approval format all OPEN.

*Source anchors:* V3-BA-04 A-06; EXT §7/§8; master K1/H13 and R-01/R-10; WDA-08 §20; Stage D03 OD-12.  
**Owner response:** `NOT_SELECTED`.

### OD-13 — G1-only cooling-off placement

**Owner question.** Should the 48-hour wait be before G1 only, rather than at G0-R acceptance?

**Recommended provisional direction:** `PROVISIONAL_PREFER_G1_ONLY__SUBJECT_TO_CONTROLLED_GOV48_ADOPTION`  
Reaffirm your earlier provisional preference for a pre-G1 wait only. V3-GOV-48-01 REV3 is a proposal and is not adopted. R2's reconciliation review of it found five findings (RF-1 to RF-5), with 29 exact edits (F01 to F29) proposed; the author's fix round and one mechanical R2 replay are still pending.

**What accepting that provisional direction means / costs.** Until properly adopted the standing requirements still govern, including the applicable wait before substantive acceptance of the amendment itself. No timer starts on this decision sheet.

**Alternative or deferral.** Keep standing timing or separately select G0-R plus G1 wait through a controlled amendment.

**Still OPEN / not answered by a tick.** GOV-48 review, exact supersession, owner authority/approval and timing evidence OPEN.

*Source anchors:* 12 Nov owner provisional G1-only response; V3-GOV-48-01 REV3; Stage D03 OD-13.  
**Owner response:** `NOT_SELECTED`.

### OD-14 — Stage D ledger and three event type registration

**Owner question.** When may the three ledger-event contracts and seven-axis transition graph become a controlled effective registry?

**Recommended provisional direction:** `PROVISIONAL_PREFER_REGISTER_ONLY_AFTER_CONTROLLED_ALIGNMENT_AND_INDEPENDENT_CHECK`  
Use the 42-edge/84-denial/3-event candidate as proposed source material. First choose to append the seven master-derived edges (rather than supersede the master), align EXT Annex G and WDA §3.1 by controlled amendment, obtain independent review, then consider exact-hash owner acceptance. No runtime registration now.

**What accepting that provisional direction means / costs.** Extra source-change review, verified owner provenance and technical implementation proof remain; 187 tests are NOT_RUN.

**Alternative or deferral.** Exclude selected transitions or choose controlled supersession of the master, with rewritten proof obligations and explicit owner selection.

**Still OPEN / not answered by a tick.** Formal route (add 7 vs change master); WDA independent reviewer; effective registry IDs/signatures; multi-axis transaction_group_id/composite event and half-commit test before implementation; OD-14 OPEN.

*Source anchors:* Master §3.3; EXT Annex G; WDA §3.1; Stage D03 files 01–04,11–12; R2 final N12.  
**Owner response:** `NOT_SELECTED`.

## Critical owner-reading notes

### OD-01 — exact provisional R+C scope does not mean actual inclusion
The inherited first slice lists eight units: `effective_policy.py`, `intent_identity.py`, `state_ledger.py`, `audit_events.py`, `control_latches.py`, `calendar_completion.py`, `synthetic_observer.py` and `capability_guard.py + tests/offline`. EXT-G0R-14 proposes twelve additional offline units (`EXT-01`–`EXT-06`, `EXT-08`–`EXT-13`) as **candidate design scope**, while `EXT-07 offline_candidate_store.py` is explicitly excluded/reserved. `EXT-06` owns its three named allowlisted paths; `EXT-11` owns its two. All live quote/anchor, broker gateway, watchdog runtime, real alert delivery, real policy permits, model fitting/activation, external broker/customer data, and V2 live access stay excluded. Not part of this offline freeze, and not dropped: TP/SL calculation policy (D04 §4 item 1), the use of calibrated confidence for entry grading and stake sizing (D04 §4 item 5; monetary risk sits under OD-05), break-even and trailing activation, and every V3-originated broker stop modification, including stop tightening. Offline V3 cannot send orders, so these cannot run here; `adaptive_protection_required` stays `UNSELECTED` and V3EXT-070 denies. The owner's stated direction (nonbinding until selected) is that V3 keeps V2's confidence-based grading and adaptive trailing and improves on them; each is to be specified to at least V2's per-instrument behaviour, and decided with evidence, before G3. This module schedule is an **author-derived candidate**, not a selected owner freeze manifest. The full per-path map and 43/13/21 item treatment need controlled validation before any G0-R acceptance.

### OD-06 — an exposed position and no available operator
This is the most consequential safety decision. The current author lean is **not to empower V3 to repair, tighten, trail, cancel or close positions**, consistent with your provisional manual-IG preference. The watchdog can identify or raise concerns but cannot itself rescue exposure. Under the proposed manual-only operational fallback, an unprotected broker position remains at risk until you act on IG; if unreachable, there is no guaranteed remedy. At G1 no actual alert or emergency path exists at all. Even if OD-06's *offline* exclusion is selected, G3 requires a separately selected and evidenced `A/B/C` response, finite risk bound, stop type, incident runbook, independently evidenced delivery/escalation, unreachable-operator behaviour, closed-market policy and broker-proven outcome. Do not interpret `manual_only` as an approved G3 safety plan. D2/E3 are typed but all numerical clocks remain UNSET.

### OD-08 — seven PARTIAL source rows, each requiring a scope treatment

| Source row | What is missing or partial | Author's restricted-scope treatment candidate |
|---|---|---|
| `OC-D03-02` | Quote/anchor and post-fill price-geometry type not in EXT; real quote module excluded | Offline typed interface only or explicit exclusion; no price execution |
| `OC-D04-02` | IG executable-price-basis type/verification absent | Offline evidence type only or explicit exclusion; no executable pricing |
| `OC-D04-06` | Source event identity must remain stable across model/policy versions, but missing EXT rule/test | Version-independent identity contract and synthetic negative test |
| `OC-D04-08` | Source-run lineage and expired-signal event missing | Pure source-run/expiry schema and tests, no real-policy activation |
| `OC-D05-04` | Attribution of an IG manual close and pending UNKNOWN state insufficiently typed | Broker-evidence attribution schema; no inferred CLOSED or permission to act |
| `OC-D05-07` | Explicit guarantee that entry-denial does not stop open-position supervision missing in EXT | Invariant and fixture tests; no actual runtime watchdog granted |
| `OC-D05-09` | Explicit gross-exposure reservation/no unproven netting wording missing | Gross-reservation type/invariant plus negative oracles |

The above descriptions come from EXT Annex B and the Stage D/Batch B crosswalk. **Every row needs its own `TYPE_ONLY` or `EXCLUDED` status**, and any `TYPE_ONLY` choice remains subject to a controlled contract amendment and independent review. Do not claim that Stage D03 passing documentary checks completed these missing original-contract provisions.

### OD-09 — three WDA owner decisions inside one group
`WDA-08 §10 #1`: independently verified failure-domain level, with the actual separation level and infrastructure still OPEN.  
`WDA-08 §10 #3`: supervision admission must be positively proved; late cycles are not retroactively backdated; freshness duration and closure of `D06-FREEZE-02` remain OPEN.  
`WDA-08 §10 #9`: propose WDA-08 as canonical definition home; EXT points to one exact WDA fingerprint only after controlled adoption.  
Record these as separate clauses within OD-09; one tick cannot falsely close independent evidence or decide numbers.

### OD-10 — every clock's unresolved decision remains excluded, not chosen
- **D1:** credible exposure/loss bracket and earliest defensible start.
- **D2:** broker-proven restoration/closure, plus protection A/B/C and closed-market response.
- **D3:** independently authenticated escalation handoff (A) **versus** independently evidenced delivery (B).
- **E1:** evidenced delivery only (A) **versus** delivery or independent incident-bound human acknowledgement (B), at acknowledgement's actual time, never backdated.
- **E2:** starts only with independently evidenced alert delivery; otherwise NOT_STARTED, never PASS.
- **E3:** continuous unprotected exposure start/end, loss uncertainty, market closure pause/no-pause and episode segmentation.
All six numeric deadlines are `UNSET`; no A/B union is a default. Approval of a *documented offline-only exclusion* must itself be explicit.

### OD-12 — three independent governance selections, not a single reviewer tick
1. **A-06 review authority:** R1 may be a candidate if independently appointed and conflict/capability assessed. R2 authored WDA-08 and cannot independently approve his own WDA design. Reviewer is not automatically an independent signatory.
2. **Witness and custody:** who witnesses the controlled record, evidence retention, second copy outside the working area and standing K1/H13/two-person obligations must be resolved or lawfully amended rather than inferred from sole-operator status.
3. **Freeze/hash approval:** exact immutable contract file set, fingerprints, negative-capability manifest, signed attestations and owner explicit approval of the same byte set. A paper review of this sheet is not such approval.

### OD-14 — candidate registry is not an effective registry
Source graph: 35 EXT Annex G edges, four initial resting-entry exclusions. Proposed master alignment: append seven `D03-MST-036`–`042` edges covering intent/attempt axes, plus 25 denied pairs, totalling **42 candidates, 38 guarded, 84 denied, 122 pairs**. Three ledger event types remain unregistered. Formal adoption requires a selected controlled source alignment (EXT Annex G plus WDA-08 §3.1), a reviewer independent of the WDA author, source-level dispositions and exact fingerprinted owner acceptance. The 187 fixture tests are **NOT_RUN**, not execution proof. R2 non-blocking N12 further identifies a pre-implementation need for multi-axis atomic-commit correlation (`transaction_group_id` or composite event) and a half-commit test. R2 N10/N11 identify a fixture starting-state mismatch and non-discriminating excluded-edge mutations; they are not open R2 review findings but should remain in the later test-maintenance register.

## Template for one consolidated provisional owner response

> For War Rig V3 Stage D decisions OD-01 through OD-14, I provide **DESIGN_ONLY, NONBINDING** provisional directions, not binding source acceptance, effective ledger/event registration, implementation permission, G0-R freeze or a cooling-off start. My selections are listed below; any unselected ID remains OPEN.
>
> - OD-01: [PREFER_RECOMMENDATION / MODIFY / DEFER] — exact route/scope modifications: ____
> - OD-02: [PREFER_RECOMMENDATION / MODIFY / DEFER] — ____
> - OD-03: [PREFER_RECOMMENDATION / MODIFY / DEFER] — ____
> - OD-04: [PREFER_RECOMMENDATION / MODIFY / DEFER] — ____
> - OD-05: [PREFER_RECOMMENDATION / MODIFY / DEFER] — ____
> - OD-06: [PREFER_OFFLINE_EXCLUSION_ONLY / MODIFY / DEFER] — separately acknowledge that G3 protective response A/B/C stays OPEN and that V3 stop tightening or trailing stays disabled until separately decided: ____
> - OD-07: [PREFER_RECOMMENDATION / MODIFY / DEFER] — E-4 full conflict policy stays OPEN: ____
> - OD-08: [PREFER_PER_ROW_TYPE_ONLY_OR_EXCLUDE / MODIFY / DEFER] — enumerate all seven row treatments: ____
> - OD-09: [PREFER_RECOMMENDATION / MODIFY / DEFER] — separately record WDA #1/#3/#9: ____
> - OD-10: [PREFER_OFFLINE_EXCLUSION_ONLY / MODIFY / DEFER] — identify excluded alternatives: ____
> - OD-11: [PREFER_RECOMMENDATION / MODIFY / DEFER] — ____
> - OD-12: [PREFER_CANDIDATE_R1_ONLY / MODIFY / DEFER] — separately address independent reviewer; witness/custody; hash approval: ____
> - OD-13: [PREFER_PENDING_GOV_AMENDMENT / MODIFY / DEFER] — standing rule still governs: ____
> - OD-14: [PREFER_CONTROLLED_ADD_SEVEN_ROUTE / MODIFY / DEFER] — no effective registry or gate authority: ____

## Freeze/readiness blockers preserved

This document does not close any of the **43 binding owner dispositions**, **13 freeze findings/notes** or **21 repairs**, nor does it provide the 187 executable proof results, WDA independent review, an effective registry, finite G3 risk limits, six operational clock values, selected protection A/B/C, source amendment approval or a GOV-48 timing supersession. A G0-R freeze requires separate acceptance of an exact source fingerprint, explicit deferrals/negative capabilities and the standing independent-review and governance conditions. No review cycle of unchanged BB-04/BB-05 or Stage D01–D03 is requested.
