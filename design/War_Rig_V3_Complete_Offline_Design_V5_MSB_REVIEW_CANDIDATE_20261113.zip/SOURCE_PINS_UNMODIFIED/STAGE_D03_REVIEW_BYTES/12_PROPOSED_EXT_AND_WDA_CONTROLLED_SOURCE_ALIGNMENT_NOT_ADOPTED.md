# Stage D02 — controlled follow-on source alignment (PROPOSED, NOT ACCEPTED)

## Required predecessor reconciliation

Corrected V1.8 master §3.3 defines two independent axes beyond EXT-G0R-14 Annex G's five-axis ledger graph: `intent_lifecycle` and `attempt_send_eligibility`. Existing EXT-G0R-14 Annex C ledger registration and WDA-08 §3.3 already reference those master transitions. R2 D01-F1 identified the inconsistency.

## Proposed EXT-G0R-14 Annex G controlled change

Extend only the closed seven-axis *candidate* state graph: retain all 35 source edges unchanged by identity and source pair, append D03-MST-036 through D03-MST-042 exactly as shown in `11_HUMAN_REVIEW_7_MASTER_EDGES.md`; expand the negative complement by 25 disallowed pairs, retaining the 59 original negatives. Result: 122 pairs = 38 guarded + 84 denied (including four excluded V3-created resting-entry edges). No broker authority, working orders or numerical parameters are granted.

## Proposed WDA-08 §3.1 controlled change

Extend the ledger `axis` finite vocabulary from five names to those five plus `intent_lifecycle` and `attempt_send_eligibility`. Retain the actor, actor_authority, stream, writer, atomicity, evidence and hash-chain requirements; accept no producer label outside EXT Annex D. Preserve WDA-08 as source untouched until separate independent review and owner acceptance.

## Required gate control

This file is a proposed change impact record, not a source redline accepted into EXT or WDA. It is not evidence of an independent checker (R2 designed WDA-08), a release signature, a registered event/edge, a runtime transition, G0 or G1 authority. The explicit owner route selection (add the master rows or controlled supersession of the master) remains OPEN; author has prepared Route (i) as R2 recommended, without owner selection.
