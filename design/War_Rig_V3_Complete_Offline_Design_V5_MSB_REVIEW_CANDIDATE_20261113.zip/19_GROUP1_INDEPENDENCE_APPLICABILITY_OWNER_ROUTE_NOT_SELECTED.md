# Group 1 independent-review/quorum applicability and CAR-01 — owner route NOT_SELECTED

**Primary controlling source:** `SOURCE_PINS_UNMODIFIED/GROUP1_PRINCIPLES_UNCHANGED.md`, principle 5 and named CAR-01 section, historically approved source hash `be6dad1f3247cf882a1912e91bc67c979e0f605d03ece1f3dcfb424d2d132e15`. The controlling text keeps independent reviewer/quorum standards, live-release/deployment two-person requirements and K1/H13 signatures/countersignatures; sole ownership by itself does **not** waive them. The original V32 clause-level acceptance document is not included here. Accordingly this table **cannot** establish which listed requirements are inapplicable to offline G0-R/G1-R. Missing original clause evidence is an explicit blocker, not a waiver.

| Existing control | Applicable to offline design/G1? | Evidence needed before final sitting | Disposition now |
|---|---|---|---|
| Independent architecture review and reviewer/quorum standard (V32) | UNKNOWN pending V32 source-clause crosswalk | Exact V32 clause, parties, conflict check, human review record and sign-off | OPEN; no AI self-certification |
| Independent WDA-08 and ATC-01 review | Presumed required under Group 1 and master, pending exact role crosswalk | Named independent reviewer(s), conflicts disclosure, scope, work product and actual attestation | OPEN; R2 is author, not independent reviewer of those items |
| K1 and H13 owner signatures / independent countersignatures | UNKNOWN for offline scope; no automatic exemption | Exact binding K1/H13 clauses, applicability decision, signatures or valid successor | OPEN |
| Live release signing and two-person deployment records | Explicitly LIVE-controlled; offline applicability unproven | Source clause stating stage and release type; live protections remain in force | OPEN for applicability; no LIVE permission |
| Witness, external-custody copy and independent fingerprint attestation | Required as design-fingerprint/custody proof under current Group 1 procedure, subject to exact accepted contract | Named custodian, external hash-verified copy, time, audit proof | NOT ATTESTED |
| CAR-01 controlled alternative | Not yet approved | Clause-by-clause replacement schedule, fingerprints, valid approval under standing rules | NOT_SELECTED |

**Exactly one owner route to resolve within this same group (do not choose for the owner):**

- **A — Existing humans:** appoint qualified real independent human reviewer/witness/countersigners sufficient for every *applicable* original control; provide clause crosswalk, signed proof and custody. A single witness does **not** automatically replace multiple mandated independent roles.
- **B — CAR-01 within this group:** independently evidence, reconcile and explicitly approve each proposed replacement and preserved control via the standing accepted route. The amendment cannot make itself effective retroactively or bypass the approval rules governing its own adoption.
- **C — Verified nonapplicability:** cite source-exact V32, K1, H13 and master clauses proving each supposedly nonapplicable rule truly does not cover offline design/G1. Merely calling it 'offline' or 'single-owner' is insufficient.

**Selection:** `UNSELECTED`. **Real reviewer(s):** `UNAPPOINTED`. **Witness/countersign:** `UNASSIGNED`. **External custody:** `NOT_ATTESTED`. **V32 source bytes/crosswalk:** `NOT_ATTACHED`. This table documents a gate within one stage, not a new design-review stage.
