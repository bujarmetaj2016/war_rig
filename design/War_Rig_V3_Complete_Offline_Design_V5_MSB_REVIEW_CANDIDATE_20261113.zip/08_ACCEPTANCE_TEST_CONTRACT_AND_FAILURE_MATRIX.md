# Offline-core acceptance and adapter conformance test contract (NOT_RUN)

**Status:** all tests here are design specifications; no software implementation, simulated trade, IG call, market backtest or failure injection has been executed by this deliverable. Historic Stage D03 has 187 synthetic specifications, not 187 passing tests. Link them under controlled review; do not replace or silently renumber them.

## Pre-registered result fields

Each executed case must record `case_id`, environment/build SHA, fixture-policy SHA, simulator version, signed source-event ID, account-scope (synthetic), initial state, injected failure, expected and observed state/evidence, resulting ledger-event IDs, requested and applied stop, writer fence, no-IG-import/egress result, source hashes, pass/fail and reviewer.

| Family | Required cases | Pass oracle |
|---|---|---|
| TC-DATA | forming bar, missing macro, stale bar, DST, no-price, market closed | no eligible trade without fresh completed fixture input |
| TC-MODEL | wrong model hash, missing calibration artifact, unapproved refit, source-version collision; and the 19 cases MSB-01..MSB-19 of file 24 (intake gates, hostile pickle, static import scan, unavailable model, registration under a frozen contract, source identity, labelling, no cross-substitution) | no eligible new entry; no duplicate intent after model rerun; NO_AUTHORITATIVE_PREDICTION on any gate failure |
| TC-CONF | mislabeled score, side-specific short absent, lower-bound vs point-estimate, drift, positive/negative net realised R-by-band | no unjustified confidence tier; safe denial |
| TC-STRAT | missing executable-side bid/ask, reference-close discrepancy, wrong-side stop, GBPUSD limit-market conversion, US500 side absent | deny invalid geometry or unsupported strategy, while independently allowing valid fixture scenario |
| TC-RISK | below-minimum stake, FX conversion mismatch, simultaneous pending exposure, unsupported netting, breaker trip, missing capital | deny or conservatively reserve, no uplift or fictitious capital |
| TC-ENGINE | prewire crash, one-attempt rule, duplicate event, true distinct event, journal failure, close/fill race | single attempt per intent, UNKNOWN stays reserved, atomic ledger |
| TC-SIM | rejection, UNKNOWN despite execution, delayed read, partial fill/close, external widen, wrong account, stale quote | simulator reflects ambiguous evidence; cannot claim VERIFIED without proof |
| TC-INIT | accepted-but-not-filled, partial/full fill before protection read-back, absent/rejected initial stop, uncertain stop outcome, crash or audit failure, quantity/stop mismatch | protection never `PROTECTION_VERIFIED` before authoritative applied-stop and quantity proof; full reservation and alerts on uncertainty (TC-INIT-01..10) |
| TC-ATC | V2 reference tiers, DV1–DV4 safety divergences, C1–C4 compute-only candidate, BE/trail, failed stop readback, no retry | tighten only; reference parity exact on pinned inputs and every safe divergence logged; no IG writes |
| TC-RECON | lost ack then fill, duplicate fill, partial snapshot, unknown close P&L, late terminal evidence | reconciliation never promotes silence/timeout to rejection or closure |
| TC-STATE | seven-axis transitions, 42 edges/84 denied complements, atomic multi-axis failure, STOP persistence, blackout alert | no partial commit, no false delivered/acknowledged or reset, all invalid edges denied |
| TC-AUDIT | disk full before simulated stop move, malformed actor ID, tamper, stale heartbeat, skipped completed-cycle proof | no unaudited mutation; watchdog cannot self-attest; evidence preserved |
| TC-COMP | V2/V3 observation pairing, censored trade, stop earlier than theoretical TP, spread/contract mismatch, lookahead attempt | no fabricated realised result or falsely comparable cohort |
| TC-ISOLATION | direct IG hostname/DNS/IP/redirect/socket/stream, nested archive secret, unsafe path, unpinned mirror/lockfile | real network denied, secret intake quarantined, zero broker/credential imports |
| TC-INSTR | missing, extra or wrong-typed definition field; T3 value overriding a T2/T1 check; unmanifested or dynamically discovered plug-in; stale or uncertified listing; second synthetic instrument added by definition plus fixture only; synthetic equity of 1,000, 10,000 and larger with a below-minimum stake | unknown field or check denies entry; zero source and zero manifest change for the second instrument (`V3EXT-001` to `V3EXT-011`); no hard-coded instrument and no hard-coded minimum equity |

## Initial protection acceptance oracles — TC-INIT (all NOT_RUN)

| ID | Deterministic fixture event trace | Required oracle |
|---|---|---|
| TC-INIT-01 | Entry intended with missing/unsupported protected-fill capability | `DENY_PRE_ENTRY`; no fill or position; no unguarded entry intent sent |
| TC-INIT-02 | Market request ACCEPTED but no fill or independent stop read-back | Order acceptance only; NOT OPEN/VERIFIED; reservation remains until authoritative terminal evidence |
| TC-INIT-03 | First partial fill with requested stop but no read-back | position `OPEN_CONFIRMED`, protection `PROTECTION_UNVERIFIED`, reserve filled and possible unfilled risk, freeze trailing/next entry, incident/alert |
| TC-INIT-04 | Full or partial fill followed by matching account/position/quantity/stop proof | `PROTECTION_VERIFIED` only after proof; position exposure remains reserved; correct protection version |
| TC-INIT-05 | Filled position with stop rejected, absent, wrong-side or worse than last verified stop | Never VERIFIED; no blind retry; preserve gross reserve; freeze trailing, alert |
| TC-INIT-06 | Stop amendment returns UNKNOWN but was secretly applied; snapshot incomplete/late | Remain UNKNOWN until attempt-specific authoritative read-back; no second send of same intent |
| TC-INIT-07 | Crash, audit disk-full, or restart between fill and protection read-back | Restore pending/UNKNOWN with exposure; fail closed; no fictitious rollback, no automated repair |
| TC-INIT-08 | Partial close/fill/stop-update race with duplicate, conflicting or reordered events | Atomic seven-axis transitions or DENIED; correct open quantity; never overwrite later verified stop with stale evidence |
| TC-INIT-09 | Latest position read shows a smaller/larger quantity than stop covered | Protection unverified; gross exposure retained and no further trailing until authoritative revalidation |
| TC-INIT-10 | Explicit fixture-only rescue simulation of absent stop | No real IG authority, no implicit emergency close; test response selected fixture only and separately audited |

The 187 detailed Stage D03 test specifications and ledger sources are included as immutable bytes under `SOURCE_PINS_UNMODIFIED/STAGE_D03_REVIEW_BYTES/`; this table is additive and does not claim any of them has executed.

## The single two-adapter suite

For every common broker operation defined in `03_...`, implement the same deterministic contract checks with a simulator adapter and with a future IG adapter. Offline runs execute **simulator only**; the IG conformance plan is frozen as tests but actual IG execution remains separately gated. Broker-specific unavailable semantics must be marked NOT_PROVEN, not mocked as an IG guarantee.

## Go/no-go test disposition

A test failure involving financial exposure uncertainty, intent retries, stop truth, audit integrity, external egress, account scope, confirmed close, atomic state or source provenance is safety-blocking for the affected release. Statistical tuning, sample sufficiency and policy-value choices can be parameterized and recorded at the correct gate, provided the build cannot accidentally enable an unselected real-money policy.
