# G1-R: separate full offline-core implementation grant — BLANK / UNSIGNED

**May be signed in the same sitting as G0-R, but it is a distinct approval record.** The full 48-hour grouped wait and independent checks must already be valid and G0-R must have been signed first. Implementation never starts merely because the interval ended.

- Exact same final group root SHA-256 used for G0-R: `________________`
- Executed G0-R acceptance ID, SHA-256 and timestamp: `________________`
- Approved full 18-row offline module/build scope and manifest hash: `________________`
- Signed environment/build deny-egress policy hash and actual egress-negative-test evidence: `________________`
- Quarantine/secret-scan outcome and custody evidence hashes: `________________`
- No-IG-import, no-V2-runtime, zero-V2-source-bytes and dependency graph evidence hashes: `________________`
- Pinned package mirror/lockfile hashes (or signed no-mirror policy): `________________`
- Complete simulator shared contract-test manifest and negative test IDs: `________________`
- Named implementation operators, permission boundaries and handoff safeguards: `________________`
- Independent verification, quorum, witness/custody and K1/H13 proof: `________________`
- Cooling-off start/end UTC and restart-free elapsed 48h evidence: `________________`
- Confirmation: NO real IG credential/account/API/session/stream; NO actual IG write or login; NO production V2 filesystem change; NO DEMO/LIVE: `[CONFIRM]`

**Proposed owner grant text (NOT spoken or selected):**

> I grant G1-R offline implementation **only** of the complete V3 broker-independent trading core defined by the exact hashes above, using signed simulated fixtures and a network-denied, no-IG environment. This includes the offline simulator, market data, prediction from two sources under the MS-B contract of file 24 (signed test scores for pipeline validation; owner-registered non-executable trained models, none of which is registered at presentation; no model is fitted or promoted), confidence, TP/SL, risk, simulated order/position lifecycle, adaptive trailing, reconciliation, audit, watchdog, dashboard and comparison tests. This grant excludes real IG operations, V2 production changes and DEMO/LIVE authority. The corresponding G0-R design acceptance is separately signed; the 48-hour group interval and all prerequisite human and technical evidence have been verified.

Owner identity/signature: `________`  UTC: `________`  Witness/countersignature: `________`.

**Current state: NOT_SELECTED / NOT_SIGNED / NO IMPLEMENTATION AUTHORITY.**
