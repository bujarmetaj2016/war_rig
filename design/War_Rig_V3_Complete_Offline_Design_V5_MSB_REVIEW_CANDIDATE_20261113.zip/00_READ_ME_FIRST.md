# War Rig V3 — one consolidated offline-core design acceptance / G1-R grant candidate

**Artifact ID:** `V3-ONE-STAGE-OFFLINE-CORE-CANDIDATE-20261113-V5`  
**Status:** `DESIGN_ONLY / PROPOSAL_FOR_SINGLE_OWNER_SITTING / NO_OWNER_SELECTION / NOT_INDEPENDENTLY_VERIFIED / NOT_FROZEN / NO_48H_CLOCK / NO_G1_AUTHORITY`.

## Meaning

One **consolidated owner stage** contains (a) independently verified final offline trading design, (b) one 48-hour evidence-bound group interval, (c) **two separate, exact-hash records signed in the same owner sitting**—G0-R design acceptance and G1-R implementation grant—and (d) implementation **only after** the G1-R record is actually signed. Do not treat the stage as an automatic grant. No IG integration, credentials, login, deals or V2 runtime modification is in scope.

**Scope selection candidate:** Master Option R + EXT-G0R-14 §1.1 Option C—**complete broker-neutral offline trading**, implemented in controlled slices under one final authority, with fixture-policy simulated dealing. This is a *candidate*; a proposal cannot sign itself. The original master §3.1A eight-unit G1R slice is expressly insufficient for full offline trading and requires controlled scope amendment. All 16 original design modules are mapped in `02_...csv`, with two named additional offline modules. The IG-facing mutation gateway stays excluded.

**ATC-01:** Confidence-grade/trade sizing/breakeven/adaptive trailing are core requirements, not deferred out of the offline simulator. ATC-01 revision 2 provides four candidate improvements and four owner decisions J1–J4, none selected. The offline manager can simulate stop modifications in a *simulation-only* mode. No real broker writes.

## Contents and sequence

- `01_...md` — full 13-component core baseline; `02_...csv` — 18-module mapping.
- `03_...md` — broker-neutral simulator/interface contract; `04_...md` — controlled source reconciliation schedule.
- `05_...csv` — all 61 owner rows: 14 Stage D + 4 ATC + 43 master; every row OPEN/NOT_SELECTED.
- `06_...csv`, `07_...csv` — 13 freeze findings and 21 repairs, preserved OPEN for controlled disposition.
- `08_...md` — test contract and offline failure injection; `09_...csv` — G1-R evidence inventory (actual results not claimed).
- `10_...md` — governance table/group timing; `11_...md` — independent review record, **unsigned**.
- `12_...md` — G0-R acceptance form, **unsigned**; `13_...md` — G1-R grant form, **unsigned**.
- `14_...json` — grouped cooling-off status: **NOT_STARTED**.
- `15_...md` — blockers/remaining work; `16_...json` — source-chain/provenance.
- `17_...csv` — crosswalk of the eight original units and `EXT-01` to `EXT-13` to the 18 modules and 13 components; `18_...csv` — disposition class of each of the 43 master rows, the 13 findings and the 21 repairs.
- `19_...md` — Group 1 independence applicability and the owner's three routes (none selected); `20_...md` — explanatory table of the source-amendment proposals (not adopted); `21_...md` — merged review finding disposition; `22_...md` — primary-evidence hashes; `23_...csv` — the **exact old and new text of the fourteen controlled source amendments (AM-01..AM-14), the controlling form** (not adopted until the owner signs G0-R); `24_...md` — MS-B dual-source prediction contract with 19 tests (proposed, not selected); `25_...csv` — evidence on the model files that exist today.
- `SOURCE_PINS_UNMODIFIED/` — fingerprinted copies of source proposals/reviews, never amended in place.
- `MANIFEST_SHA256.json` — SHA256 for every member other than the manifest; the containing ZIP hash is reported separately.

## Readiness is not permission

This is a **substantive consolidated candidate**, not a claim that all safety, reviewer, custody or G1-R environmental evidence is complete. Do **not** present it as the *last/final evidence-bound group* or start the 48-hour interval until all items in `15_READINESS_BLOCKERS_AND_UNSET_VALUES.md` are satisfied, all decisions explicitly disposed, all final proposal bytes and evidence locked, independently checked, and the final-group hashes presented together. A revision changes the group's fingerprint and, if a group clock has started, restarts the entire indivisible group under the reported 27-Oct rule.

**Historical evidence caution:** The local historical cooling-off `PENDING_V1` file is *not* the subsequently approved 48-hour decision; it is not included as a controlling source. The approved decision is attached byte for byte as `SOURCE_PINS_UNMODIFIED/A39_GROUP1_COOLING_OFF_OWNER_DECISION_V2.json` (SHA-256 `d3f39baa27d8a8c91050d19dea32d83883b73eb1ddb80cf4d89dcfbee534143b`, re-computed from its bytes by R2 on 13 Nov 2026). Owner reply, verbatim: "Cooling-off duration: 48 hours. I accept rules (a) and (b) as written." Rule (a): one interval covers proposals presented together once the full group, every final proposal, its evidence and each SHA-256 are fixed, and it starts after the last final evidence-bound presentation. Rule (b): a change to proposal text, evidence-bound scope or SHA-256 restarts the clock, and for an indivisible group it restarts the whole group clock.

**Precedence over the pinned Group 1 addendum:** `SOURCE_PINS_UNMODIFIED/GROUP1_V2_ADDENDUM_UNCHANGED.json` was written before the owner's decision and still records `cooling_off_duration: UNSET`. The owner's 27 Oct decision (`d3f39baa…`, 48 hours) supersedes that statement for duration only; no other statement in the addendum changes.

**V3-GOV-48-01:** retained as an unadopted alternative; not incorporated or treated as an effective replacement. No other stage is invented by this candidate. G2/G3/G4 external broker/use gates stay separately controlled in future when needed; they are outside this one offline implementation grant.

## Consolidated review correction round (13 Nov 2026)

R2 B1–B7/C1 edits, source pins and 27 October decision are incorporated. A second documentary review identified F01–F07; this revision adds explicit initial-stop protection contract and test oracles, fixes inconsistent offline modules, supplies the Stage D03 primary spec and 187 detailed unexecuted cases, and corrects clock metadata. See `21_MERGED_REVIEW_FINDING_DISPOSITION.md`. All such corrections are **design-only and nonbinding**; no human independent review, build, test execution, cooling-off or owner signature is claimed.

**Important boundary:** the model *interface, confidence pipeline and simulated signals* are in offline G1 candidate scope, while prediction sources are governed by the proposed MS-B dual-source contract (`24_...md`, `25_...csv`): signed test scores validate the pipeline, owner-registered non-executable trained models may be read once registered, no model is fitted or promoted, and at presentation all five Core-5 trained models are recorded UNAVAILABLE for offline serving, because no registered frozen Core-5 artifact was identified in the inspected locations and the V2 inference code that R2 holds trains afresh on each run (this is not proof that no model exists elsewhere). This is not a claim of a fully integrated trained-model trading runtime.

New review files: `17_EXT_AND_ORIGINAL_UNIT_CROSSWALK.csv`, `18_REGISTER_DISPOSITION_CLASSES.csv`, `19_GROUP1_INDEPENDENCE_APPLICABILITY_OWNER_ROUTE_NOT_SELECTED.md`, `20_CONTROLLED_SOURCE_SUPERSESSION_PROPOSAL_NOT_ADOPTED.md`, `21_MERGED_REVIEW_FINDING_DISPOSITION.md`, `22_PRIMARY_EVIDENCE_MOUNT_AND_CONTENT_SHA256.md`, `23_CONTROLLED_AMENDMENT_EXACT_TEXT.csv`, `24_MSB_CONTROLLED_DUAL_SOURCE_PREDICTIONS_CONTRACT.md`, `25_MODEL_ARTIFACT_EVIDENCE_EC2_20261113.csv`; primary bytes under `SOURCE_PINS_UNMODIFIED/STAGE_D03_REVIEW_BYTES/`.
