# MS-B — CONTROLLED_DUAL_SOURCE_PREDICTIONS / NO_REFIT (PROPOSED, NOT SELECTED, NOT APPLIED)

**Status:** proposal text for the owner sitting. Nothing here is adopted until the owner signs the G0-R record against the final group root. It selects no model cadence, authorises no fitting and approves no model. The exact source amendments it needs are AM-10..AM-14 in `23_CONTROLLED_AMENDMENT_EXACT_TEXT.csv`; the evidence about the models that exist today is in `25_MODEL_ARTIFACT_EVIDENCE_EC2_20261113.csv`.

## 1. In plain words

- V3 has **two ways to produce a prediction, and both are built from the start**: (1) **signed test scores**, fixed and fingerprinted numbers that prove the machinery (sizing, TP/SL, trailing, simulated trades) works; (2) **actual trained models**, finished model files that the owner has registered and that V3 may only read.
- Both feed **one prediction contract** (`SignalScore`, section 4). Every prediction and every simulated trade says which source it came from and carries that source's fingerprint.
- Test scores are never shown as model predictions and never used as evidence of trading performance.
- A trained model is usable only if the owner has registered it, its fingerprint matches, its format cannot run code when opened, and every gate in section 9 passes. If a gate fails, or no model exists, that instrument gets **no prediction**. V3 never quietly switches to test scores, to an older file or to a freshly trained model.
- No registered, frozen Core-5 model was found. The owner's inventory (one host; `/home/ubuntu`, `/opt`, `/srv`) found no Core-5 model file, and V2's code trains its main signal model again on every run and throws it away (section 13). So at presentation all five Core-5 models are recorded **UNAVAILABLE** for offline serving. That is a serving classification, not proof that no model exists anywhere; S3 and other hosts were not inventoried. Making one is a fitting action; this selection does not authorise it, and it is done outside V3 (section 12).
- The contract and its 19 tests are fixed in the group. Real models are registered afterwards, one at a time, under the frozen contract. They are not group members and do not restart the 48-hour clock.

## 2. What MS-B authorises, exactly

- **M1.** Source A, `SIGNED_TEST_SCORE`: a signed, hash-registered, deterministic test-score set (a pure scoring function registered in the EXT section 2.3 plug-in manifest, or a score table inside a signed fixture snapshot). It reads no model file and no network.
- **M2.** Source B, `TRAINED_MODEL`: one module, `v3/offline/model_intake.py`, verifies and evaluates owner-registered artifacts. It is registered in the same plug-in manifest; manifest capabilities restrict and never enable.
- **M3.** Both sources return the same `SignalScore` record to the strategy evaluator `EXT-04` (which keeps no loader) and on to the OfflineBrokerSimulator. Both are part of the initial offline implementation.
- **M4.** The input to either source is a signed feature row produced from the signed snapshots of `SourceSnapshotLoader` (file 02, row 1). Whether a snapshot may be real historical market data is decided by that row and by EXT section 4.1. MS-B does not grant it.

## 3. What MS-B does not authorise

- **N1.** Fitting, re-fitting, calibration fitting, just-in-time training or any other training, anywhere in G1-R or V3. (The A0.10 proposal `A010-ARCH-D017-v22` has a just-in-time mode and a machine authoriser; neither is borrowed.)
- **N2.** Promotion, or activation for live use. `promoted_for_live` must be false on every registered artifact. The serving state in section 8 means "may drive the offline simulator" and nothing more.
- **N3.** Any IG, broker, network or credential path (EXT section 1.2, AM-01).
- **N4.** Any V2 code, V2 database or V2 live-cohort read. `G1R-08-X` stays absolute. V3EXT-025 changes only for converted model data (AM-12). V3EXT-027 is unchanged because a model artifact is data, not source.
- **N5.** Selection of a model cadence. `OC-D04-04` stays `DEFER`. D04 option B (controlled re-fitting) stays unselected. With no refit allowed, the offline build behaves like a retained-frozen model; that is not a selection of option A as the live policy.
- **N6.** Pickle, joblib, dill, cloudpickle, marshal, shelve, `numpy.load` with `allow_pickle`, or any format that runs code when opened, anywhere in G1-R.
- **N7.** Any new route for V2 history. V2 recorded signals and outcomes enter only as the immutable, quarantined, independently pinned V2 snapshot that `ComparisonEvaluator` already admits (file 02, TC-COMP). A replay from V2 recorded signals can compare trailing behaviour without loading a model; it cannot prove trained-model inference parity.

## 4. The common prediction contract (`SignalScore`)

Every `SignalScore` carries these fields, whichever source produced it.

- **S-1** `source_kind`: `SIGNED_TEST_SCORE` or `TRAINED_MODEL`. It is set by the source module, never by the caller. The run manifest declares which source each instrument uses in that run, and the declaration cannot change mid-run.
- **S-2** `source_fingerprint`: the sha256 of the signed test-score set, or of the registered model manifest.
- **S-3** Feature lineage: `feature_row_sha256`, the source snapshot id and hash, and the bar range. For `TRAINED_MODEL` also the feature-schema hash.
- **S-4** `evidence_class`: `PIPELINE_VALIDATION_ONLY` for `SIGNED_TEST_SCORE`; `OFFLINE_MODEL_BEHAVIOUR` for `TRAINED_MODEL`. Neither is live trading-performance evidence (EXT section 4.1).
- **S-5** Direction, raw score, calibrated probability, confidence grade, policy hash and run-manifest hash, as the strategy evaluator already requires.
- **S-6** Every simulated order, position, trade outcome and audit event carries the `prediction_id`, so its source and fingerprint can be read back.
- **S-7** Reports are grouped by `source_kind` and never pooled. Any figure from a `SIGNED_TEST_SCORE` run is stamped `NOT_PERFORMANCE_EVIDENCE` and `NOT_A_MODEL_PREDICTION`. Any figure from a `TRAINED_MODEL` run is stamped `OFFLINE_SIMULATED_MODEL_BEHAVIOUR`, and its report says in words that it shows offline historical or simulated model behaviour and is not verified forward or live trading performance. No offline figure is relabelled as forward or live evidence. A forward-demo evidence class is not created here, because no forward path exists in this scope.
- **S-8** No cross-substitution. A `TRAINED_MODEL` source that fails a gate or has no authorised artifact returns `NO_AUTHORITATIVE_PREDICTION` and is never replaced by a test score, a latest or previous model, or a refit. A `SIGNED_TEST_SCORE` prediction can never carry a model label.

## 5. Signed test-score rules (source A)

- **F-1** The set is registered by hash in the plug-in manifest or sits in a signed fixture snapshot whose hash is checked at load.
- **F-2** Same input, same bytes out.
- **F-3** It opens no model file and no network; it cannot be mistaken for a model by its record (S-1, S-4).
- **F-4** A tampered, unsigned or unregistered test-score set returns `NOT_PROVEN`.

## 6. Allowed model artifact formats (allow-list; anything else is rejected before it is parsed)

| Code | Artifact | Allowed form | Notes |
|---|---|---|---|
| AF-1 | Model | XGBoost native JSON, `gbtree` booster only | objective limited to `binary:logistic` or `reg:squarederror`; any other objective is a contract change |
| AF-2 | Scaler | JSON of named numeric arrays | method `ROBUST` or `STANDARD`; columns listed |
| AF-3 | Calibration | JSON of numeric parameters | method `PLATT` or `ISOTONIC_STEP`; or `NONE_DECLARED` |
| AF-4 | Feature schema | JSON list of ordered column names, dtypes and the missing-value rule | its hash is in the manifest |
| AF-5 | Manifest | JSON, fields of section 7 | its hash is the registered identity of the set |

The evaluator is a pure in-repo tree-ensemble evaluator using the standard-library `json` module with strict parsing (non-finite constants rejected). No `xgboost`, `sklearn`, `joblib` or `pickle` package is imported anywhere in G1-R, so no fit implementation is even present in the process.

## 7. Model manifest fields (all required; `UNKNOWN` may be recorded but yields NOT_PROVEN)

`model_set_id`; `instrument_scope` (Gold, GER40, US500, EURUSD, GBPUSD, or `NONE_NOT_CORE5`); `role` (`SIGNAL_SCORE`, `EXECUTION_FILTER_SKIP`, `EXECUTION_FILTER_R`, `SHADOW_ONLY`); `objective`; `files` (name, format code, sha256, bytes); `feature_schema_sha256`; `scaler_sha256` or `NONE_DECLARED`; `calibration_sha256` or `NONE_DECLARED`; `calibration_required`; `training_snapshot_sha256_and_bar_range`; `fit_procedure_code_sha256`; `producer_environment_identity`; `conversion_record_sha256`; `state`; `promoted_for_live`; `authorisation` (owner signature reference, scope `OFFLINE_SIMULATOR_ONLY`, finite `valid_until`, runtime profile); `registered_utc`.

The conversion record holds the source artifact's sha256 before and after conversion, the converter's code hash, the golden-vector reference hash, the number of golden vectors and the registered parity tolerance. The tolerance is a recorded parameter, UNSET in this contract. Zero is not assumed, because float32 accumulation may differ between the original library and the in-repo evaluator. A conversion record with no registered, justified tolerance cannot reach `VALIDATED`, so that set can never become serving.

## 8. Model states

`CREATED_UNREGISTERED` -> `REGISTERED_IMMUTABLE` -> `VALIDATED` -> `SERVING_AUTHORIZED_OFFLINE_ONLY`; also `SERVING_SUSPENDED`, `REVOKED`, `RETIRED`. The names follow the A0.10 OQ-006 proposal (SHA-256 `1b397d2f…5abb`, R2 copy V22), which is itself `PROPOSED_PENDING_REVIEW`; no authority is claimed from it. Each transition is an owner-signed record. There is no machine authoriser in G1-R.

## 9. Model gates at load (all must pass; any failure returns `NO_AUTHORITATIVE_PREDICTION` and no new entry)

- **G-1** the manifest hash equals the registered manifest hash.
- **G-2** every listed file exists and its sha256 equals the manifest; no unlisted file is in the artifact directory; no directory scanning.
- **G-3** every file is one of AF-1..AF-5 and parses as strict JSON.
- **G-4** the input row equals the feature schema: names, order, dtypes, count.
- **G-5** a declared-required calibration artifact is present with the declared hash.
- **G-6** `instrument_scope` and `role` equal the request.
- **G-7** state is `SERVING_AUTHORIZED_OFFLINE_ONLY` and `valid_until` has not passed on the run clock declared in the run manifest.
- **G-8** `promoted_for_live` is false.
- **G-9** the runtime profile equals the registered profile.
- **G-10** the output is finite and inside its declared domain; it is never clipped or repaired.
- **G-11** identical input and identical artifact give byte-identical output.

## 10. Conversion and registration happen outside G1-R

- **C-1** An existing `.pkl` or `.joblib` file is converted once, in a separate trusted, isolated environment that is not G1-R and not V3: no network, read-only source mount, owner-produced files only, source sha256 recorded before and after.
- **C-2** Opening a pickle or joblib file runs code. That is acceptable only in that environment and only for a file the owner produced, whose hash was recorded in an earlier inventory. It is never done inside V3.
- **C-3** The converter is a recorded, hashed tool. It writes only AF-1..AF-5 files and a parity record on golden vectors. The golden vectors cover the whole inference path in one pass, from the raw signed feature row through feature ordering and the missing-value rule, the scaler, tree traversal and the calibration to the final probability, and are compared with the original library's output for the same rows. A parity check of the tree output alone is not enough.
- **C-4** The set then enters G1-R through the EXT section 7.1 intake quarantine: hash match, format scan, no nested or hidden members, no traversal or symlink, canary scan.
- **C-5** The owner registers the set by signing its manifest hash.

## 11. Registration after the freeze

As in EXT section 3, where new dated listings do not change the family digest (V3EXT-003, V3EXT-032), a registered artifact is separate from the contract. The contract, the 19 tests, a signed test-score set and a synthetic test model are in the group. Each real registration is a separate signed record carrying its own conversion, parity and quarantine evidence. It does not change the contract digest or the group root. A registration that needs a new format, objective or gate is a contract change and restarts the group clock by rule (b).

## 12. Making a model (fit-and-freeze) is not MS-B

Producing a new model, including a one-time freeze of a Core-5 model, is a fitting action. EXT section 4.1 requires a separately named, fingerprinted, credential-free research/data authorisation that specifies input manifests, quarantine, model-fit permissions, outputs, retention, no network and exact negative tests. Call it **MS-F**. MS-F is not selected, not in this package, and not performed inside G1-R or V3. A model it produces is registered through sections 10 and 11 like any other.

## 13. Status at presentation and the evidence behind it

| Instrument or file set | Role | Status at presentation |
|---|---|---|
| Gold | SIGNAL_SCORE | TRAINED_MODEL source UNAVAILABLE: no registered frozen artifact identified in the inspected locations |
| GER40 | SIGNAL_SCORE | TRAINED_MODEL source UNAVAILABLE: no registered frozen artifact identified in the inspected locations |
| US500 | SIGNAL_SCORE | TRAINED_MODEL source UNAVAILABLE: no registered frozen artifact identified in the inspected locations |
| EURUSD | SIGNAL_SCORE | TRAINED_MODEL source UNAVAILABLE: no registered frozen artifact identified in the inspected locations |
| GBPUSD | SIGNAL_SCORE | TRAINED_MODEL source UNAVAILABLE: no registered frozen artifact identified in the inspected locations |
| Two Signal ML V2 `model.joblib` sets, 18 May 2026 | not Core-5 | CREATED_UNREGISTERED; `promoted_for_live` NOT_VERIFIED_BY_R2 (E6); role to be taken from each set's own training manifest at registration |
| Four execution-filter `.pkl` files, 4 and 15 May 2026 | not Core-5 | CREATED_UNREGISTERED |

The `SIGNED_TEST_SCORE` source is available for all five instruments from the first offline build. `UNAVAILABLE` is a serving-authorisation status, not a finding that no model exists anywhere: a Core-5 source becomes eligible only when an artifact passes sections 9 to 11. The sha256, size and date of each model file are in file 25, copied from the owner's inventory output of 13 Nov 2026 (host `ip-172-31-5-61`, 16:27:41Z).

- **E1** The inventory found no Core-5 model file under `/home/ubuntu`, `/opt` or `/srv`. Absence there does not prove absence everywhere; S3 and other hosts were not inventoried.
- **E2** `backtest_ml/live_inference.py`, function `_live_prob` (defined at line 107; the classifier is built at line 138 and fitted at line 144) in the three V2 copies held by R2 (SHA-256 `8a298149c23ec23cd2dee63349834bd09e7e59c13bd533fb39a5e126795e4601`), builds a `RobustScaler` and an `XGBClassifier(n_estimators=200, max_depth=4, learning_rate=0.05, subsample=0.8, colsample_bytree=0.8, random_state=42)`, calls `fit` on all history, reads one `predict_proba` and keeps nothing. Its docstring says "Train on all available history and predict today."
- **E3** The owner's crontab runs `backtest_ml.live_inference` nine times each weekday.
- **E4** The hash of the live-folder file is `PENDING_OWNER_CHECK`. The inventory's code search was capped at 300 lines and did not reach the live folder, so E2 is shown for the copies only.
- **E5** D04-04 (pinned) says per-run transient training without a retained artifact is not eligible to claim reproducibility; Master V1.8 section 8 (a design-proposal table, not a live-host attestation) lists "V2 inference re-fits each call without permanent model hash" with "prior audit reported; code pin needed". E2 to E4 are that code pin once E4 is supplied.
- **E6** Not verified by R2: the contents of the Signal ML V2 training manifests and metrics, including any `promoted_for_live` flag stated in the author's note of 13 Nov, and any models held in S3 (`infrastructure/lambda`, `download_models_to_tmp`). None of these open items is a permission: an artifact whose manifest, provenance or location is unverified stays `CREATED_UNREGISTERED` and is not served.

## 14. Tests (design specifications; none has been run)

| ID | Case | Required result | Anchors |
|---|---|---|---|
| MSB-01 | Synthetic registered model set, evaluated twice on the same signed feature row | score produced; both runs byte-identical; artifact and score hashes in the `SignalScore` | G-1 to G-11 |
| MSB-02 | One byte of any model artifact file flipped after registration | NO_AUTHORITATIVE_PREDICTION; no entry; audit event names the file | G-2 |
| MSB-03 | An unlisted extra file in the artifact directory; a listed file missing | NO_AUTHORITATIVE_PREDICTION for the set | G-2 |
| MSB-04 | A pickle or joblib file with a correct hash; a file with an allowed extension but non-JSON content | rejected before any parse; never deserialised; canary side effect absent | G-3; G1R-08-M |
| MSB-05 | Static scan of the whole build for pickle, joblib, dill, cloudpickle, marshal, shelve, xgboost, sklearn, `allow_pickle` and any fit or train symbol | zero hits; the only model reader is `v3/offline/model_intake.py` using stdlib json | G1R-08-M; V3EXT-025 |
| MSB-06 | Input row with wrong order, a missing column, an extra column, a wrong dtype | NO_AUTHORITATIVE_PREDICTION | G-4 |
| MSB-07 | Calibration declared required but absent or with another hash | NO_AUTHORITATIVE_PREDICTION | G-5 |
| MSB-08 | Wrong instrument or role; expired authorisation; state other than serving; `promoted_for_live` not false; different runtime profile | NO_AUTHORITATIVE_PREDICTION in each of the five cases | G-6 to G-9 |
| MSB-09 | Any run-time call to a fit, train, refit or calibrate entry point, including a hostile plug-in | denied and audited; no score from the call; no fallback | EXT 1.2 as amended (AM-14); V3EXT-015 |
| MSB-10 | Output is NaN, infinite or outside its declared domain | NO_AUTHORITATIVE_PREDICTION; value not repaired | G-10 |
| MSB-11 | Converted synthetic set (a) whose golden-vector outputs differ from the reference by more than the registered tolerance; (b) whose conversion record has no registered, justified tolerance; (c) whose golden vectors cover only the tree output and not the full path | in each case does not reach VALIDATED and cannot become serving | section 7; C-3 |
| MSB-12 | A run declares `TRAINED_MODEL` for an instrument with no authorised artifact (each of the five at presentation) | `NO_AUTHORITATIVE_PREDICTION`; no eligible new entry; not converted into a test-score run | S-8 |
| MSB-13 | Re-scoring the same source event after a model rerun or reload | no second intent; same canonical intent identity | TC-MODEL; D04-04 |
| MSB-14 | Registration of a real artifact under the frozen contract | contract digest and group root unchanged; separate signed record; a registration needing a new format or gate is refused as a contract change | section 11 |
| MSB-15 | Import graph of the strategy artifact EXT-04 and of every module except `model_intake.py` | V3EXT-021 still passes; any other module importing the model reader fails the build | AM-10; V3EXT-021 |
| MSB-16 | Run both sources; follow every order, position, outcome and audit event back | each carries a `prediction_id` that resolves to `source_kind`, `source_fingerprint` and feature lineage; none is missing | S-1 to S-3, S-6 |
| MSB-17 | Produce the run report from a mixed run | results grouped by `source_kind`, never pooled; every `SIGNED_TEST_SCORE` figure stamped `NOT_PERFORMANCE_EVIDENCE` and `NOT_A_MODEL_PREDICTION`; every `TRAINED_MODEL` figure stamped `OFFLINE_SIMULATED_MODEL_BEHAVIOUR` with the words "not verified forward or live trading performance" | S-4, S-7 |
| MSB-18 | A model gate fails mid-run; the run tries to continue with a test score; a test-score prediction is given a model label; the declared source is changed mid-run | all refused and audited; no substitution in either direction | S-1, S-8 |
| MSB-19 | Tampered, unsigned or unregistered test-score set; the same input run twice | `NOT_PROVEN` for the tampered set; identical bytes for the valid set | F-1 to F-4 |

## 15. Owner selections for the sitting (listed once)

1. Accept MS-B (dual-source predictions, no refit) exactly as written here, with AM-10..AM-14, file 25 and tests MSB-01..MSB-19 (yes/no).
2. Confirm that `OC-D04-04` stays `DEFER`, so no model cadence is selected (yes/no).
3. Note that any fit-and-freeze (MS-F) is a separate later authorisation and is not decided at this sitting.
