# Review evidence for the War Rig V3 consolidated offline-core package (13 Nov 2026)

This folder holds R2's current set (first-round review, V2 replay and the MS-B dual-source amendment). R2 is an AI reviewer; nothing here is human-independent evidence, an owner acceptance or a freeze.

| File | What it is |
|---|---|
| `R2_review_of_consolidated_offline_core_package_and_change_list_20261113.md` | R2's review of the first consolidated package (dac6eb6e...), with the merged change list (R2 B1-B7, C1 and the second reviewer's F-01..F-07). |
| `R2_replay_of_V2_and_residual_fix_list_20261113.md` | R2's single mechanical replay of V2 (6888d01c...) and the residual fix list. |
| `cons_review_edits.py`, `verify_cons_review.py`, `required_pins.json` | The first-round change list as code, its checker and the pin table. The checker's inherited checks (manifest, pins, B1-B7, C1, S) are reused unchanged by the replay checker. |
| `R2_MSB_dual_source_report_20261113.md` | R2's report on MS-B (controlled dual-source predictions, no refit): the finding, the five source amendments AM-10..AM-14, corrections to the Option B notes, R2's own mistakes, what is not established, and the three owner selections. |
| `msb_edits.py`, `members/`, `msb_pins.json` | MS-B as code: 24 exact edits, AM-10..AM-14 (written to member 23), and the two new members it copies in (24 contract, 25 EC2 model evidence). `msb_pins.json` is the 25-pin table of the V3 package. |
| `verify_msb.py` | The MS-B checker. `replay FIXED_DIR` is the author's re-run (71 checks). `review` is R2's run with leave-one-out and planted-fault controls (114 checks). |
| `R2_review_of_V4_candidate_and_one_file_design_20261113.md` | R2's review of the author's V4 candidate and the one-file design document: V4 verified, the author's three evidence-wording corrections (all R2's text) plus a fourth, fixed as code, package ID V5. |
| `v2_residual_edits.py` | The residual fixes as code: 23 exact old-to-new edits, new member 23, replacement of this folder, manifest regeneration. |
| `verify_v2_replay.py` | The replay checker. `replay FIXED_DIR` is the author's re-run. `review` is R2's run with leave-one-out and planted-fault controls. |

Run from this folder:

    python3 -I -B verify_v2_replay.py replay ..

Limits: the 43/13/21 classes and the crosswalk are R2 proposals, checked for completeness and consistency only. The nine amendment wordings are R2's drafting; the checker proves each old text is quoted exactly once from the pinned file, not that the new wording is right.

MS-B (after V3 is unzipped to V3_DIR):

    python3 -I -B msb_edits.py V3_DIR NEW_DIR EVIDENCE_DIR
    python3 -I -B verify_msb.py replay NEW_DIR

Limits (MS-B): R2 drafted the five amendment wordings and the checker; the checker proves each old text is quoted exactly once, not that the new wording is right. The EC2 rows in file 25 are from an inventory Jon ran on 13 Nov 2026 16:27:41Z; the live-folder file and the training manifests are not covered.
