# R2 report: MS-B, controlled dual-source predictions, no refit (13 Nov 2026)

Reviewer: R2, an AI reviewer. Nothing here is human-independent evidence, an owner acceptance, a freeze or a start of the 48-hour clock. Jon alone approves.

Basis: the author's V3 package, ZIP SHA-256 `0e71d874dfc7d1bd26b20f3721e7995a4ec8e509cd77662e3bf861e81e8ecf00` (59 manifest entries, 25 pinned sources), the EC2 inventory taken 13 Nov 2026 16:27:41Z on host `ip-172-31-5-61` (run by Jon, pasted as two files), the three copies of V2 `live_inference.py`, and the author's two notes on Option B.

## In plain words

Your choice is now written down as a design, and it can be built. V3 will have two ways to produce a prediction, and both exist from the first build: **signed test scores** (fixed numbers that prove the machinery works) and **trained models** (finished model files that you register and V3 may only read). Both feed one prediction record. Every prediction and every simulated trade says which source it came from and carries that source's fingerprint. Test scores are never shown as model predictions or as evidence of trading performance. A model that is missing, unregistered, or fails a check gives no prediction; V3 never quietly falls back to test scores or to a newly trained model.

The inventory confirms the gap the author described. Six model files exist on EC2: four execution-filter files and two Signal ML V2 files. **None is a Core-5 model** (Gold, GER40, US500, EURUSD, GBPUSD). No registered, frozen Core-5 signal model was found, and V2's code trains its main signal model again on every run and throws it away (`backtest_ml/live_inference.py`, function `_live_prob`, which calls `m.fit(...)` at line 144 and says in its docstring "Train on all available history and predict today"; the cron table runs it nine times each weekday). So at presentation all five Core-5 models are recorded **UNAVAILABLE** for offline serving. That is a serving status, not proof that no model exists anywhere: the inventory covered one host and S3 was not checked. Making one is a fitting action. MS-B does not authorise it; it is a separate later decision (MS-F).

To build this, five sentences in the pinned documents have to change, because as written they say the opposite. I wrote each as an exact old-to-new edit (AM-10 to AM-14), plus 24 matching edits to the package's own files, so the author applies them with one command and nothing is left to interpret. After that, nothing is left for me to review. You select three things at the sitting (listed at the end).

This does not add a design stage or restart anything. No clock has started. When it starts is decided by OD-13, not by MS-B. The package follows Path 1 (one 48-hour interval from the last presentation, then G0-R and G1-R signed at one sitting), which file 10 records as a working path that binds only through your signed records. The package gets a new ID because its text changed (V4 was built from the first version of this report; the corrections in the V4 review report make it V5).

## What MS-B now says (file 24)

| Part | Rule |
|---|---|
| Source A, signed test scores | A registered pure scoring function or score table inside a signed fixture. No model file, no network. Stamped `NOT_PERFORMANCE_EVIDENCE` and `NOT_A_MODEL_PREDICTION`. Class `PIPELINE_VALIDATION_ONLY`. |
| Source B, trained models | One module, `v3/offline/model_intake.py`. It reads only owner-registered artifacts in a data-only format: XGBoost native JSON (binary logistic or squared-error objective), plus scaler, calibration, feature-schema and manifest JSON. It evaluates the trees with its own code, so no xgboost, sklearn, joblib or pickle is imported anywhere in G1-R. Class `OFFLINE_MODEL_BEHAVIOUR`. |
| One prediction record | `SignalScore` carries source kind, source fingerprint, feature lineage, evidence class and a `prediction_id` that follows every order, position, outcome and audit event. Reports never pool the two sources. |
| Gates at load | Eleven, all must pass (G-1 to G-11): manifest hash equals the one you registered; every listed file present with a matching hash and no unlisted file; every file an allowed data format that parses as strict JSON; input row equals the feature schema; required calibration present; instrument scope and role match; state is serving-authorised-offline-only and not expired; `promoted_for_live` false; runtime profile as registered; output finite and inside its declared range, never clipped or repaired; same input and artifact give byte-identical output. Any failure gives no prediction and no new entry. Parity with the original model is checked at conversion (C-1 to C-5), outside G1-R. |
| Models in joblib or pickle | Converted outside G1-R, in a separate isolated environment, on your own files only, with a recorded parity check (C-1 to C-5). The conversion is not part of this authorisation. |
| After the freeze | The contract and its 19 tests (MSB-01 to MSB-19) are fixed in the group. Real models are registered afterwards, one at a time, as separate signed records. They are not group members and do not restart the clock. |
| Not authorised (N1 to N7) | Any fitting or retraining; promotion or live use; any IG, broker, network or credential path; any V2 code or database read; choosing a model cadence (`OC-D04-04` stays DEFER); pickle or joblib in G1-R; any new route for V2 history. |

## The five source amendments (file 23, AM-10 to AM-14)

| AM | Where | What it changes, in plain words |
|---|---|---|
| 10 | EXT-G0R-14, import-ban row `G1R-08-M` | Was: no model registry or loader at all. Now: none, except the single `model_intake.py` under the MS-B gates. Fitting, promotion, activation and just-in-time training stay rejected. |
| 11 | EXT-G0R-14, oracle inventory | The row that said "no model registry import" becomes "narrowed by AM-10", so the test oracle matches. |
| 12 | EXT-G0R-14, `V3EXT-025` | Was: no V2 bytes. Now: one exception, an owner-registered converted model file, because it is data and not V2 source. |
| 13 | Master V1.8 section 3.1, `ModelArtifactRegistry` row | Was: excluded from G1-R. Now: controlled dual-source predictions only. |
| 14 | EXT-G0R-14 section 1.2, invariant 1 | The ban on "model fitting or model activation" stays. It now says offline serving of a registered artifact is neither promotion nor activation for live use. |

Unchanged on purpose: `V3EXT-021` (the pure strategy imports no loader), `V3EXT-015`, `V3EXT-027`, and `G1R-08-X` (no V2 source bytes), which stays absolute.

I drafted these wordings and I also wrote the check that they are verbatim. The check proves each old sentence is quoted exactly once from the pinned file. It does not prove the new wording is right. That is a judgement for you and the independent reviewer.

## Where the author's note needs a correction or is unverified

1. **Both saved Signal ML V2 files are "promoted_for_live=0".** I have not seen this. The manifests sit beside each model file, but I have not read them. File 25 records the flag as `NOT_VERIFIED_BY_R2`. It does not matter for safety, because gate G-8 requires the flag to be false in the manifest you register, whatever the file says today.
2. **A0.10 `REGISTER_BEFORE_SERVE` is a proposal, not an accepted decision.** MS-B uses its state names (`CREATED_UNREGISTERED` through `SERVING_AUTHORIZED_OFFLINE_ONLY`). It does not borrow its just-in-time mode or its machine authoriser, because both would allow fitting.
3. **"Real market features."** MS-B takes only signed feature rows built from signed snapshots (M4). Whether a snapshot may be real historical market data is decided by file 02 row 1 and EXT section 4.1, which says real historical data intake and trained-model fit are "not implicitly included". MS-B does not grant it.
4. **"Use historical V2 signals for replay."** Right in substance, but it is not a new permission. `ComparisonEvaluator` already admits one immutable, quarantined, pinned V2 snapshot. I wrote that into N7 so MS-B opens no new route. A replay from V2 recorded signals can compare trailing behaviour. It cannot prove that a trained model gives the same answers.
5. **Selecting MS-B does not approve D04 Model Option A.** Agreed. `OC-D04-04` stays DEFER and D04-FREEZE-02 moves in file 18 to "design adopted for offline core" (proposed only). With no refit allowed, the offline build behaves like a retained-frozen model, but that is not a selection of Option A as the live policy.

## Second reviewer's note of 13 Nov (`a9251859`): what I accepted

It concurs with the design and I agree with its disposition table. Its corrections, one pass:

| Its point | R2 disposition |
|---|---|
| B. Cooling-off should sit at the implementation gate, by controlled amendment | **No MS-B change.** I hold no record of a later arrangement. What the package and the pinned 27 Oct decision (`d3f39baa...`, rules (a) and (b)) say is Path 1. The "implementation gate only" idea matches your earlier provisional preference in OD-13 and the unadopted `V3-GOV-48-01` (REV3, five findings and 29 edits still pending). Nothing silently supersedes a pinned rule. If you want that timing instead, `V3-GOV-48-01` has to be adopted, which reopens a review. I have not changed anything here, and unless you tell me otherwise Path 1 stands. One fair part: my report stated the clock start as settled. It now says Path 1 is a working path that binds only through your signature. |
| C. Core-5 `UNAVAILABLE` is a serving status, not proof of absence | **Accepted, and my wording overclaimed.** File 24 section 1 said the model "does not exist as a file today", and section 13 and file 25 said "no frozen artifact exists". They now say no registered frozen artifact was identified in the inspected locations, and that `UNAVAILABLE` is a serving classification. E1 already said S3 and other hosts were not inventoried. |
| D. Parity needs end-to-end evidence; tolerance stays unset until justified | **Accepted in part.** The substance was already there (C-3, tolerance UNSET, MSB-11). Added: the golden vectors must cover the whole path (raw row, feature order, missing-value rule, scaler, trees, calibration, final probability), and a conversion record with no registered, justified tolerance cannot reach `VALIDATED`. MSB-11 now has three cases (a) to (c). |
| E. Trained-model reports must say offline, not forward or live | **Accepted.** S-7 and MSB-17 now stamp every trained-model figure `OFFLINE_SIMULATED_MODEL_BEHAVIOUR`, with the words "not verified forward or live trading performance". Not adopted: a separate forward-demo class. No forward path exists in this scope, so it would have no producer. It can be added when one does. |
| 7. Open items must not become implicit permissions | **Accepted.** E6 now says none of the open items (manifests, S3, live folder) is a permission, and an artifact with unverified provenance stays `CREATED_UNREGISTERED`. The live-folder check is still yours. |
| 1, 3, 4, 5, 6, 8 | Agreed. No change needed: they restate what the contract and the package already say. |

## My own mistakes

- **Planned claim withdrawn.** I had planned to say V2 historical signals conflict with `G1R-08-X`. That was wrong, for the reason in point 4. I changed N7 before sending anything.
- **The inventory script stopped early.** Section C was capped at 300 lines and never reached the live folder `/home/ubuntu/tradingview_webhook`. I told you sections A to C should be complete, and that was wrong. So the live-folder copy of `live_inference.py` is `PENDING_OWNER_CHECK` in file 25, and I have not shown that the live file equals the three V2 copies (all three identical, SHA-256 `8a298149c23ec23cd2dee63349834bd09e7e59c13bd533fb39a5e126795e4601`).
- **A wrong citation, caught by my own checker.** My first draft of clause E5 said the "re-fits each call, code pin needed" row is in EXT section 6. It is in Master V1.8 section 8, in a table headed "design proposal, no live-host attestations". It is fixed in file 24, and it means that row is a prior-audit claim, not a live-host fact.
- **An overclaim in my own contract.** I wrote that V2's main model "does not exist as a file". The evidence supports only that none was found on one host. The second reviewer caught it and it is fixed, with a checker test that fails if the phrase comes back.
- **First run of my checker: 104 of 108.** All four failures were mine (a wrong expected count, a wrong phrase, the wrong source file in a citation, and the wrong bold markup in a pattern). None was a package defect. The package edits applied cleanly on the first run.

## Result

| Check | Result |
|---|---|
| R2 review run (`review` mode, with leave-one-out and planted faults) | 114 checks, 114 PASS, 0 FAIL |
| Author re-run on the fixed package (`replay` mode) | 71 checks, 71 PASS, 0 FAIL |
| Facts about the delivered V3 (A01 to A17) | All pass: ZIP hash, 59 entries, the author's own 55 checks plus 2 manifest checks (57), every old text occurs once in its pinned source |
| Leave-one-out | Dropping any one of the 24 edits, any one of AM-10 to AM-14, either new member or the evidence replacement makes at least one check fail |
| Planted faults | 23 of 23 detected (a changed pinned byte, a joblib row in the allow-list, a changed model hash, a Core-5 row marked serving, `OC-D04-04` selected, a started clock, the overclaim put back in each of files 00, 15 and 24, the trained-model stamp removed, and 14 more) |

## What I did not establish

- The live-folder file and who loads the six model files in the live tree (your one-command check, below).
- The contents of the training manifests, any `promoted_for_live` flag, and whether S3 holds models (`infrastructure/lambda/shared/s3_helper.py` has a download path I did not trace).
- Whether the six files convert cleanly to XGBoost JSON. Nobody has opened them. I did not open any pickle or joblib file in this review.
- I ran no test. I did not re-derive the 42 edges, 84 denied pairs or 187 test cases.
- The independence route, the V32 clause text and the G1-R environment packet are owner-side, as before.

## Your one-command check (live folder)

On EC2: `cd /home/ubuntu/tradingview_webhook && sha256sum backtest_ml/live_inference.py && grep -n "\.fit(" backtest_ml/live_inference.py`. Expected hash `8a298149...e4601` and one `.fit(` line. A different hash means the live file differs from the three copies I read, and file 25 needs one more row.

## Your selections at the sitting (listed once)

1. Accept MS-B (dual-source predictions, no refit) exactly as written, with AM-10 to AM-14, file 25 and tests MSB-01 to MSB-19 (yes/no).
2. Confirm `OC-D04-04` stays DEFER, so no model cadence is selected (yes/no).
3. Note that any fit-and-freeze (MS-F) is a separate later authorisation, not decided at this sitting.

## For the author

    python3 -I -B msb_edits.py V3_UNZIPPED_DIR NEW_DIR EVIDENCE_DIR
    python3 -I -B verify_msb.py replay NEW_DIR

The first command stops and writes nothing if any old text does not occur exactly the stated number of times. It adds members 23 (exact text), 24 and 25, replaces `REVIEW_EVIDENCE`, and regenerates the manifest under the new ID. The second should print 71 checks, 71 PASS. The package then needs one fresh fingerprint and one presentation. Under Path 1 the 48-hour interval runs from that presentation and not before.
