#!/usr/bin/env python3
"""Residual fixes found by the single R2 replay of the author's V2 package
(War_Rig_V3_One_Stage_Offline_Core_Consolidated_Candidate_V2_20261113.zip, SHA-256 6888d01c...41c5).

Mechanical: every edit is (file, exact old text, exact new text) and the old text must occur exactly
the stated number of times, otherwise the script stops and writes nothing.

  python3 -I v2_residual_edits.py V2_PKG_DIR OUT_DIR EVIDENCE_DIR [NEW_PACKAGE_ID]

What it does, in order
  1. copies V2_PKG_DIR to OUT_DIR
  2. applies the EDITS below
  3. writes the new member 23_CONTROLLED_AMENDMENT_EXACT_TEXT.csv (AM-01..AM-09, from cons_review_edits.AMEND)
  4. replaces REVIEW_EVIDENCE/ with the files in EVIDENCE_DIR
  5. regenerates MANIFEST_SHA256.json
It changes nothing in SOURCE_PINS_UNMODIFIED/ and selects nothing on the owner's behalf.
"""
import csv, hashlib, io, json, os, shutil, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import cons_review_edits as CE  # noqa: E402  (rev 2 module: AMEND, AMEND_HEADER)

V2_ZIP_SHA = "6888d01c66f492d8c7ac80b750dc823f799f821e3e6587e4dcf77b45e8ba41c5"
DEFAULT_NEW_ID = "V3-ONE-STAGE-OFFLINE-CORE-CANDIDATE-20261113-V3"
OLD_ID = "V3-ONE-STAGE-OFFLINE-CORE-CANDIDATE-20261113-V2"
OLD_ID_V1 = "V3-ONE-STAGE-OFFLINE-CORE-CANDIDATE-20261113-V1"
F23 = "23_CONTROLLED_AMENDMENT_EXACT_TEXT.csv"

EDITS = []


def E(eid, group, file, old, new, why, count=1):
    EDITS.append({"id": eid, "group": group, "file": file, "old": old, "new": new, "why": why, "count": count})


# ---------------------------------------------------------------- F1 one controlling form with exact text
E("F1-1", "F1", "04_CONTROLLED_SCOPE_SOURCE_AMENDMENT_SCHEDULE.md",
  "signing this schedule alone does not mutate their source files.",
  "signing this schedule alone does not mutate their source files. The exact old and new text of each amendment is in `" + F23 + "` (AM-01..AM-09; each old text is quoted verbatim from the pinned file, where it occurs exactly once). That file is the controlling form of each amendment; this schedule and `20_...` explain what each one is for, and where they differ from file 23, file 23 controls.",
  "Two overlapping amendment lists (04 and 20) were both descriptive; neither gave exact text. One controlling form is named.")
E("F1-2", "F1", "04_CONTROLLED_SCOPE_SOURCE_AMENDMENT_SCHEDULE.md",
  "| Master V1.8 §0 | Scope R/F/DEFER unresolved |",
  "| EXT section 1.2 invariant 1 | Bans real market-data network acquisition and order/stop/close operations in G1-R, which read literally also bans simulated ones | Ban only real-broker order/stop/close operations; simulated order, stop and close operations inside the OfflineBrokerSimulator are test-only with no real transport, credential or network path (AM-01) | No real transport, credential or socket in any build; V3EXT-024, V3EXT-025, TC-ISOLATION | PROPOSED/OPEN |\n| Master V1.8 §0 | Scope R/F/DEFER unresolved |",
  "File 04 had no row for EXT section 1.2 invariant 1, the clause that otherwise forbids the simulator's order/stop/close operations.")
E("F1-3", "F1", "20_CONTROLLED_SOURCE_SUPERSESSION_PROPOSAL_NOT_ADOPTED.md",
  "**Purpose.** To resolve secondary finding F-01",
  "**Controlling form.** The exact old and new text of each amendment is in `" + F23 + "` (AM-01..AM-09). This table only explains the purpose of each change and the test boundary; if it differs from file 23, file 23 controls. Where a row below has no matching AM entry, the pinned text is unchanged and the row only states how this package reads it.\n\n**Purpose.** To resolve secondary finding F-01",
  "File 20 described amendments in prose but file 21 called it exact.")
E("F1-4", "F1", "21_MERGED_REVIEW_FINDING_DISPOSITION.md",
  "Exact controlled supersession *proposal* in file 20; original pinned sources immutable",
  "Exact old and new text of nine amendments in file 23, each old text verbatim and unique in its pinned file (file 20 explains purpose only); original pinned sources immutable",
  "File 21 said file 20 was exact. The exact text is file 23.")
E("F1-5", "F1", "21_MERGED_REVIEW_FINDING_DISPOSITION.md",
  "Scope amendments precisely proposed in 20",
  "Scope amendments given as exact old/new text in 23 (explained in 20)",
  "Same row, B3.")
E("F1-6", "F1", "10_GOVERNANCE_CONFORMANCE_AND_SINGLE_48H_RULE.md",
  "Proposed clauses collected once in `04_...`",
  "Exact old/new text in `" + F23 + "`; purposes in `04_...`",
  "Governance table pointed at the descriptive list.")
E("F1-7", "F1", "12_G0R_DESIGN_OWNER_ACCEPTANCE_FORM_UNSIGNED.md",
  "- Controlled adopted master/EXT/Stage D/ATC amended-source hashes: `________________`",
  "- Controlled source amendments AM-01..AM-09 exactly as in `" + F23 + "` (its SHA-256) and the adopted amended-source hashes: `________________`",
  "The G0-R record must bind the exact amendment text, not a description of it.")
E("F1-8", "F1", "00_READ_ME_FIRST.md",
  "`18_...csv` — disposition class of each of the 43 master rows, with the 13 findings and 21 repairs to be classed.",
  "`18_...csv` — disposition class of each of the 43 master rows, the 13 findings and the 21 repairs.\n- `19_...md` — Group 1 independence applicability and the owner's three routes (none selected); `20_...md` — explanatory table of the source-amendment proposals (not adopted); `21_...md` — merged review finding disposition; `22_...md` — primary-evidence hashes; `23_...csv` — the **exact old and new text of the nine controlled source amendments, the controlling form** (not adopted until the owner signs G0-R).",
  "Contents list stopped at 18 and still said the 34 rows were 'to be classed'.")
E("F1-9", "F1", "00_READ_ME_FIRST.md",
  "`21_MERGED_REVIEW_FINDING_DISPOSITION.md`; primary bytes under",
  "`21_MERGED_REVIEW_FINDING_DISPOSITION.md`, `22_PRIMARY_EVIDENCE_MOUNT_AND_CONTENT_SHA256.md`, `" + F23 + "`; primary bytes under",
  "New-members list in file 00 omitted 22 and 23.")

# ---------------------------------------------------------------- F2 protection state names = pinned ledger spec
E("F2-1", "F2", "01_COMPLETE_OFFLINE_CORE_DESIGN_13_COMPONENTS.md",
  "remain `OPEN_UNVERIFIED_PROTECTION` until independent simulator read-back",
  "remain position `OPEN_CONFIRMED` with protection `PROTECTION_UNVERIFIED` until independent simulator read-back",
  "OPEN_UNVERIFIED_PROTECTION is not a state in the pinned Stage D01 specification.")
E("F2-2", "F2", "01_COMPLETE_OFFLINE_CORE_DESIGN_13_COMPONENTS.md",
  "remains `UNKNOWN/UNVERIFIED` with frozen trailing",
  "remains `PROTECTION_UNVERIFIED` (or `PROTECTION_DRIFT` when a defect is proven) with frozen trailing",
  "UNKNOWN/UNVERIFIED is not a protection-axis value in the pinned specification.")
E("F2-3", "F2", "03_BROKER_NEUTRAL_EXECUTION_AND_SIMULATOR_CONTRACT.md",
  "Transition the position to `OPEN_UNVERIFIED_PROTECTION` with protection `UNKNOWN`/`PENDING`; do not label `OPEN_CONFIRMED_WITH_VERIFIED_PROTECTION` merely because",
  "Set the position axis to `OPEN_CONFIRMED` (`D03-SRC-015`, fill proven) and the protection axis to `PROTECTION_UNVERIFIED` (`D03-SRC-020`); do not set `PROTECTION_VERIFIED` merely because",
  "Three labels in one sentence that the pinned specification does not contain.")
E("F2-4", "F2", "03_BROKER_NEUTRAL_EXECUTION_AND_SIMULATOR_CONTRACT.md",
  "A verified match transitions protection to `VERIFIED_APPLIED` and releases",
  "A verified match moves protection from `PROTECTION_UNVERIFIED` to `PROTECTION_VERIFIED` (`D03-SRC-028`) and releases",
  "VERIFIED_APPLIED is not in the pinned specification.")
E("F2-5", "F2", "03_BROKER_NEUTRAL_EXECUTION_AND_SIMULATOR_CONTRACT.md",
  "remains `UNVERIFIED/UNKNOWN`, freezes trailing",
  "remains `PROTECTION_UNVERIFIED` (or becomes `PROTECTION_DRIFT` when a defect is proven, `D03-SRC-023`), freezes trailing",
  "Same.")
E("F2-6", "F2", "03_BROKER_NEUTRAL_EXECUTION_AND_SIMULATOR_CONTRACT.md",
  "must recover with `UNKNOWN` or `OPEN_UNVERIFIED_PROTECTION`, full reservations",
  "must recover with position `BROKER_OUTCOME_UNKNOWN` (if the fill itself is not proven) or position `OPEN_CONFIRMED` with protection `PROTECTION_UNVERIFIED`, full reservations",
  "Same; BROKER_OUTCOME_UNKNOWN is the pinned position-axis value for an unproven outcome (D03-SRC-016).")
E("F2-7", "F2", "08_ACCEPTANCE_TEST_CONTRACT_AND_FAILURE_MATRIX.md",
  "| `OPEN_UNVERIFIED_PROTECTION`, reserve filled",
  "| position `OPEN_CONFIRMED`, protection `PROTECTION_UNVERIFIED`, reserve filled",
  "TC-INIT-03 expected result used the invented label.")
E("F2-8", "F2", "08_ACCEPTANCE_TEST_CONTRACT_AND_FAILURE_MATRIX.md",
  "| `VERIFIED_APPLIED` only after proof",
  "| `PROTECTION_VERIFIED` only after proof",
  "TC-INIT-04 expected result used the invented label.")
E("F2-9", "F2", "08_ACCEPTANCE_TEST_CONTRACT_AND_FAILURE_MATRIX.md",
  "position never VERIFIED before authoritative applied-stop and quantity proof",
  "protection never `PROTECTION_VERIFIED` before authoritative applied-stop and quantity proof",
  "Family summary: the axis that is verified is protection, not position.")

# ---------------------------------------------------------------- F3 precedence over the Group 1 addendum
E("F3-1", "F3", "00_READ_ME_FIRST.md",
  "for an indivisible group it restarts the whole group clock.",
  "for an indivisible group it restarts the whole group clock.\n\n**Precedence over the pinned Group 1 addendum:** `SOURCE_PINS_UNMODIFIED/GROUP1_V2_ADDENDUM_UNCHANGED.json` was written before the owner's decision and still records `cooling_off_duration: UNSET`. The owner's 27 Oct decision (`d3f39baa…`, 48 hours) supersedes that statement for duration only; no other statement in the addendum changes.",
  "Two pinned sources appear to disagree on the duration; precedence is stated once.")

# ---------------------------------------------------------------- F4 identifiers
E("F4-1", "F4", "14_GROUP_48H_CLOCK_NOT_STARTED.json", "\"package_id\": \"" + OLD_ID_V1 + "\"", "\"package_id\": \"@@NEW_ID@@\"",
  "Clock file named package V1; the package is V2 (now the next revision).")
E("F4-2", "F4", "00_READ_ME_FIRST.md", "**Artifact ID:** `" + OLD_ID + "`", "**Artifact ID:** `@@NEW_ID@@`",
  "New revision carries a new ID, equal in file 00, file 14 and the manifest.")

# ---------------------------------------------------------------- F5 recorded-once wording (not blocking)
E("F5-1", "F5", "02_SCOPE_C_COMPLETE_18_MODULE_SCHEDULE.csv",
  "\"Later offline slice, separate scope\"",
  "NONE_IN_OFFLINE_MODE; EXT-07 stays excluded and reserved",
  "CandidatePublisher row still pointed at a later slice although EXT-07 is excluded and unchanged.")

# ---------------------------------------------------------------- F6 record of this replay
E("F6-1", "F6", "21_MERGED_REVIEW_FINDING_DISPOSITION.md",
  "This is a corrected **candidate**, not a freeze-ready final group.",
  "This is a corrected **candidate**, not a freeze-ready final group.\n\n## R2 mechanical replay of V2 and the residual fixes\n\nR2 replayed V2 once (`REVIEW_EVIDENCE/R2_replay_of_V2_and_residual_fix_list_20261113.md`; AI, not human independent). Everything else in V2 passed. It found these residual items: exact old/new amendment text (now file 23, one controlling form), the EXT section 1.2 row in file 04, protection state names aligned to the pinned ledger specification, one precedence sentence over the Group 1 addendum's UNSET duration, package identifiers, and the review-evidence folder carrying the current checker. They are applied in this revision. The author's own run of `verify_v2_replay.py` is the check; no further R2 review round is part of the process.",
  "Package records what the replay found and that it is applied.")


# ---------------------------------------------------------------- machinery
def _read(p):
    with open(p, encoding="utf-8", newline="") as f:
        return f.read()


def _write(p, t):
    with open(p, "w", encoding="utf-8", newline="") as f:
        f.write(t)


def sha_f(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


def amendment_csv():
    o = io.StringIO()
    w = csv.writer(o, lineterminator="\n")
    w.writerow(CE.AMEND_HEADER)
    for r in CE.AMEND:
        w.writerow(r)
    return o.getvalue()


def regen_manifest(d, new_id):
    ents = []
    for root, _, fs in os.walk(d):
        for f in sorted(fs):
            rel = os.path.relpath(os.path.join(root, f), d)
            if rel == "MANIFEST_SHA256.json":
                continue
            ents.append({"path": rel, "size_bytes": os.path.getsize(os.path.join(root, f)), "sha256": sha_f(os.path.join(root, f))})
    ents.sort(key=lambda e: e["path"])
    old = json.load(open(os.path.join(d, "MANIFEST_SHA256.json"), encoding="utf-8"))
    out = {"status": old["status"], "id": new_id, "members": len(ents), "hash_algorithm": "SHA-256", "entries": ents,
           "supersedes_candidate_sha256": V2_ZIP_SHA, "authority": old["authority"]}
    json.dump(out, open(os.path.join(d, "MANIFEST_SHA256.json"), "w"), indent=2)


def apply(src, out, evidence, new_id=DEFAULT_NEW_ID, skip=(), with_member=True, with_evidence=True):
    texts = {}
    for e in EDITS:
        if e["id"] in skip:
            continue
        p = os.path.join(src, e["file"])
        t = texts.get(e["file"]) or _read(p)
        n = t.count(e["old"])
        if n != e["count"]:
            sys.exit("STOP %s: old text occurs %d times in %s, expected %d. Nothing written." % (e["id"], n, e["file"], e["count"]))
        texts[e["file"]] = t.replace(e["old"], e["new"].replace("@@NEW_ID@@", new_id))
    if os.path.exists(out):
        shutil.rmtree(out)
    shutil.copytree(src, out)
    for f, t in texts.items():
        _write(os.path.join(out, f), t)
    if with_member:
        _write(os.path.join(out, F23), amendment_csv())
    if with_evidence:
        ev = os.path.join(out, "REVIEW_EVIDENCE")
        shutil.rmtree(ev)
        shutil.copytree(evidence, ev, ignore=shutil.ignore_patterns("__pycache__", "attach", "*.pyc"))
    regen_manifest(out, new_id)
    return out


if __name__ == "__main__":
    if len(sys.argv) < 4:
        sys.exit(__doc__)
    apply(sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4] if len(sys.argv) > 4 else DEFAULT_NEW_ID)
    print("applied %d edits + %s + REVIEW_EVIDENCE + manifest -> %s" % (len(EDITS), F23, sys.argv[2]))
