#!/usr/bin/env python3
"""Mechanical checker for the R2 review of the consolidated offline-core package.

  review  ORIG_PKG_DIR WORK_DIR OUT_PREFIX [--att DIR]   R2 run: facts about the delivered package,
          applies cons_review_edits.py to a copy, runs the post-fix checks, then the controls.
  replay  FIXED_PKG_DIR                                   the single mechanical replay on the author's fixed package
          (post-fix checks only; the manifest must have been regenerated).
Every check prints PASS or FAIL with the reason. Exit code 1 if any FAIL.
"""
import csv, hashlib, io, json, os, re, shutil, sys, zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import cons_review_edits as CE  # noqa: E402

PINS = CE.PINS
PKG_SHA = "dac6eb6e377923fe6043d4b583b63d08bdc25f3b4002e4e0c1705dbb09c4c8a7"
SPEC_AXES = ["broker_operation", "working_order", "position", "protection", "realised_result", "intent_lifecycle", "attempt_send_eligibility"]
BOILER = ["CONTRACT_DEFINED_FOR_FULL_OFFLINE_CORE; FIxture values allowed but not live policy", "OFFLINE_SIMULATION_ONLY; NO_IG_CAPABILITY"]


def sha_b(b):
    return hashlib.sha256(b).hexdigest()


def sha_f(p):
    return sha_b(open(p, "rb").read())


def rd(d, name):
    return open(os.path.join(d, name), encoding="utf-8").read()


class R:
    def __init__(self):
        self.rows = []

    def add(self, cid, ok, detail=""):
        self.rows.append((cid, bool(ok), detail))

    def fails(self):
        return [r for r in self.rows if not r[1]]


def table_rows_consistent(text):
    """every markdown table row has the same number of cells as its header row"""
    bad = []
    lines = text.split("\n")
    i = 0
    while i < len(lines):
        if lines[i].startswith("|") and i + 1 < len(lines) and re.match(r"^\|[\s:|-]+\|$", lines[i + 1]):
            n = lines[i].count("|")
            j = i + 2
            while j < len(lines) and lines[j].startswith("|"):
                if lines[j].count("|") != n:
                    bad.append(lines[j][:60])
                j += 1
            i = j
        else:
            i += 1
    return bad


# ------------------------------------------------------------------------------------------------
def post_fix_checks(d, res, att=None, label="", strict=True):
    """Conditions that must hold in the author's fixed package at directory d."""
    P = lambda cid, ok, det="": res.add(label + cid, ok, det)
    pins = os.path.join(d, "SOURCE_PINS_UNMODIFIED")
    files = os.listdir(d)
    # ---- manifest (replay mode only checks it; review mode regenerates conceptually)
    t01 = rd(d, "01_COMPLETE_OFFLINE_CORE_DESIGN_13_COMPONENTS.md")
    t02 = rd(d, "02_SCOPE_C_COMPLETE_18_MODULE_SCHEDULE.csv")
    t04 = rd(d, "04_CONTROLLED_SCOPE_SOURCE_AMENDMENT_SCHEDULE.md")
    t08 = rd(d, "08_ACCEPTANCE_TEST_CONTRACT_AND_FAILURE_MATRIX.md")
    t10 = rd(d, "10_GOVERNANCE_CONFORMANCE_AND_SINGLE_48H_RULE.md")
    t00 = rd(d, "00_READ_ME_FIRST.md")
    t11 = rd(d, "11_INDEPENDENT_VERIFICATION_AND_QUORUM_RECORD_UNSIGNED.md")
    t13 = rd(d, "13_G1R_OFFLINE_IMPLEMENTATION_GRANT_FORM_UNSIGNED.md")
    t15 = rd(d, "15_READINESS_BLOCKERS_AND_UNSET_VALUES.md")
    t05 = rd(d, "05_CONSOLIDATED_61_ROW_OWNER_DECISION_REGISTER_NOT_SELECTED.csv")
    j14 = json.loads(rd(d, "14_GROUP_48H_CLOCK_NOT_STARTED.json"))
    j16 = json.loads(rd(d, "16_SOURCE_PROVENANCE_AND_COUNTS.json"))

    # ---- B1 group membership
    spec_name = "STAGE_D01_INTEGRATED_TECHNICAL_SPECIFICATION_UNCHANGED.md"
    P("B1.a spec pin has its true name and hash", os.path.isfile(os.path.join(pins, spec_name)) and not os.path.exists(os.path.join(pins, "D03_TECH_SPEC_UNCHANGED.md")) and sha_f(os.path.join(pins, spec_name)) == PINS["stage_d03_zip"]["members"]["00_STAGE_D01_INTEGRATED_TECHNICAL_SPECIFICATION.md"])
    flat = json.dumps(j16)
    miss = [k for k, v in PINS["stage_d03_zip"]["members"].items() if v not in flat]
    P("B1.b Stage D03 members 00-07 and 12 hashes are in file 16", not miss, "missing: %s" % miss)
    P("B1.c Stage D03 zip hash is in file 16", PINS["stage_d03_zip"]["sha256"] in flat)
    for key, nm in (("d03_v3_design", "D03 V3"), ("d04_v2_design", "D04 V2")):
        want = PINS[key]["sha256"]
        found = [f for f in os.listdir(pins) if os.path.isfile(os.path.join(pins, f)) and sha_f(os.path.join(pins, f)) == want]
        P("B1.d %s bytes are pinned in the package with hash %s" % (nm, want[:8]), bool(found) and want in flat, "found files: %s" % found)
    P("B1.e fixed-by-reference note names master section 1.1", "fixed_by_reference_via_pinned_master_section_1_1" in j16 and PINS["by_reference_via_master_1_1"]["D01"]["sha256"] and True)
    mtxt = rd(pins, "MASTER_V1_8_CORRECTED_UNCHANGED.md")
    bad_ref = [k for k, v in PINS["by_reference_via_master_1_1"].items() if v["sha256"] not in mtxt]
    P("B1.f every by-reference hash (D01-D06, RG-01..07) appears in the pinned master", not bad_ref, str(bad_ref))

    # ---- B2 configurable instrument layer
    xw = list(csv.DictReader(io.StringIO(rd(d, "17_EXT_AND_ORIGINAL_UNIT_CROSSWALK.csv")))) if "17_EXT_AND_ORIGINAL_UNIT_CROSSWALK.csv" in files else []
    ids = [r["source_unit"] for r in xw]
    want_ids = ["unit 0%d" % i for i in range(1, 9)] + ["EXT-%02d" % i for i in range(1, 14)]
    P("B2.a crosswalk lists each of units 01-08 and EXT-01..13 exactly once", sorted(ids) == sorted(want_ids), "got %s" % ids)
    names18 = [r["module"] for r in csv.DictReader(io.StringIO(t02))]
    ok_map = True
    for r in xw:
        parts = [p.strip() for p in re.split(r";", r["mapped_module_row_in_02"])]
        for p in parts:
            p0 = p.split(" + ")[0].strip()
            if r["source_unit"] != "EXT-02" and p0 not in names18 and not any(n in p0 for n in names18):
                ok_map = False
    P("B2.b every mapped module name is one of the 18 module rows in file 02", ok_map)
    ext07 = [r for r in xw if r["source_unit"] == "EXT-07"]
    P("B2.c EXT-07 is excluded and no other unit is", len(ext07) == 1 and ext07[0]["disposition_in_this_grant"].startswith("EXCLUDED") and sum(1 for r in xw if r["disposition_in_this_grant"].startswith("EXCLUDED")) == 1)
    P("B2.d baseline names the instrument definition layer, EXT-01/02/13 and V3EXT-006", all(s in t01 for s in ["Instrument definition layer", "EXT-01", "EXT-02", "EXT-13", "V3EXT-006"]))
    P("B2.e a TC-INSTR family exists with V3EXT-001..011", "| TC-INSTR |" in t08 and "V3EXT-001" in t08 and "V3EXT-011" in t08)
    P("B2.g file 04 points to the crosswalk and file 00 lists the new members 17 and 18", "17_EXT_AND_ORIGINAL_UNIT_CROSSWALK.csv" in t04 and "`17_...csv`" in t00 and "`18_...csv`" in t00)
    P("B2.f 01 still says thirteen components and no fourteenth is added", "Thirteen integrated components" in t01 and "| 14 |" not in t01)

    # ---- B3 import-ban oracles
    rows02 = {r["module"]: r for r in csv.DictReader(io.StringIO(t02))}
    P("B3.a ModelArtifactRegistry is fixture-scoring only", rows02["ModelArtifactRegistry"]["proposed_scope_C_disposition"] == "OFFLINE_FIXTURE_SCORING_ONLY_NO_MODEL_LOADER")
    P("B3.b CandidatePublisher is excluded/reserved", rows02["CandidatePublisher"]["proposed_scope_C_disposition"].startswith("EXCLUDED_RESERVED_EXT07"))
    P("B3.c AnchorQuoteValidator is a pure validator over fixture quotes", rows02["AnchorQuoteValidator"]["proposed_scope_C_disposition"] == "OFFLINE_PURE_VALIDATOR_OVER_FIXTURE_QUOTES")
    P("B3.d file 04 has one row each for G1R-08-M, -C and -Q", all(("`%s`" % x) in t04 for x in ["G1R-08-M", "G1R-08-C", "G1R-08-Q"]))
    P("B3.e component 02 has no trained-model loader and 03 does not use CandidatePublisher as owner", "no trained-model loader" in t01 and "load retained models" not in t01 and "EffectivePolicyResolver + CandidatePublisher |" not in t01)
    P("B3.f grant text does not say retained inference", "retained inference" not in t13 and "no trained V2 or V3 model is loaded" in t13)

    # ---- B4 axes
    m = re.search(r"seven ledger axes exactly as .*?\bnot among these seven ledger axes\.", t01, re.S)
    para = m.group(0) if m else ""
    axes_in = re.findall(r"`([a-z_]+)`", para)
    axes_in = [a for a in axes_in if a in SPEC_AXES or a in ("monetary_outcome",)]
    P("B4.a the axis list in 01 is exactly the seven pinned axes", sorted(set(axes_in)) == sorted(SPEC_AXES) and len(axes_in) == 7, str(axes_in))
    spec_txt = rd(pins, spec_name) if os.path.isfile(os.path.join(pins, spec_name)) else ""
    P("B4.b the pinned specification defines those same seven axes", all(a in spec_txt for a in SPEC_AXES))
    P("B4.c no old axis wording remains", "monetary outcome, alert/clock, control-latch" not in t01 and "master seven axes" not in t04)

    # ---- B5 decision record
    dec_p = os.path.join(pins, CE.DEC_NAME)
    P("B5.a decision file is attached and its SHA-256 equals d3f39baa...", os.path.isfile(dec_p) and sha_f(dec_p) == CE.DEC_SHA == "d3f39baa27d8a8c91050d19dea32d83883b73eb1ddb80cf4d89dcfbee534143b")
    if os.path.isfile(dec_p):
        dj = json.load(open(dec_p, encoding="utf-8"))
        P("B5.b the attached record says 48 hours and carries rules (a) and (b)", dj["chosen_duration"]["value"] == 48 and dj["chosen_duration"]["unit"] == "hours" and "rule_a" in dj["approved_rules"] and "rule_b" in dj["approved_rules"])
    else:
        P("B5.b the attached record says 48 hours and carries rules (a) and (b)", False, "file missing")
    stale = [s for s in ["not mounted", "not present in these mounted", "R2-reported", "REPORTED_BY_USER", "NOT_YET_VERIFIED_IN_THIS_PACKAGE", "outstanding final-evidence attachment", "R2's reported direct inspection", "Attach/hash original decision"] if s in (t00 + t10 + t15 + json.dumps(j14) + json.dumps(j16))]
    P("B5.c no text still says the decision is unverified or not mounted", not stale, str(stale))
    P("B5.d clock file shows verified, hash field renamed, still NOT_STARTED with no timestamps", j14.get("primary_decision_file_verified_locally") is True and "governing_duration_primary_decision_sha256" in j14 and j14["status"] == "NOT_STARTED" and j14["latest_final_evidence_bound_presentation_utc"] is None and j14["wait_completed_utc"] is None and j14["implementation_permission"] is False)
    P("B5.e 00 and 10 quote the owner reply and the two rules", 'Cooling-off duration: 48 hours. I accept rules (a) and (b) as written.' in t00 and "recommended by R2" in t10)

    # ---- B6 human controls
    P("B6.a files 11 and 15 name CAR-01 and the three routes", "CAR-01" in t11 and "CAR-01" in t15 and "name real independent humans" in t15 and "does not apply to an offline-only grant" in t15)

    # ---- B7 register
    reg = list(csv.DictReader(io.StringIO(t05)))
    master43 = [r for r in reg if r["kind"] == "MASTER_BINDING_ITEM"]
    P("B7.a register still has 61 rows and nothing is selected", len(reg) == 61 and all(r["explicit_owner_choice"] == "NOT_SELECTED" and r["binding_disposition"] == "OPEN" for r in reg))
    P("B7.b no typo FIxture and no boilerplate candidate text on the 43 rows", "FIxture" not in t05 and not any(r["consolidated_scope_C_candidate"] in BOILER for r in master43))
    od13 = [r for r in reg if r["decision_id"] == "OD-13"][0]
    P("B7.c OD-13 no longer says G1-only and no longer waits for proof", "G1-only cooling-off placement" not in od13["topic"] and "only if primary governance proof confirms" not in od13["consolidated_scope_C_candidate"])
    cls = list(csv.DictReader(io.StringIO(rd(d, "18_REGISTER_DISPOSITION_CLASSES.csv")))) if "18_REGISTER_DISPOSITION_CLASSES.csv" in files else []
    c43 = [r for r in cls if r["item_kind"] == "MASTER_BINDING_ITEM"]
    byid = {r["decision_id"]: r for r in master43}
    same = all(CE.classify_43(byid[r["item_id"]]) == r["disposition_class"] for r in c43 if r["item_id"] in byid)
    from collections import Counter
    cnt = Counter(r["disposition_class"] for r in c43)
    P("B7.d the 43 master rows are classed K/D/C = 9/28/6 by their recorded recommendation", len(c43) == 43 and same and cnt == Counter({"D_DESIGN_ADOPTED_FOR_OFFLINE_CORE": 28, "K_KEEP_OFF_UNTIL_LATER_GATE": 9, "C_CARRY_PRIOR_DECISION": 6}), str(dict(cnt)))
    f21 = [r for r in cls if r["item_kind"] in ("FREEZE_FINDING", "REPAIR")]
    want21 = sorted([r["finding_id"] for r in csv.DictReader(io.StringIO(rd(d, "06_ORIGINAL_13_FREEZE_FINDINGS_OPEN.csv")))] + [r["repair_id"] for r in csv.DictReader(io.StringIO(rd(d, "07_ORIGINAL_21_REPAIRS_OPEN.csv")))])
    undone = sum(1 for r in f21 if r["disposition_class"].startswith("AUTHOR_TO_ASSIGN") or r["location_or_gate_and_test_id"] in ("", "AUTHOR_TO_FILL"))
    P("B7.e0 file 18 lists exactly the 13 findings and 21 repairs of files 06 and 07", sorted(r["item_id"] for r in f21) == want21 and len(want21) == 34)
    if strict:
        P("B7.e every one of the 34 is classed with a location or a gate plus denial test ID", undone == 0, "unclassed: %d" % undone)

    # ---- R1 findings folded in
    t03 = rd(d, "03_BROKER_NEUTRAL_EXECUTION_AND_SIMULATOR_CONTRACT.md")
    t14 = j14
    am_p = os.path.join(d, "19_CONTROLLED_AMENDMENT_EXACT_TEXT.csv")
    am = list(csv.DictReader(io.StringIO(open(am_p, encoding="utf-8").read()))) if os.path.isfile(am_p) else []
    bad_old = []
    for r in am:
        fp = os.path.join(pins, r["pinned_file"])
        txt = open(fp, encoding="utf-8").read() if os.path.isfile(fp) else ""
        if txt.count(r["exact_old_text"]) != 1 or not r["exact_new_text"].strip() or r["exact_new_text"] == r["exact_old_text"] or not r["takes_effect"].strip():
            bad_old.append(r["amendment_id"])
    P("R1.a file 19 has AM-01..AM-09; each old text occurs exactly once in its pinned file and each new text is non-empty and different", [r["amendment_id"] for r in am] == ["AM-0%d" % i for i in range(1, 10)] and not bad_old, "bad: %s" % bad_old)
    P("R1.b file 04 names file 19 as the controlling form and has a row for EXT section 1.2 invariant 1", "controlling form of each amendment" in t04 and "EXT section 1.2 invariant 1" in t04 and "proposed and unapproved" in t04)
    P("R1.c the stale wording is gone from the three schedule rows", all(s not in t02 for s in ["Actual decision engine later", "Monetary ledger after approved separate slice", "Later offline slice, separate scope"]))
    P("R1.d file 03: submit_market carries geometry and the trace table covers the six cases", "side, stake, geometry, guard_hash)" in t03 and "Initial stop and fill-to-protection trace" in t03 and all(s in t03 for s in ["Full fill;", "| Partial fill |", "Fill with no initial stop", "Initial stop rejected", "`read_position` UNKNOWN or stale", "Audit append fails before a simulated stop move", "PROTECTION_VERIFIED", "PROTECTION_UNVERIFIED", "PROTECTION_DRIFT"]))
    P("R1.e file 08 has a TC-PROTECT family", "| TC-PROTECT |" in t08 and "never recorded as applied" in t08)
    P("R1.f clock file: required duration 48, elapsed so far 0, old ambiguous field gone", t14.get("required_duration_elapsed_hours") == 48 and t14.get("elapsed_hours_so_far") == 0 and "duration_elapsed_hours" not in t14)
    P("B5.f file 00 says the 27 Oct decision supersedes the addendum's UNSET duration", "supersedes that statement for duration only" in t00)

    # ---- C1 and structural
    P("C1.a provisional-selection sentence is in step 1 of file 10", "provisional input that becomes binding only through the two signed records" in t10)
    bad = table_rows_consistent(t01) + table_rows_consistent(t03) + table_rows_consistent(t04) + table_rows_consistent(t08) + table_rows_consistent(t10) + table_rows_consistent(t11)
    P("S.a every edited markdown table row has the header's number of cells", not bad, str(bad[:3]))
    P("S.b status still design-only: not frozen, no clock, no authority", all(s in t00 for s in ["NOT_FROZEN", "NO_48H_CLOCK", "NO_G1_AUTHORITY"]))
    P("S.c unsigned forms are still unsigned", all("UNSIGNED" in f or "NOT_SIGNED" in rd(d, f) for f in files if f.startswith(("12_", "13_"))))
    P("S.d 18-row schedule and 61-row register counts unchanged", len(names18) == 18 and len(reg) == 61 and j16["baseline_counts"]["module_rows"] == 18)


def manifest_check(d, res):
    m = json.load(open(os.path.join(d, "MANIFEST_SHA256.json"), encoding="utf-8"))
    bad = []
    seen = set()
    for e in m["entries"]:
        p = os.path.join(d, e["path"])
        seen.add(e["path"])
        if not os.path.isfile(p) or sha_f(p) != e["sha256"]:
            bad.append(e["path"])
    allf = set()
    for root, _, fs in os.walk(d):
        for f in fs:
            allf.add(os.path.relpath(os.path.join(root, f), d))
    extra = sorted(allf - seen - {"MANIFEST_SHA256.json"})
    res.add("M.a manifest hashes match every file", not bad, "mismatch: %s" % bad)
    res.add("M.b every file is in the manifest (no extras)", not extra, "extra: %s" % extra)


# ------------------------------------------------------------------------------------------------
def facts_about_original(orig, res, orig_zip=None):
    P = res.add
    pins = os.path.join(orig, "SOURCE_PINS_UNMODIFIED")
    if orig_zip:
        P("A01 package ZIP SHA-256 equals dac6eb6e...", sha_f(orig_zip) == PKG_SHA)
    manifest_check(orig, res)
    j16o = json.dumps(json.load(open(os.path.join(orig, "16_SOURCE_PROVENANCE_AND_COUNTS.json"), encoding="utf-8"))["sources"])
    unlisted = [f for f in os.listdir(pins) if sha_f(os.path.join(pins, f)) not in j16o]
    P("A00 every pinned source file's SHA-256 is listed in file 16 (12 pins)", len(os.listdir(pins)) == 12 and not unlisted, str(unlisted))
    want = {"MASTER_V1_8_CORRECTED_UNCHANGED.md": "dce9968ec3645cd03b786409c86eeb513826df9b6d14b340533973b7c08aafdd", "EXT_G0R_14_UNCHANGED.md": "256ad6bd0d78f30e5e005f4fde64f13021d36286c8512640b2adf91a62153092", "WDA_08_UNCHANGED.md": "01697219278154ac808cebdafc6575b93a5ea7ca9cbb2310331a5b30f78966c6", "ATC_01_REV2_UNCHANGED.md": "ce5301c17b7a8e17b161bea808e4691986b8943b99edc416e0062ff482cf8039", "GROUP1_PRINCIPLES_UNCHANGED.md": "be6dad1f3247cf882a1912e91bc67c979e0f605d03ece1f3dcfb424d2d132e15", "R2_STAGE_D03_REPLAY_REPORT_UNCHANGED.md": "b60c98c4d87924286a0530bde3bf307a10dadde354bf5d4fea472c19f2a7d8f4"}
    P("A00b pinned master, EXT, WDA-08, ATC-01 rev2, Group 1 principles and R2 replay report carry the hashes agreed in this project", all(sha_f(os.path.join(pins, k)) == v for k, v in want.items()))
    t01 = rd(orig, "01_COMPLETE_OFFLINE_CORE_DESIGN_13_COMPONENTS.md")
    spec = rd(pins, "D03_TECH_SPEC_UNCHANGED.md")
    m = re.search(r"seven independent axes \((.*?)\;", t01)
    P("A02 [finding B4] package 01 lists seven axes that differ from the pinned specification", bool(m) and all(a in spec for a in SPEC_AXES) and not all(a in (m.group(1) if m else "") for a in ["broker_operation", "working_order", "realised_result"]), (m.group(1) if m else "no match"))
    ext = rd(pins, "EXT_G0R_14_UNCHANGED.md")
    t02 = rd(orig, "02_SCOPE_C_COMPLETE_18_MODULE_SCHEDULE.csv")
    t04 = rd(orig, "04_CONTROLLED_SCOPE_SOURCE_AMENDMENT_SCHEDULE.md")
    t08 = rd(orig, "08_ACCEPTANCE_TEST_CONTRACT_AND_FAILURE_MATRIX.md")
    allpkg = "".join(rd(orig, f) for f in os.listdir(orig) if f[:2].isdigit())
    P("A03 [finding B2] EXT-G0R-14 is titled Configurable Instrument and makes V3EXT-006 the first milestone", "Configurable Instrument" in ext.split("\n")[0] and "V3EXT-006" in ext and "First milestone" in ext)
    P("A04 [finding B2] the delivered package never mentions EXT-01, EXT-02, EXT-13, V3EXT-006 or a family/listing definition", not any(s in allpkg for s in ["EXT-01", "EXT-02", "EXT-13", "V3EXT-006", "instrument_definition", "plugin_manifest"]))
    P("A05 [finding B3] pinned EXT section 5.3 keeps G1R-08-M, -C, -Q as negative oracles", all(("`G1R-08-%s`" % x) in ext for x in "MCQ") and "UNCHANGED NEGATIVE" in ext)
    rows = {r["module"]: r for r in csv.DictReader(io.StringIO(t02))}
    P("A06 [finding B3] file 02 marks all three modules FULL_OFFLINE_IMPLEMENTATION_CANDIDATE with the negative test as anchor", all(rows[k]["proposed_scope_C_disposition"] == "FULL_OFFLINE_IMPLEMENTATION_CANDIDATE" for k in ["ModelArtifactRegistry", "CandidatePublisher", "AnchorQuoteValidator"]) and "G1R-08-M" in rows["ModelArtifactRegistry"]["source_test_anchor"] and "G1R-08-C" in rows["CandidatePublisher"]["source_test_anchor"] and "G1R-08-Q" in rows["AnchorQuoteValidator"]["source_test_anchor"])
    P("A07 [finding B3] file 04 has no row for G1R-08-M, -C or -Q", not any(x in t04 for x in ["G1R-08-M", "G1R-08-C", "G1R-08-Q"]))
    mentions = [n for n in ["01_EDGE_CONTRACTS_35_DRAFT.json", "02_NEGATIVE_GRAPH_COMPLEMENT_59_SOURCE_PRESERVED.json", "06_DETERMINISTIC_TEST_PLAN_UNEXECUTED.json"] if n in spec]
    P("A08 [finding B1] the pinned specification relies on Stage D03 members that the package neither contains nor hashes", len(mentions) == 3 and not any(h in allpkg + rd(orig, "16_SOURCE_PROVENANCE_AND_COUNTS.json") for h in [PINS["stage_d03_zip"]["members"]["01_EDGE_CONTRACTS_35_DRAFT.json"], PINS["stage_d03_zip"]["sha256"]]))
    P("A09 [finding B1] D03 V3 and D04 V2 are hashed in master 1.1 but are not pinned in the package", PINS["d03_v3_design"]["sha256"] in rd(pins, "MASTER_V1_8_CORRECTED_UNCHANGED.md") and PINS["d04_v2_design"]["sha256"] in rd(pins, "MASTER_V1_8_CORRECTED_UNCHANGED.md") and not any(sha_f(os.path.join(pins, f)) in (PINS["d03_v3_design"]["sha256"], PINS["d04_v2_design"]["sha256"]) for f in os.listdir(pins)))
    P("A10 [finding B1] the pin named D03_TECH_SPEC is the Stage D01 integrated specification (hash ae373e60...)", sha_f(os.path.join(pins, "D03_TECH_SPEC_UNCHANGED.md")) == PINS["stage_d03_zip"]["members"]["00_STAGE_D01_INTEGRATED_TECHNICAL_SPECIFICATION.md"] and "Stage D01" in spec.split("\n")[0])
    P("A11 [finding B5] the package says the 27 Oct decision is not mounted and does not contain it", "not mounted" in rd(orig, "00_READ_ME_FIRST.md") and not any(f.startswith("A39_GROUP1_COOLING_OFF") for f in os.listdir(pins)))
    P("A12 [finding B6] Group 1 principle 5 keeps the two-person rules and names CAR-01; the package never names CAR-01", "Existing two-person safeguards stay in force" in rd(pins, "GROUP1_PRINCIPLES_UNCHANGED.md") and "waived by approval of these principles" in rd(pins, "GROUP1_PRINCIPLES_UNCHANGED.md") and "CAR-01" in rd(pins, "GROUP1_PRINCIPLES_UNCHANGED.md") and "CAR-01" not in allpkg)
    reg = list(csv.DictReader(io.StringIO(rd(orig, "05_CONSOLIDATED_61_ROW_OWNER_DECISION_REGISTER_NOT_SELECTED.csv"))))
    m43 = [r for r in reg if r["kind"] == "MASTER_BINDING_ITEM"]
    P("A13 [finding B7] the 43 master rows carry only the two boilerplate candidate texts; 25 contain the typo", len(m43) == 43 and set(r["consolidated_scope_C_candidate"] for r in m43) == set(BOILER) and sum(1 for r in m43 if "FIxture" in r["consolidated_scope_C_candidate"]) == 25)
    t03o = rd(orig, "03_BROKER_NEUTRAL_EXECUTION_AND_SIMULATOR_CONTRACT.md")
    P("A15 [R1 F-01] pinned EXT section 1.2 prohibits order/stop/close operations in G1-R and file 04 has no row for it", "real market-data network acquisition, order/stop/close operations, external notifications" in ext and "invariant 1" not in t04 and "1.2" not in t04)
    P("A16 [R1 F-04] submit_market in file 03 has no geometry or stop argument and no fill-to-protection trace exists", "submit_market(intent_id, attempt_id, policy_hash, side, stake, guard_hash)" in t03o and "fill-to-protection" not in t03o and "TC-PROTECT" not in t08)
    t02o = t02
    P("A17 [R1 F-02] three schedule rows carry stale 'later' wording beside a FULL_OFFLINE disposition", all(s in t02o for s in ["Actual decision engine later", "Monetary ledger after approved separate slice", "Later offline slice, separate scope"]))
    P("A18 [R1 F-07] clock file shows NOT_STARTED beside duration_elapsed_hours 48", '"duration_elapsed_hours": 48' in rd(orig, "14_GROUP_48H_CLOCK_NOT_STARTED.json") and '"status": "NOT_STARTED"' in rd(orig, "14_GROUP_48H_CLOCK_NOT_STARTED.json"))
    P("A19 [R1 F-01] every old text in the amendment table is verbatim and unique in its pinned source", all(open(os.path.join(pins, r[1]), encoding="utf-8").read().count(r[2]) == 1 for r in CE.AMEND), "")
    P("A14 [finding B7] OD-13 still carries the G1-only topic", any(r["decision_id"] == "OD-13" and r["topic"] == "G1-only cooling-off placement" for r in reg))


# ------------------------------------------------------------------------------------------------
def make_fixed(orig, out, att=None):
    """R2 simulation of the author's fixed package: the edits plus the three files the author must attach."""
    CE.apply(orig, out)
    pins = os.path.join(out, "SOURCE_PINS_UNMODIFIED")
    for name in (CE.DEC_NAME, PINS["d03_v3_design"]["file"], PINS["d04_v2_design"]["file"]):
        shutil.copy(os.path.join(HERE, "attach", name), os.path.join(pins, name))
    return out


def regen_manifest(d):
    ents = []
    for root, _, fs in os.walk(d):
        for f in sorted(fs):
            rel = os.path.relpath(os.path.join(root, f), d)
            if rel == "MANIFEST_SHA256.json":
                continue
            ents.append({"path": rel, "size_bytes": os.path.getsize(os.path.join(root, f)), "sha256": sha_f(os.path.join(root, f))})
    ents.sort(key=lambda e: e["path"])
    json.dump({"status": "PROPOSED_CANDIDATE_NOT_FROZEN", "id": "V3-ONE-STAGE-OFFLINE-CORE-CANDIDATE-20261113-V2-SIMULATED", "members": len(ents), "hash_algorithm": "SHA-256", "entries": ents}, open(os.path.join(d, "MANIFEST_SHA256.json"), "w"), indent=2)


def controls(orig, work, att, res):
    """Leave-one-out, partial and planted controls. Each must make the post-fix checks FAIL."""
    # leave-one-out
    loo_ok = []
    for e in list(CE.EDITS):
        saved = list(CE.EDITS)
        CE.EDITS[:] = [x for x in saved if x["id"] != e["id"]]
        d = os.path.join(work, "loo")
        try:
            make_fixed(orig, d, att)
            r2 = R()
            post_fix_checks(d, r2, strict=False)
            flagged = bool(r2.fails())
        except SystemExit:
            flagged = True
        finally:
            CE.EDITS[:] = saved
        loo_ok.append((e["id"], flagged))
    notflag = [i for i, f in loo_ok if not f]
    res.add("K1 leave-one-out: dropping any single one of the %d edits makes at least one post-fix check FAIL" % len(loo_ok), not notflag, "not flagged: %s" % notflag)

    base = os.path.join(work, "fixed")

    def planted(cid, mutate, expect_prefixes):
        d = os.path.join(work, "planted")
        if os.path.exists(d):
            shutil.rmtree(d)
        shutil.copytree(base, d)
        mutate(d)
        r2 = R()
        post_fix_checks(d, r2, strict=False)
        f = [x[0] for x in r2.fails()]
        ok = all(any(x.startswith(p) for x in f) for p in expect_prefixes)
        res.add("K2 planted: %s is detected (%s FAIL)" % (cid, "/".join(expect_prefixes)), ok, "failed checks: %s" % f)

    def w(d, name, fn):
        p = os.path.join(d, name)
        t = open(p, encoding="utf-8").read()
        open(p, "w", encoding="utf-8", newline="").write(fn(t))

    planted("one hash digit flipped in file 16", lambda d: w(d, "16_SOURCE_PROVENANCE_AND_COUNTS.json", lambda t: t.replace(PINS["stage_d03_zip"]["members"]["01_EDGE_CONTRACTS_35_DRAFT.json"][:12], "000000000000", 1)), ["B1.b"])
    planted("old axis wording put back", lambda d: w(d, "01_COMPLETE_OFFLINE_CORE_DESIGN_13_COMPONENTS.md", lambda t: t.replace("`attempt_send_eligibility`", "monetary outcome, alert/clock, control-latch", 1)), ["B4.a", "B4.c"])
    planted("EXT-13 missing from the crosswalk", lambda d: w(d, "17_EXT_AND_ORIGINAL_UNIT_CROSSWALK.csv", lambda t: "\n".join(l for l in t.split("\n") if not l.startswith("EXT-13"))), ["B2.a"])
    planted("a master row misclassed K instead of D", lambda d: w(d, "18_REGISTER_DISPOSITION_CLASSES.csv", lambda t: t.replace("OC-D03-02,MASTER_BINDING_ITEM,D_DESIGN_ADOPTED_FOR_OFFLINE_CORE", "OC-D03-02,MASTER_BINDING_ITEM,K_KEEP_OFF_UNTIL_LATER_GATE", 1)), ["B7.d"])
    planted("one byte changed in the attached decision", lambda d: w(d, "SOURCE_PINS_UNMODIFIED/" + CE.DEC_NAME, lambda t: t.replace("48", "47", 1)), ["B5.a"])
    planted("'not mounted' text put back", lambda d: w(d, "00_READ_ME_FIRST.md", lambda t: t + "\nThe exact approved file is not mounted in this package.\n"), ["B5.c"])
    planted("CandidatePublisher marked built again", lambda d: w(d, "02_SCOPE_C_COMPLETE_18_MODULE_SCHEDULE.csv", lambda t: t.replace("EXCLUDED_RESERVED_EXT07_NO_PUBLISHER_OR_STORE", "FULL_OFFLINE_IMPLEMENTATION_CANDIDATE", 1)), ["B3.b"])
    planted("boilerplate candidate text put back on a master row", lambda d: w(d, "05_CONSOLIDATED_61_ROW_OWNER_DECISION_REGISTER_NOT_SELECTED.csv", lambda t: t.replace("CLASS D_DESIGN_ADOPTED_FOR_OFFLINE_CORE: " + CE.CLASS_LEGEND["D_DESIGN_ADOPTED_FOR_OFFLINE_CORE"], "OFFLINE_SIMULATION_ONLY; NO_IG_CAPABILITY", 1)), ["B7.b"])
    planted("a finding not in files 06/07 added to file 18", lambda d: w(d, "18_REGISTER_DISPOSITION_CLASSES.csv", lambda t: t + "D03-FREEZE-99,FREEZE_FINDING,AUTHOR_TO_ASSIGN: x,,AUTHOR_TO_FILL\n"), ["B7.e0"])
    planted("an amendment old text no longer verbatim", lambda d: w(d, "19_CONTROLLED_AMENDMENT_EXACT_TEXT.csv", lambda t: t.replace("order/stop/close operations, external notifications", "order/stop/close operation, external notifications", 1)), ["R1.a"])
    planted("a case row deleted from the fill-to-protection trace", lambda d: w(d, "03_BROKER_NEUTRAL_EXECUTION_AND_SIMULATOR_CONTRACT.md", lambda t: "\n".join(l for l in t.split("\n") if not l.startswith("| Initial stop rejected"))), ["R1.d"])
    planted("ambiguous clock field restored", lambda d: w(d, "14_GROUP_48H_CLOCK_NOT_STARTED.json", lambda t: t.replace('"required_duration_elapsed_hours": 48', '"duration_elapsed_hours": 48', 1)), ["R1.f"])
    planted("clock started by mistake", lambda d: w(d, "14_GROUP_48H_CLOCK_NOT_STARTED.json", lambda t: t.replace('"status": "NOT_STARTED"', '"status": "RUNNING"', 1)), ["B5.d"])


def simulate_author_complete(fixed, work, res):
    """Positive control: when the author has classed the 34 rows and regenerated the manifest, strict replay passes."""
    d = os.path.join(work, "author_complete")
    if os.path.exists(d):
        shutil.rmtree(d)
    shutil.copytree(fixed, d)
    p = os.path.join(d, "18_REGISTER_DISPOSITION_CLASSES.csv")
    rows = list(csv.reader(open(p, encoding="utf-8")))
    for r in rows[1:]:
        if r[2].startswith("AUTHOR_TO_ASSIGN"):
            r[2] = "CLOSED_IN_DESIGN_TEXT"
            r[3] = "closed by the design text"
            r[4] = "01 component 10 (simulation of the author's entry)"
    o = io.StringIO()
    wr = csv.writer(o, lineterminator="\n")
    for r in rows:
        wr.writerow(r)
    open(p, "w", encoding="utf-8", newline="").write(o.getvalue())
    regen_manifest(d)
    r2 = R()
    manifest_check(d, r2)
    post_fix_checks(d, r2, strict=True)
    res.add("K3 positive control: with the 34 rows classed and the manifest regenerated, the strict replay has 0 FAIL (%d checks)" % len(r2.rows), not r2.fails(), str([x[0] for x in r2.fails()]))


def main(argv):
    if argv[1] == "replay":
        d = argv[2]
        res = R()
        manifest_check(d, res)
        post_fix_checks(d, res)
        return report(res, None)
    orig, work, outp = argv[2], argv[3], argv[4]
    att = argv[argv.index("--att") + 1] if "--att" in argv else None
    orig_zip = argv[argv.index("--zip") + 1] if "--zip" in argv else None
    os.makedirs(work, exist_ok=True)
    res = R()
    facts_about_original(orig, res, orig_zip)
    fixed = os.path.join(work, "fixed")
    make_fixed(orig, fixed, att)
    regen_manifest(fixed)
    post_fix_checks(fixed, res, strict=False)
    manifest_check(fixed, res)
    controls(orig, work, att, res)
    simulate_author_complete(fixed, work, res)
    return report(res, outp)


def report(res, outp):
    lines = []
    for cid, ok, det in res.rows:
        lines.append("%s  %s%s" % ("PASS" if ok else "FAIL", cid, ("  -- " + det) if (det and not ok) else ""))
    npass = sum(1 for r in res.rows if r[1])
    lines.append("")
    lines.append("TOTAL %d checks: %d PASS, %d FAIL" % (len(res.rows), npass, len(res.rows) - npass))
    txt = "\n".join(lines)
    print(txt)
    if outp:
        open(outp + ".txt", "w").write(txt + "\n")
        json.dump([{"id": c, "pass": o, "detail": d} for c, o, d in res.rows], open(outp + ".json", "w"), indent=1)
    return 1 if res.fails() else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
