# R2 replay of the author's V2 consolidated package, and the residual fix list (13 Nov 2026)

Package replayed: `War_Rig_V3_One_Stage_Offline_Core_Consolidated_Candidate_V2_20261113.zip`, SHA-256 `6888d01c66f492d8c7ac80b750dc823f799f821e3e6587e4dcf77b45e8ba41c5` (54 files, 53 manifest entries). This is an AI review by R2 and is labelled NOT_INDEPENDENT_SINGLE_OWNER_PROCESS. It is not an owner acceptance, a freeze or the start of any clock.

## In plain words

V2 is close. The substantial work holds. Every pinned source file is byte for byte what it should be, the 61-row decision register is intact with nothing selected, all 34 findings and repairs now have a class, the new initial-stop section and its ten tests are there, the clock file correctly says 48 hours required and 0 elapsed, and both owner forms are still blank.

I found six small things that must be fixed before the group is final. I have written each one as an exact edit, so the author applies them with one command and nothing is left to interpret.

The one that matters is this. The nine changes to the old documents (for example, the old rule that says no "order, stop or close operations" has to become "no real-broker ones", or the simulator could not be built) are described in two overlapping tables, but they are not written out word for word. At the sitting you would be signing a description, and the exact words could be filled in afterwards, which would restart the 48 hours. The fix is one file that holds the exact old sentence and the exact new sentence for each change, with every old sentence checked to occur exactly once in the pinned source. These nine wordings are my drafting. You or the author can change them, at no cost, until the final presentation.

The other five are mechanical: the names of the protection states, one sentence saying which duration wins, a package ID, one stale phrase, and the review-evidence folder, which still holds my first-round files.

After the author applies the edits and runs the checker (57 checks, 0 fail), nothing is left for me to review. The final presentation can happen then, and the 48-hour clock starts at that presentation and not before. Nothing is accepted, frozen or started today.

The "42/42" in the author's message is my first-round checker. This replay uses the later one, which also covers the second reviewer's seven findings. So 42/42 was real, but it was not this result.

## What passed

| Area | Result |
|---|---|
| ZIP, manifest, pins | ZIP hash `6888d01c…` matches. All 53 manifest entries match their files and no file is unlisted. The pinned master, EXT-G0R-14, WDA-08, ATC-01 rev2, Group 1 principles, R2 Stage D03 report, the 27 Oct decision (`d3f39baa…`), D03 V3, D04 V2 and the Stage D01 specification carry the hashes agreed in this project. The Stage D03 ZIP and its members 00-07 and 12 match, and the test plan holds 187 cases. |
| My first-round conditions B1 to B7, C1 and the structure checks | All 40 pass on V2 as delivered: the instrument layer and crosswalk, the three import-ban oracles, the seven ledger axes, the 27 Oct decision attached and quoted, CAR-01 and the three routes named, 61 rows NOT_SELECTED, 43 rows classed 9/28/6, 13 findings and 21 repairs classed. |
| The second reviewer's items, by substance | The fill-to-protection section, `initial_protection_spec` in `submit_market`, TC-INIT-01..10 and the TC-AUDIT row are present. Two of the three stale schedule rows are fixed. The clock file says required 48, elapsed 0, NOT_STARTED. |
| Status | Design only. Not frozen, no clock, no authority, forms unsigned. |

Seven of my later checks failed on first run. Three failed only because they looked for my file and field names (the test family is called TC-INIT, not TC-PROTECT; the clock fields are named differently; the trace is prose, not a table), and the substance is fine. I replaced those with name-neutral checks. Four were real, and they are items 1, 2, 4 and 5 below. Reading the files for the replay found items 3 and 6.

## Residual items (none changes a design decision)

| # | Item | Why it matters | Fix |
|---|---|---|---|
| 1 | The nine source amendments are in two prose tables (`04` and `20`) and nowhere as exact old/new text. File 21 calls file 20 "exact". The G0-R form binds "amended-source hashes" but no wording. | You would sign a description. Exact wording filled in later restarts the clock. | New member `23_CONTROLLED_AMENDMENT_EXACT_TEXT.csv` (AM-01..AM-09). Files 04 and 20 name it as controlling, and 10, 12, 21 and 00 point to it. Edits F1-1 and F1-3 to F1-7, plus the new member. |
| 2 | File 04 has no row for EXT section 1.2 invariant 1, the clause that forbids order, stop and close operations in G1-R and so forbids the simulator as written. | This is the clause that, read literally, forbids the simulator Scope C needs. | Row added (F1-2); the wording is AM-01. |
| 3 | The new initial-stop section uses states that the pinned ledger specification does not have: `OPEN_UNVERIFIED_PROTECTION`, `OPEN_CONFIRMED_WITH_VERIFIED_PROTECTION`, `VERIFIED_APPLIED`, `UNKNOWN/UNVERIFIED`. The pinned specification has position `OPEN_CONFIRMED` / `BROKER_OUTCOME_UNKNOWN` and protection `PROTECTION_UNVERIFIED` / `PROTECTION_VERIFIED` / `PROTECTION_DRIFT`. | The ten TC-INIT oracles could not be run against the pinned ledger, and the package would contradict its own "no silent renaming of axes" row. | Nine edits F2-1 to F2-9, each citing the pinned transition (`D03-SRC-015`, `-020`, `-023`, `-028`). |
| 4 | The pinned Group 1 addendum still says `cooling_off_duration: UNSET`; the owner decision says 48 hours. Nothing says which wins. | Two pinned sources disagree on the duration. | One sentence in file 00 (F3-1): the 27 Oct decision supersedes that statement for duration only. |
| 5 | The `CandidatePublisher` row in file 02 still says "Later offline slice, separate scope" although EXT-07 stays excluded and unchanged. | Stale wording; recorded once, does not block. | F5-1. |
| 6 | File 14 names the package `...-V1` while file 00 and the manifest say V2. `REVIEW_EVIDENCE/` holds my first-round change list, checker and report, not the current set. File 00's list stops at member 21 and still says the 34 rows are "to be classed". | Identifiers and evidence must be one set at the final presentation. | F4-1, F4-2, F1-8, F1-9, F6-1 and the evidence folder replacement. New package ID `V3-ONE-STAGE-OFFLINE-CORE-CANDIDATE-20261113-V3` (the author may use another, but file 00, file 14 and the manifest must agree). |

## The nine amendments in plain words

Each keeps real-broker (IG) action denied. Each is what lets the confidence, sizing, breakeven and adaptive trailing logic, which are core V2 features, be built and tested offline in the simulator instead of being deferred.

| AM | Where | Old rule | New rule |
|---|---|---|---|
| 01 | EXT-G0R-14 section 1.2 | No order, stop or close operations | No real-broker ones; simulated ones inside the simulator are test-only, with no real transport, credential or network |
| 02 | EXT-G0R-14, stop modification | No stop-modification import | None for a real broker or IG; simulator-only tightening is allowed in mode `SIMULATOR_ONLY_TIGHTEN` under signed fixture policies |
| 03 | EXT-G0R-14 | Five state axes | Seven: the five plus `intent_lifecycle` and `attempt_send_eligibility`, as master 3.3 and the Stage D01 specification already say |
| 04 | ATC-01 rev2 | Modes OFF, COMPUTE_AND_LOG_ONLY, LIVE_TIGHTEN_ONLY | Adds `SIMULATOR_ONLY_TIGHTEN`; `LIVE_TIGHTEN_ONLY` stays unavailable in this grant |
| 05 | Master 1.8 invariant | No trade, no fitting or policy activation | No real trade (simulated trades allowed), no model fitting, no policy activation |
| 06 | Master 3.1A | The 16-row module table | Marked as replaced by the 18-row table in file 02 |
| 07 | OD14-03 | Every protective broker action disabled | Every real-broker one disabled; simulated ones allowed as test-only |
| 08 | OD14-03 | Stop tightening and trailing stay disabled | Real-broker ones stay disabled; simulated ones are in scope |
| 09 | OD14-03 | "Offline V3 cannot send orders, so these cannot run here" | They run here against the simulator; `adaptive_protection_required` stays unselected for any real broker |

I drafted all nine wordings, and I also wrote the check that they are verbatim. That check proves each old sentence is quoted exactly from the pinned file; it does not prove the new wording is right. AM-04 amends ATC-01, which I designed, so I cannot independently check it, and that check stays with you (item A-06, as before). AM-07 to AM-09 amend the author's OD14-03 sheet, so the author should read those three as their own document.

## Your decisions, listed once

1. **Independence route (file 19), the only item that cannot be closed by writing.** The author's table correctly says the V32 clauses are not attached, so nobody can yet say which controls apply to an offline design acceptance. Send the author the V32 text on independent reviewer, quorum, K1, H13 and release signing. The author fills the table. If every clause plainly covers only live release, route C (verified non-applicability) is open to you. If any clause covers design acceptance, you need route A (name real people) or route B (CAR-01 joins the group, and its own text must then be fixed before the clock starts). I cannot read V32, so I cannot tell you that C will hold.
2. **At the one sitting:** Option R with Scope C; the classes K/D/C for the 43 rows and the dispositions for the 13 and 21; the 14 Stage D rows; ATC decisions J1 to J4; the nine amendments as written in file 23.
3. **Outside-workspace custody copy** of the final group.
4. **Trained-model scope.** As written, the offline build exercises the whole trading pipeline (confidence, sizing, TP/SL, breakeven, adaptive trailing, risk, simulator) on signed fixture scores, not on V2's trained model. Taking V2's model in needs a separate controlled grant later.

## Sequence from here

The author applies the edits and re-runs the checker. No further round with me is needed unless that checker fails. Then comes the final presentation, with the clock starting at its recorded time. Any change to the group after that restarts the whole group clock (27 Oct rule (b)), so the exact wording in file 23 and the V32 answer should be settled before that presentation. After 48 elapsed hours, one sitting, with two separate records signed: G0-R, then G1-R.

## How the author applies and re-runs

    python3 -I v2_residual_edits.py V2_DIR FIXED_DIR EVIDENCE_DIR [NEW_PACKAGE_ID]
    python3 -I -B verify_v2_replay.py replay FIXED_DIR

The first command stops without writing anything if any old text does not occur the stated number of times. It also writes member 23, replaces `REVIEW_EVIDENCE/` with the files in `EVIDENCE_DIR` (the set in the attached ZIP) and regenerates the manifest. The second must print `TOTAL 57 checks: 57 PASS, 0 FAIL`.

## What the checker proves and does not

R2's run (`review` mode) gives 88 checks, 0 fail: 17 on V2 as delivered (15 facts, including each of the six items, plus its manifest); 57 on the simulated fixed package, which is also what the author's re-run executes; one leave-one-out control (dropping any one of the 23 edits, member 23 or the evidence replacement makes a check fail); and 13 planted faults, each detected. A second clean run gave identical output.

Not established. I did not re-derive the 42 edge contracts, 84 denied pairs or 187 test cases; I rely on the earlier Stage D03 replay and checked only that the pinned bytes are what that replay hashed. The protection section was judged by reading it against the pinned transitions, and no test has been run. The 43/13/21 classes are still my proposals, checked for completeness and consistency and not for each judgement. Whether adaptive trailing improves on V2's outcomes is not tested anywhere yet. V2's `REVIEW_EVIDENCE/` suggests the author built it from my first-round list; my later merged list already contained the exact amendment wording and the second reviewer's items, which is why they were missing.

## Appendix A: the edit list (generated from `v2_residual_edits.py`; every old text occurs exactly once in V2)

### F1-1 — `04_CONTROLLED_SCOPE_SOURCE_AMENDMENT_SCHEDULE.md`

*Why:* Two overlapping amendment lists (04 and 20) were both descriptive; neither gave exact text. One controlling form is named.

Old:

    signing this schedule alone does not mutate their source files.

New:

    signing this schedule alone does not mutate their source files. The exact old and new text of each amendment is in `23_CONTROLLED_AMENDMENT_EXACT_TEXT.csv` (AM-01..AM-09; each old text is quoted verbatim from the pinned file, where it occurs exactly once). That file is the controlling form of each amendment; this schedule and `20_...` explain what each one is for, and where they differ from file 23, file 23 controls.

### F1-2 — `04_CONTROLLED_SCOPE_SOURCE_AMENDMENT_SCHEDULE.md`

*Why:* File 04 had no row for EXT section 1.2 invariant 1, the clause that otherwise forbids the simulator's order/stop/close operations.

Old:

    | Master V1.8 §0 | Scope R/F/DEFER unresolved |

New:

    | EXT section 1.2 invariant 1 | Bans real market-data network acquisition and order/stop/close operations in G1-R, which read literally also bans simulated ones | Ban only real-broker order/stop/close operations; simulated order, stop and close operations inside the OfflineBrokerSimulator are test-only with no real transport, credential or network path (AM-01) | No real transport, credential or socket in any build; V3EXT-024, V3EXT-025, TC-ISOLATION | PROPOSED/OPEN |
    | Master V1.8 §0 | Scope R/F/DEFER unresolved |

### F1-3 — `20_CONTROLLED_SOURCE_SUPERSESSION_PROPOSAL_NOT_ADOPTED.md`

*Why:* File 20 described amendments in prose but file 21 called it exact.

Old:

    **Purpose.** To resolve secondary finding F-01

New:

    **Controlling form.** The exact old and new text of each amendment is in `23_CONTROLLED_AMENDMENT_EXACT_TEXT.csv` (AM-01..AM-09). This table only explains the purpose of each change and the test boundary; if it differs from file 23, file 23 controls. Where a row below has no matching AM entry, the pinned text is unchanged and the row only states how this package reads it.
    
    **Purpose.** To resolve secondary finding F-01

### F1-4 — `21_MERGED_REVIEW_FINDING_DISPOSITION.md`

*Why:* File 21 said file 20 was exact. The exact text is file 23.

Old:

    Exact controlled supersession *proposal* in file 20; original pinned sources immutable

New:

    Exact old and new text of nine amendments in file 23, each old text verbatim and unique in its pinned file (file 20 explains purpose only); original pinned sources immutable

### F1-5 — `21_MERGED_REVIEW_FINDING_DISPOSITION.md`

*Why:* Same row, B3.

Old:

    Scope amendments precisely proposed in 20

New:

    Scope amendments given as exact old/new text in 23 (explained in 20)

### F1-6 — `10_GOVERNANCE_CONFORMANCE_AND_SINGLE_48H_RULE.md`

*Why:* Governance table pointed at the descriptive list.

Old:

    Proposed clauses collected once in `04_...`

New:

    Exact old/new text in `23_CONTROLLED_AMENDMENT_EXACT_TEXT.csv`; purposes in `04_...`

### F1-7 — `12_G0R_DESIGN_OWNER_ACCEPTANCE_FORM_UNSIGNED.md`

*Why:* The G0-R record must bind the exact amendment text, not a description of it.

Old:

    - Controlled adopted master/EXT/Stage D/ATC amended-source hashes: `________________`

New:

    - Controlled source amendments AM-01..AM-09 exactly as in `23_CONTROLLED_AMENDMENT_EXACT_TEXT.csv` (its SHA-256) and the adopted amended-source hashes: `________________`

### F1-8 — `00_READ_ME_FIRST.md`

*Why:* Contents list stopped at 18 and still said the 34 rows were 'to be classed'.

Old:

    `18_...csv` — disposition class of each of the 43 master rows, with the 13 findings and 21 repairs to be classed.

New:

    `18_...csv` — disposition class of each of the 43 master rows, the 13 findings and the 21 repairs.
    - `19_...md` — Group 1 independence applicability and the owner's three routes (none selected); `20_...md` — explanatory table of the source-amendment proposals (not adopted); `21_...md` — merged review finding disposition; `22_...md` — primary-evidence hashes; `23_...csv` — the **exact old and new text of the nine controlled source amendments, the controlling form** (not adopted until the owner signs G0-R).

### F1-9 — `00_READ_ME_FIRST.md`

*Why:* New-members list in file 00 omitted 22 and 23.

Old:

    `21_MERGED_REVIEW_FINDING_DISPOSITION.md`; primary bytes under

New:

    `21_MERGED_REVIEW_FINDING_DISPOSITION.md`, `22_PRIMARY_EVIDENCE_MOUNT_AND_CONTENT_SHA256.md`, `23_CONTROLLED_AMENDMENT_EXACT_TEXT.csv`; primary bytes under

### F2-1 — `01_COMPLETE_OFFLINE_CORE_DESIGN_13_COMPONENTS.md`

*Why:* OPEN_UNVERIFIED_PROTECTION is not a state in the pinned Stage D01 specification.

Old:

    remain `OPEN_UNVERIFIED_PROTECTION` until independent simulator read-back

New:

    remain position `OPEN_CONFIRMED` with protection `PROTECTION_UNVERIFIED` until independent simulator read-back

### F2-2 — `01_COMPLETE_OFFLINE_CORE_DESIGN_13_COMPONENTS.md`

*Why:* UNKNOWN/UNVERIFIED is not a protection-axis value in the pinned specification.

Old:

    remains `UNKNOWN/UNVERIFIED` with frozen trailing

New:

    remains `PROTECTION_UNVERIFIED` (or `PROTECTION_DRIFT` when a defect is proven) with frozen trailing

### F2-3 — `03_BROKER_NEUTRAL_EXECUTION_AND_SIMULATOR_CONTRACT.md`

*Why:* Three labels in one sentence that the pinned specification does not contain.

Old:

    Transition the position to `OPEN_UNVERIFIED_PROTECTION` with protection `UNKNOWN`/`PENDING`; do not label `OPEN_CONFIRMED_WITH_VERIFIED_PROTECTION` merely because

New:

    Set the position axis to `OPEN_CONFIRMED` (`D03-SRC-015`, fill proven) and the protection axis to `PROTECTION_UNVERIFIED` (`D03-SRC-020`); do not set `PROTECTION_VERIFIED` merely because

### F2-4 — `03_BROKER_NEUTRAL_EXECUTION_AND_SIMULATOR_CONTRACT.md`

*Why:* VERIFIED_APPLIED is not in the pinned specification.

Old:

    A verified match transitions protection to `VERIFIED_APPLIED` and releases

New:

    A verified match moves protection from `PROTECTION_UNVERIFIED` to `PROTECTION_VERIFIED` (`D03-SRC-028`) and releases

### F2-5 — `03_BROKER_NEUTRAL_EXECUTION_AND_SIMULATOR_CONTRACT.md`

*Why:* Same.

Old:

    remains `UNVERIFIED/UNKNOWN`, freezes trailing

New:

    remains `PROTECTION_UNVERIFIED` (or becomes `PROTECTION_DRIFT` when a defect is proven, `D03-SRC-023`), freezes trailing

### F2-6 — `03_BROKER_NEUTRAL_EXECUTION_AND_SIMULATOR_CONTRACT.md`

*Why:* Same; BROKER_OUTCOME_UNKNOWN is the pinned position-axis value for an unproven outcome (D03-SRC-016).

Old:

    must recover with `UNKNOWN` or `OPEN_UNVERIFIED_PROTECTION`, full reservations

New:

    must recover with position `BROKER_OUTCOME_UNKNOWN` (if the fill itself is not proven) or position `OPEN_CONFIRMED` with protection `PROTECTION_UNVERIFIED`, full reservations

### F2-7 — `08_ACCEPTANCE_TEST_CONTRACT_AND_FAILURE_MATRIX.md`

*Why:* TC-INIT-03 expected result used the invented label.

Old:

    | `OPEN_UNVERIFIED_PROTECTION`, reserve filled

New:

    | position `OPEN_CONFIRMED`, protection `PROTECTION_UNVERIFIED`, reserve filled

### F2-8 — `08_ACCEPTANCE_TEST_CONTRACT_AND_FAILURE_MATRIX.md`

*Why:* TC-INIT-04 expected result used the invented label.

Old:

    | `VERIFIED_APPLIED` only after proof

New:

    | `PROTECTION_VERIFIED` only after proof

### F2-9 — `08_ACCEPTANCE_TEST_CONTRACT_AND_FAILURE_MATRIX.md`

*Why:* Family summary: the axis that is verified is protection, not position.

Old:

    position never VERIFIED before authoritative applied-stop and quantity proof

New:

    protection never `PROTECTION_VERIFIED` before authoritative applied-stop and quantity proof

### F3-1 — `00_READ_ME_FIRST.md`

*Why:* Two pinned sources appear to disagree on the duration; precedence is stated once.

Old:

    for an indivisible group it restarts the whole group clock.

New:

    for an indivisible group it restarts the whole group clock.
    
    **Precedence over the pinned Group 1 addendum:** `SOURCE_PINS_UNMODIFIED/GROUP1_V2_ADDENDUM_UNCHANGED.json` was written before the owner's decision and still records `cooling_off_duration: UNSET`. The owner's 27 Oct decision (`d3f39baa…`, 48 hours) supersedes that statement for duration only; no other statement in the addendum changes.

### F4-1 — `14_GROUP_48H_CLOCK_NOT_STARTED.json`

*Why:* Clock file named package V1; the package is V2 (now the next revision).

Old:

    "package_id": "V3-ONE-STAGE-OFFLINE-CORE-CANDIDATE-20261113-V1"

New:

    "package_id": "@@NEW_ID@@"

### F4-2 — `00_READ_ME_FIRST.md`

*Why:* New revision carries a new ID, equal in file 00, file 14 and the manifest.

Old:

    **Artifact ID:** `V3-ONE-STAGE-OFFLINE-CORE-CANDIDATE-20261113-V2`

New:

    **Artifact ID:** `@@NEW_ID@@`

### F5-1 — `02_SCOPE_C_COMPLETE_18_MODULE_SCHEDULE.csv`

*Why:* CandidatePublisher row still pointed at a later slice although EXT-07 is excluded and unchanged.

Old:

    "Later offline slice, separate scope"

New:

    NONE_IN_OFFLINE_MODE; EXT-07 stays excluded and reserved

### F6-1 — `21_MERGED_REVIEW_FINDING_DISPOSITION.md`

*Why:* Package records what the replay found and that it is applied.

Old:

    This is a corrected **candidate**, not a freeze-ready final group.

New:

    This is a corrected **candidate**, not a freeze-ready final group.
    
    ## R2 mechanical replay of V2 and the residual fixes
    
    R2 replayed V2 once (`REVIEW_EVIDENCE/R2_replay_of_V2_and_residual_fix_list_20261113.md`; AI, not human independent). Everything else in V2 passed. It found these residual items: exact old/new amendment text (now file 23, one controlling form), the EXT section 1.2 row in file 04, protection state names aligned to the pinned ledger specification, one precedence sentence over the Group 1 addendum's UNSET duration, package identifiers, and the review-evidence folder carrying the current checker. They are applied in this revision. The author's own run of `verify_v2_replay.py` is the check; no further R2 review round is part of the process.

### Member 23 — `23_CONTROLLED_AMENDMENT_EXACT_TEXT.csv`

Nine rows AM-01..AM-09 with columns `amendment_id, pinned_file, exact_old_text, exact_new_text, takes_effect, negative_test_id`, generated from `cons_review_edits.AMEND`. Every `takes_effect` reads: "only when the owner signs the G0-R record against the final group root".

### REVIEW_EVIDENCE/

Replace the folder's contents with the eight files in the attached evidence ZIP, then regenerate the manifest (the script does both).
