#!/usr/bin/env python3
"""R2's single mechanical replay of the author's V2 consolidated package, and the check the author re-runs
after applying v2_residual_edits.py.

  review  V2_DIR WORK_DIR OUT_PREFIX EVIDENCE_DIR [--zip V2.zip]
          R2's run: facts about V2 as delivered, the residual-fix simulation, leave-one-out, planted faults, positive control.
  replay  FIXED_DIR
          the author's re-run on the revised package (post-fix checks only).

The checks inherited from verify_cons_review.py (manifest, pins, B1-B7, C1, S) are run unchanged, except the
seven R1.*/B5.f checks that tested file NAMES the author chose differently (file 19 in V2 is the independence table).
Those seven are replaced by the V-series below, which test the same substance against V2's own file names.
Every check prints PASS or FAIL. Exit code 1 if any FAIL.
"""
import csv, io, json, os, re, shutil, sys

sys.dont_write_bytecode = True  # running in place must not add files that the manifest does not list

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import verify_cons_review as V  # noqa: E402
import v2_residual_edits as RE  # noqa: E402

CE = V.CE
F23 = RE.F23
V2_ZIP_SHA = RE.V2_ZIP_SHA
INVENTED = ["OPEN_UNVERIFIED_PROTECTION", "OPEN_CONFIRMED_WITH_VERIFIED_PROTECTION", "VERIFIED_APPLIED", "UNVERIFIED/UNKNOWN", "UNKNOWN/UNVERIFIED", "UNKNOWN`/`PENDING"]
EVIDENCE_NAMES = ["README.md", "R2_review_of_consolidated_offline_core_package_and_change_list_20261113.md", "R2_replay_of_V2_and_residual_fix_list_20261113.md",
                  "cons_review_edits.py", "verify_cons_review.py", "required_pins.json", "v2_residual_edits.py", "verify_v2_replay.py"]


def pinned_text(d):
    out = ""
    pins = os.path.join(d, "SOURCE_PINS_UNMODIFIED")
    for root, _, fs in os.walk(pins):
        for f in fs:
            if f.endswith((".md", ".json")):
                out += open(os.path.join(root, f), encoding="utf-8", errors="replace").read()
    return out


def v_checks(d, res, expect_id=None):
    P = res.add
    rd = lambda n: V.rd(d, n)
    files = os.listdir(d)
    pins = os.path.join(d, "SOURCE_PINS_UNMODIFIED")
    t00, t01, t02, t03, t04, t08, t10, t12, t20, t21 = [rd(n) for n in [
        "00_READ_ME_FIRST.md", "01_COMPLETE_OFFLINE_CORE_DESIGN_13_COMPONENTS.md", "02_SCOPE_C_COMPLETE_18_MODULE_SCHEDULE.csv",
        "03_BROKER_NEUTRAL_EXECUTION_AND_SIMULATOR_CONTRACT.md", "04_CONTROLLED_SCOPE_SOURCE_AMENDMENT_SCHEDULE.md",
        "08_ACCEPTANCE_TEST_CONTRACT_AND_FAILURE_MATRIX.md", "10_GOVERNANCE_CONFORMANCE_AND_SINGLE_48H_RULE.md",
        "12_G0R_DESIGN_OWNER_ACCEPTANCE_FORM_UNSIGNED.md", "20_CONTROLLED_SOURCE_SUPERSESSION_PROPOSAL_NOT_ADOPTED.md",
        "21_MERGED_REVIEW_FINDING_DISPOSITION.md"]]
    j14 = json.loads(rd("14_GROUP_48H_CLOCK_NOT_STARTED.json"))
    mf = json.load(open(os.path.join(d, "MANIFEST_SHA256.json"), encoding="utf-8"))

    # ---- F1 exact amendment text, one controlling form
    am_p = os.path.join(d, F23)
    am = list(csv.DictReader(io.StringIO(open(am_p, encoding="utf-8").read()))) if os.path.isfile(am_p) else []
    bad = []
    for r in am:
        fp = os.path.join(pins, r["pinned_file"])
        txt = open(fp, encoding="utf-8").read() if os.path.isfile(fp) else ""
        if txt.count(r["exact_old_text"]) != 1 or not r["exact_new_text"].strip() or r["exact_new_text"] == r["exact_old_text"] or not r["takes_effect"].strip() or not r["negative_test_id"].strip():
            bad.append(r["amendment_id"])
    P("V.1 file 23 has AM-01..AM-09; each old text occurs exactly once in its pinned file; each new text is non-empty and different; each has an effect condition and a negative test", [r["amendment_id"] for r in am] == ["AM-0%d" % i for i in range(1, 10)] and not bad, "bad: %s" % bad)
    P("V.2 files 04 and 20 name file 23 as controlling", all(("23_CONTROLLED_AMENDMENT_EXACT_TEXT.csv" in t and "file 23 controls" in t) for t in (t04, t20)))
    P("V.3 file 04 has a row for EXT section 1.2 invariant 1 that cites AM-01", "| EXT section 1.2 invariant 1 |" in t04 and "(AM-01)" in t04)
    P("V.4 files 10, 12 and 21 name file 23; 21 no longer calls file 20 exact", all("23_CONTROLLED_AMENDMENT_EXACT_TEXT.csv" in t or " 23 " in t for t in (t10, t12)) and "in file 23" in t21 and "*proposal* in file 20" not in t21 and "precisely proposed in 20" not in t21)
    P("V.5 file 00 lists members 19-23 and no longer says the 34 rows are 'to be classed'", "`23_...csv`" in t00 and "`22_PRIMARY_EVIDENCE_MOUNT_AND_CONTENT_SHA256.md`" in t00 and "to be classed" not in t00)

    # ---- F2 protection names equal the pinned ledger specification
    inv = [(f, s) for f, t in (("01", t01), ("03", t03), ("08", t08)) for s in INVENTED if s in t]
    P("V.6 none of the labels that the pinned specification lacks appears in files 01, 03, 08", not inv and "position never VERIFIED" not in t08, str(inv))
    allpins = pinned_text(d)
    toks = set()
    for t in (t01, t03, t08):
        toks |= set(re.findall(r"`([A-Z_]*PROTECTION[A-Z_]*|OPEN_CONFIRMED|BROKER_OUTCOME_UNKNOWN)`", t))
    notpinned = sorted(x for x in toks if x not in allpins)
    P("V.7 every protection or position state named in 01, 03, 08 exists in the pinned specification bytes", not notpinned and {"PROTECTION_UNVERIFIED", "PROTECTION_VERIFIED", "OPEN_CONFIRMED"} <= toks, "not pinned: %s; found: %s" % (notpinned, sorted(toks)))
    ids = ["TC-INIT-%02d" % i for i in range(1, 11)]
    P("V.8 file 08 keeps TC-INIT-01..10 and TC-AUDIT; file 03 keeps initial_protection_spec", all(("| %s |" % i) in t08 for i in ids) and "| TC-AUDIT |" in t08 and "initial_protection_spec" in t03)

    # ---- F3 precedence over the Group 1 addendum
    add = open(os.path.join(pins, "GROUP1_V2_ADDENDUM_UNCHANGED.json"), encoding="utf-8").read()
    P("V.9 file 00 states that the 27 Oct decision supersedes the pinned addendum's UNSET duration, for duration only", '"cooling_off_duration": "UNSET"' in add and "supersedes that statement for duration only" in t00 and "cooling_off_duration: UNSET" in t00)

    # ---- F4 identifiers and clock
    m = re.search(r"\*\*Artifact ID:\*\* `([^`]+)`", t00)
    aid = m.group(1) if m else None
    same = aid and j14.get("package_id") == aid == mf.get("id")
    P("V.10 package id is the same in file 00, file 14 and the manifest" + (" (= %s)" % expect_id if expect_id else ""), same and (expect_id is None or aid == expect_id), "00=%s 14=%s manifest=%s" % (aid, j14.get("package_id"), mf.get("id")))
    P("V.11 clock file: required 48 hours, elapsed 0, NOT_STARTED, no timestamps, no permission", j14.get("required_duration_hours") == 48 and j14.get("duration_elapsed_hours") == 0 and j14.get("status") == "NOT_STARTED" and j14.get("latest_final_evidence_bound_presentation_utc") is None and j14.get("wait_completed_utc") is None and j14.get("implementation_permission") is False)
    P("V.12 manifest records the V2 ZIP it supersedes", mf.get("supersedes_candidate_sha256") == V2_ZIP_SHA)

    # ---- F5 wording
    P("V.13 the three stale 'later' phrases are gone from file 02", all(s not in t02 for s in ["Actual decision engine later", "Monetary ledger after approved separate slice", "Later offline slice, separate scope"]))

    # ---- F6 record + evidence folder
    P("V.14 file 21 records the R2 replay of V2", "R2 mechanical replay of V2 and the residual fixes" in t21 and "verify_v2_replay.py" in t21)
    ev = os.path.join(d, "REVIEW_EVIDENCE")
    have = set(os.listdir(ev)) if os.path.isdir(ev) else set()
    ce = open(os.path.join(ev, "cons_review_edits.py"), encoding="utf-8").read() if "cons_review_edits.py" in have else ""
    vc = open(os.path.join(ev, "verify_cons_review.py"), encoding="utf-8").read() if "verify_cons_review.py" in have else ""
    P("V.15 REVIEW_EVIDENCE holds the current evidence set (rev 2 change list and checker, replay report, residual edits, this checker)", set(EVIDENCE_NAMES) <= have and "R1-9" in ce and "R1.f" in vc, "missing: %s" % sorted(set(EVIDENCE_NAMES) - have))


def post_fix(d, res, expect_id=None):
    inh = V.R()
    V.post_fix_checks(d, inh, strict=True)
    for cid, ok, det in inh.rows:
        if cid.startswith("R1.") or cid.startswith("B5.f"):
            continue
        res.add(cid, ok, det)
    v_checks(d, res, expect_id)


# ------------------------------------------------------------------------------------------------
def facts_about_v2(v2, res, v2zip=None):
    P = res.add
    pins = os.path.join(v2, "SOURCE_PINS_UNMODIFIED")
    rd = lambda n: V.rd(v2, n)
    if v2zip:
        P("A01 the V2 ZIP SHA-256 equals 6888d01c...", V.sha_f(v2zip) == V2_ZIP_SHA)
    V.manifest_check(v2, res)
    want = {"MASTER_V1_8_CORRECTED_UNCHANGED.md": "dce9968ec3645cd03b786409c86eeb513826df9b6d14b340533973b7c08aafdd", "EXT_G0R_14_UNCHANGED.md": "256ad6bd0d78f30e5e005f4fde64f13021d36286c8512640b2adf91a62153092", "WDA_08_UNCHANGED.md": "01697219278154ac808cebdafc6575b93a5ea7ca9cbb2310331a5b30f78966c6", "ATC_01_REV2_UNCHANGED.md": "ce5301c17b7a8e17b161bea808e4691986b8943b99edc416e0062ff482cf8039", "GROUP1_PRINCIPLES_UNCHANGED.md": "be6dad1f3247cf882a1912e91bc67c979e0f605d03ece1f3dcfb424d2d132e15", "R2_STAGE_D03_REPLAY_REPORT_UNCHANGED.md": "b60c98c4d87924286a0530bde3bf307a10dadde354bf5d4fea472c19f2a7d8f4", CE.DEC_NAME: CE.DEC_SHA, V.PINS["d03_v3_design"]["file"]: V.PINS["d03_v3_design"]["sha256"], V.PINS["d04_v2_design"]["file"]: V.PINS["d04_v2_design"]["sha256"], "STAGE_D01_INTEGRATED_TECHNICAL_SPECIFICATION_UNCHANGED.md": V.PINS["stage_d03_zip"]["members"]["00_STAGE_D01_INTEGRATED_TECHNICAL_SPECIFICATION.md"]}
    P("A02 the pinned master, EXT, WDA-08, ATC-01, Group 1 principles, R2 replay report, 27 Oct decision, D03 V3, D04 V2 and the Stage D01 specification carry their agreed hashes", all(V.sha_f(os.path.join(pins, k)) == v for k, v in want.items()))
    zp = os.path.join(pins, "War_Rig_V3_StageD03_Bounded_Mechanical_Residual_Fixes_20261113.zip")
    P("A03 the Stage D03 ZIP copy equals 23bdbe3b... and its members 00-07 and 12 equal the pinned member hashes", V.sha_f(zp) == V.PINS["stage_d03_zip"]["sha256"] and all(V.sha_f(os.path.join(pins, "STAGE_D03_REVIEW_BYTES", k)) == v for k, v in V.PINS["stage_d03_zip"]["members"].items() if os.path.isfile(os.path.join(pins, "STAGE_D03_REVIEW_BYTES", k))) and len(os.listdir(os.path.join(pins, "STAGE_D03_REVIEW_BYTES"))) == 9)
    plan = json.load(open(os.path.join(pins, "STAGE_D03_REVIEW_BYTES", "06_DETERMINISTIC_TEST_PLAN_UNEXECUTED.json"), encoding="utf-8"))
    P("A04 the pinned test plan contains 187 test cases", len(plan["tests"]) == 187)
    inh = V.R()
    V.post_fix_checks(v2, inh, strict=True)
    keep = [r for r in inh.rows if not (r[0].startswith("R1.") or r[0].startswith("B5.f"))]
    P("A05 all %d inherited checks (B1-B7, C1, S and the pins) pass on V2 as delivered" % len(keep), all(r[1] for r in keep), str([r[0] for r in keep if not r[1]]))
    t01, t03, t04, t08, t20, t21, t00, t02 = [rd(n) for n in ["01_COMPLETE_OFFLINE_CORE_DESIGN_13_COMPONENTS.md", "03_BROKER_NEUTRAL_EXECUTION_AND_SIMULATOR_CONTRACT.md", "04_CONTROLLED_SCOPE_SOURCE_AMENDMENT_SCHEDULE.md", "08_ACCEPTANCE_TEST_CONTRACT_AND_FAILURE_MATRIX.md", "20_CONTROLLED_SOURCE_SUPERSESSION_PROPOSAL_NOT_ADOPTED.md", "21_MERGED_REVIEW_FINDING_DISPOSITION.md", "00_READ_ME_FIRST.md", "02_SCOPE_C_COMPLETE_18_MODULE_SCHEDULE.csv"]]
    ext = rd("SOURCE_PINS_UNMODIFIED/EXT_G0R_14_UNCHANGED.md")
    # facts behind the residual items
    P("A06 [F1] V2 has no member with exact old/new amendment text; file 20 is prose; file 21 calls it exact", not any(f.startswith("23_") for f in os.listdir(v2)) and "exact_old_text" not in t20 and "Exact controlled supersession *proposal* in file 20" in t21)
    P("A07 [F1] pinned EXT section 1.2 prohibits order/stop/close operations in G1-R; V2 file 04 has no row for it", "real market-data network acquisition, order/stop/close operations, external notifications" in ext and "1.2" not in t04)
    inv = [s for t in (t01, t03, t08) for s in INVENTED if s in t]
    P("A08 [F2] V2 files 01, 03, 08 use protection/position labels that are not in any pinned source", len(inv) >= 6 and not any(s in pinned_text(v2) for s in ["OPEN_UNVERIFIED_PROTECTION", "OPEN_CONFIRMED_WITH_VERIFIED_PROTECTION", "VERIFIED_APPLIED"]), str(inv))
    st = rd("SOURCE_PINS_UNMODIFIED/STAGE_D01_INTEGRATED_TECHNICAL_SPECIFICATION_UNCHANGED.md")
    P("A09 [F2] the pinned specification names protection PROTECTION_UNVERIFIED/VERIFIED/DRIFT and position OPEN_CONFIRMED/BROKER_OUTCOME_UNKNOWN", all(x in st for x in ["PROTECTION_UNVERIFIED", "PROTECTION_VERIFIED", "PROTECTION_DRIFT", "OPEN_CONFIRMED", "BROKER_OUTCOME_UNKNOWN", "D03-SRC-015", "D03-SRC-020", "D03-SRC-028"]))
    add = rd("SOURCE_PINS_UNMODIFIED/GROUP1_V2_ADDENDUM_UNCHANGED.json")
    P("A10 [F3] the pinned Group 1 addendum records cooling_off_duration UNSET and V2 file 00 has no precedence sentence", '"cooling_off_duration": "UNSET"' in add and "supersedes that statement" not in t00)
    j14 = json.loads(rd("14_GROUP_48H_CLOCK_NOT_STARTED.json"))
    mf = json.load(open(os.path.join(v2, "MANIFEST_SHA256.json")))
    P("A11 [F4] file 14 names package V1 while file 00 and the manifest name V2", j14["package_id"].endswith("-V1") and mf["id"].endswith("-V2") and "-V2`" in t00)
    P("A12 [F5] CandidatePublisher row in file 02 still says 'Later offline slice, separate scope'", "Later offline slice, separate scope" in t02 and "Actual decision engine later" not in t02 and "Monetary ledger after approved separate slice" not in t02)
    ev = os.path.join(v2, "REVIEW_EVIDENCE")
    ce = open(os.path.join(ev, "cons_review_edits.py"), encoding="utf-8").read()
    P("A13 [F6] V2 REVIEW_EVIDENCE carries the first-revision change list and checker (no R1 items), not the current set", "R1-1" not in ce and "R1.f" not in open(os.path.join(ev, "verify_cons_review.py"), encoding="utf-8").read())
    P("A14 [substance, passes] V2 already carries TC-INIT-01..10, a TC-AUDIT row, initial_protection_spec, clock required 48 / elapsed 0, and the two corrected schedule rows", all(("| TC-INIT-%02d |" % i) in t08 for i in range(1, 11)) and "| TC-AUDIT |" in t08 and "initial_protection_spec" in t03 and j14["required_duration_hours"] == 48 and j14["duration_elapsed_hours"] == 0)
    P("A15 [status, passes] V2 is still design-only: not frozen, no clock, forms unsigned, 61 rows NOT_SELECTED", all(s in t00 for s in ["NOT_FROZEN", "NO_48H_CLOCK", "NO_G1_AUTHORITY"]) and j14["status"] == "NOT_STARTED")


# ------------------------------------------------------------------------------------------------
def controls(v2, work, evidence, res):
    base = os.path.join(work, "fixed")
    loo = []
    n_edits = len(RE.EDITS)
    for e in list(RE.EDITS):
        d = os.path.join(work, "loo")
        RE.apply(v2, d, evidence, skip=(e["id"],))
        r2 = V.R()
        V.manifest_check(d, r2)
        post_fix(d, r2, RE.DEFAULT_NEW_ID)
        loo.append((e["id"], bool(r2.fails())))
    for nm, kw in (("F1-member", dict(with_member=False)), ("F1-evidence", dict(with_evidence=False))):
        d = os.path.join(work, "loo")
        RE.apply(v2, d, evidence, **kw)
        r2 = V.R()
        V.manifest_check(d, r2)
        post_fix(d, r2, RE.DEFAULT_NEW_ID)
        loo.append((nm, bool(r2.fails())))
    notflag = [i for i, f in loo if not f]
    res.add("K1 leave-one-out: dropping any one of the %d edits, the new member 23 or the evidence replacement makes at least one check FAIL" % n_edits, not notflag, "not flagged: %s" % notflag)

    def planted(cid, mutate, expect):
        d = os.path.join(work, "planted")
        if os.path.exists(d):
            shutil.rmtree(d)
        shutil.copytree(base, d)
        mutate(d)
        r2 = V.R()
        post_fix(d, r2, RE.DEFAULT_NEW_ID)
        f = [x[0] for x in r2.fails()]
        res.add("K2 planted: %s is detected (%s FAIL)" % (cid, "/".join(expect)), all(any(x.startswith(p) for x in f) for p in expect), "failed: %s" % f)

    def w(d, name, fn):
        p = os.path.join(d, name)
        t = open(p, encoding="utf-8", newline="").read()
        open(p, "w", encoding="utf-8", newline="").write(fn(t))

    planted("an amendment old text no longer verbatim", lambda d: w(d, F23, lambda t: t.replace("order/stop/close operations, external notifications", "order/stop/close operation, external notifications", 1)), ["V.1"])
    planted("an amendment row removed", lambda d: w(d, F23, lambda t: "\n".join(l for l in t.split("\n") if not l.startswith("AM-07"))), ["V.1"])
    planted("a pinned source changed by one byte (EXT)", lambda d: w(d, "SOURCE_PINS_UNMODIFIED/EXT_G0R_14_UNCHANGED.md", lambda t: t.replace("Five distinct", "Four distinct", 1)), ["V.1"])
    planted("an invented protection label put back in file 08", lambda d: w(d, "08_ACCEPTANCE_TEST_CONTRACT_AND_FAILURE_MATRIX.md", lambda t: t.replace("`PROTECTION_VERIFIED` only after proof", "`VERIFIED_APPLIED` only after proof", 1)), ["V.6"])
    planted("a made-up PROTECTION_ state name in file 03", lambda d: w(d, "03_BROKER_NEUTRAL_EXECUTION_AND_SIMULATOR_CONTRACT.md", lambda t: t.replace("`PROTECTION_UNVERIFIED` (`D03-SRC-020`)", "`PROTECTION_PENDING` (`D03-SRC-020`)", 1)), ["V.7"])
    planted("TC-INIT-07 row deleted", lambda d: w(d, "08_ACCEPTANCE_TEST_CONTRACT_AND_FAILURE_MATRIX.md", lambda t: "\n".join(l for l in t.split("\n") if not l.startswith("| TC-INIT-07 |"))), ["V.8"])
    planted("precedence sentence removed", lambda d: w(d, "00_READ_ME_FIRST.md", lambda t: t.replace("supersedes that statement for duration only", "is noted", 1)), ["V.9"])
    planted("clock file package id back to V1", lambda d: w(d, "14_GROUP_48H_CLOCK_NOT_STARTED.json", lambda t: t.replace(RE.DEFAULT_NEW_ID, RE.OLD_ID_V1, 1)), ["V.10"])
    planted("clock started by mistake", lambda d: w(d, "14_GROUP_48H_CLOCK_NOT_STARTED.json", lambda t: t.replace('"status": "NOT_STARTED"', '"status": "RUNNING"', 1)), ["V.11"])
    planted("elapsed hours set to 48 again", lambda d: w(d, "14_GROUP_48H_CLOCK_NOT_STARTED.json", lambda t: t.replace('"duration_elapsed_hours": 0', '"duration_elapsed_hours": 48', 1)), ["V.11"])
    planted("stale 'later slice' phrase restored", lambda d: w(d, "02_SCOPE_C_COMPLETE_18_MODULE_SCHEDULE.csv", lambda t: t.replace("NONE_IN_OFFLINE_MODE; EXT-07 stays excluded and reserved", "\"Later offline slice, separate scope\"", 1)), ["V.13"])
    planted("old checker back in REVIEW_EVIDENCE", lambda d: w(d, "REVIEW_EVIDENCE/verify_cons_review.py", lambda t: t.replace("R1.f", "R1_f")), ["V.15"])
    planted("one inherited condition broken (a finding dropped from file 18)", lambda d: w(d, "18_REGISTER_DISPOSITION_CLASSES.csv", lambda t: "\n".join(l for l in t.split("\n") if not l.startswith("D03-FREEZE-01,"))), ["B7.e0"])


def main(argv):
    if argv[1] == "replay":
        d = argv[2]
        res = V.R()
        V.manifest_check(d, res)
        post_fix(d, res)
        return report(res, None)
    v2, work, outp, evidence = argv[2], argv[3], argv[4], argv[5]
    v2zip = argv[argv.index("--zip") + 1] if "--zip" in argv else None
    os.makedirs(work, exist_ok=True)
    res = V.R()
    facts_about_v2(v2, res, v2zip)
    fixed = os.path.join(work, "fixed")
    RE.apply(v2, fixed, evidence)
    V.manifest_check(fixed, res)
    post_fix(fixed, res, RE.DEFAULT_NEW_ID)
    controls(v2, work, evidence, res)
    return report(res, outp)


def report(res, outp):
    lines = ["%s  %s%s" % ("PASS" if ok else "FAIL", cid, ("  -- " + det) if (det and not ok) else "") for cid, ok, det in res.rows]
    npass = sum(1 for r in res.rows if r[1])
    lines += ["", "TOTAL %d checks: %d PASS, %d FAIL" % (len(res.rows), npass, len(res.rows) - npass)]
    txt = "\n".join(lines)
    print(txt)
    if outp:
        open(outp + ".txt", "w").write(txt + "\n")
        json.dump([{"id": c, "pass": o, "detail": d} for c, o, d in res.rows], open(outp + ".json", "w"), indent=1)
    return 1 if res.fails() else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
