# R2 review of the V4 candidate and the one-file design document (13 Nov 2026)

Reviewer: R2, an AI reviewer. Nothing here is human-independent evidence, an owner acceptance, a freeze or a start of the 48-hour clock. Jon alone approves.

Reviewed: `War_Rig_V3_Complete_Offline_Design_V4_MSB_REVIEW_CANDIDATE_20261113.zip` (SHA-256 `78b4a4b1a13c9ba86b2dbcf98bfac14c2818e1fbe8d5f3c514b53b00085106dd`, 789,990 bytes) and `War_Rig_V3_ONE_COMPLETE_OFFLINE_DESIGN_Owner_Review_20261113.md` (SHA-256 `dffd09c0c7208b63d2a54f58d4c65884275cd559cb6a9be44bb7bcf0793463db`, 1,326 lines).

## In plain words

V4 and the one-file document are sound. The package is exactly what it says it is, the one-file document reproduces every numbered member word for word, and the summary in Part I agrees with the package on every count and rule I checked. There is no design problem and no new stage.

The author found three wordings that claim more than the evidence supports. The author is right on all three, and **all three are wording that I wrote**. I fixed the same kind of overclaim in files 24 and 25 after the other reviewer's note, but I searched only those two files. The same overclaim was still sitting in my own edits to files 00, 15 and 21. I found a fourth one (file 21) that the author's list does not include.

I have fixed all four as exact replacements in my edits module. The package then gets the ID `...-V5`, and the author applies one command. My checker now looks for these phrases in every numbered member, so a fifth cannot hide. Nothing else changes, and no clock has started.

## What I checked on V4

| Check | Result |
|---|---|
| ZIP SHA-256 | `78b4a4b1...06dd`, equals the author's stated value |
| ZIP integrity and names | 69 entries readable, no unsafe paths |
| Manifest | 68 entries; every hash matches; no unlisted file; no listed file missing |
| Pinned sources | All 25 equal my pin table, byte for byte |
| What V4 is | V3 plus my 24 edits and AM-10 to AM-14, with files 24 and 25 as in my report revision 2. Compared with my own rebuild, only the manifest differs, and that is because V4 adds three reference-output files to `REVIEW_EVIDENCE` |
| My checker on V4 (`replay`) | 71 checks, 71 PASS, 0 FAIL, the same as the author reports |
| One-file document, Part II | All 26 numbered members (00 to 25) equal the package files word for word. CSV and JSON are fenced; member 25 is followed by a provenance footer that is not part of the member |
| One-file document, Part I | Counts and rules agree with the package: 13 components, 18 modules, 61 rows (43 + 14 + 4), 13 findings, 21 repairs, 187 test cases, 42 candidate edges, 38 guarded, 84 denied (this one is pinned in the Stage D01 text), 26 members, 68 manifest entries, ZIP about 790 KB |
| Clock and status | `NOT_STARTED`, no signatures, `implementation_permission: false`, Path 1 as recorded in file 10 |

## The four wordings, with exact fixes

| # | Where | Words now | Replace with | Whose text |
|---|---|---|---|---|
| 1 | File 24, section 13 table, the two Signal ML V2 `.joblib` sets | `CREATED_UNREGISTERED; not promoted; role to be taken from...` | `CREATED_UNREGISTERED; promoted_for_live NOT_VERIFIED_BY_R2 (E6); role to be taken from...` | Mine (report revision 1). Author found it. |
| 2 | File 15, remaining items | `Core-5 frozen model artifacts (none exist; MS-F ...` | `Core-5 frozen model artifacts (none registered or eligible in the inspected locations; other hosts and S3 not checked; MS-F ...` | Mine (edit G3-7). Author found it. |
| 3 | File 00, "Important boundary" | `UNAVAILABLE because V2 trains them afresh on each run and keeps no file.` | `UNAVAILABLE for offline serving, because no registered frozen Core-5 artifact was identified in the inspected locations and the V2 inference code that R2 holds trains afresh on each run (this is not proof that no model exists elsewhere).` | Mine (edit G1-1). Author found it. |
| 4 | File 21, MS-B record | `no Core-5 model file exists, V2 fits a model on every run, and six other model files exist (file 25).` | `no Core-5 model file was found on the one inspected host, the V2 inference code that R2 holds fits a model on every run, and six other model files exist (file 25).` | Mine (edit G4-3). **Not in the author's list.** |

Why each matters: the inventory covers one host and three copies of `live_inference.py`. The live-folder hash is still `PENDING_OWNER_CHECK`, and S3 was not checked. "None exist", "keeps no file" and "no file exists" say more than that. The status `UNAVAILABLE` is still right; it is a serving classification.

The fixes are items 2, 3 and 4 in `msb_edits.py` (edits G3-7, G1-1, G4-3) and item 1 in `members/24_...md`. The package ID in `msb_edits.py` is now `V3-ONE-STAGE-OFFLINE-CORE-CANDIDATE-20261113-V5`, because the bytes change.

## What the author does next (one pass, no new stage)

    python3 -I -B msb_edits.py V3_UNZIPPED_DIR NEW_DIR EVIDENCE_DIR
    python3 -I -B verify_msb.py replay NEW_DIR

The second command should print 71 checks, 71 PASS. Then regenerate the one-file document from the V5 package:

- Part I section J: the three corrections become a short note that they were applied (with the fourth), and the "not silently incorporated" wording goes.
- Part II: the members 00, 15, 21 and 24 change as above.
- The provenance footer takes the V5 ZIP hash.

## Results

| Check | Result |
|---|---|
| R2 review run on V3 plus the edits (`review` mode) | 114 checks, 114 PASS, 0 FAIL; two clean runs identical |
| Includes | the four fixes; leave-one-out over every edit, amendment and member; 23 planted faults, including each overclaim put back in files 00, 15 and 24 |
| Author-style replay on the V5 package built from V3 plus the edits | 71 checks, 71 PASS |

## What I did not establish

- The live-folder file, the training manifests, S3 and the six files' convertibility are still open, as in the MS-B report.
- I did not re-derive the 42, 38 and 84 edge counts or the 187 test cases. I confirmed that the Part I figures are the figures in the pinned Stage D01 text and the package.
- I did not read Part II for meaning; I verified that it equals the package members. The members themselves were reviewed in the earlier rounds.
- I ran no test. The independent-review route, the V32 clause text and the G1-R environment packet are owner-side, as before.

## Your selections (unchanged, listed once)

1. Accept MS-B as written, with AM-10 to AM-14, file 25 and tests MSB-01 to MSB-19.
2. Confirm `OC-D04-04` stays DEFER.
3. Note that MS-F (fit-and-freeze) is a separate later authorisation.
