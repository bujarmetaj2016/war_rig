#!/usr/bin/env python3
"""MS-B (CONTROLLED_DUAL_SOURCE_PREDICTIONS / NO_REFIT) edits for the author's V3 package
(War_Rig_V3_One_Stage_Offline_Core_Consolidated_Candidate_V3_20261113.zip, SHA-256 0e71d874...ecf00).

Mechanical: every edit is (file, exact old text, exact new text); the old text must occur exactly the stated
number of times, otherwise the script stops and writes nothing.

  python3 -I -B msb_edits.py V3_PKG_DIR OUT_DIR EVIDENCE_DIR [NEW_PACKAGE_ID]

Order: copy V3_PKG_DIR to OUT_DIR; apply EDITS; write 23_CONTROLLED_AMENDMENT_EXACT_TEXT.csv with AM-01..AM-14;
add members 24 and 25 (from members/); replace REVIEW_EVIDENCE/; regenerate MANIFEST_SHA256.json.
Nothing in SOURCE_PINS_UNMODIFIED/ changes and nothing is selected on the owner's behalf.
"""
import csv, hashlib, io, json, os, shutil, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import cons_review_edits as CE  # noqa: E402  (AM-01..AM-09 and AMEND_HEADER)

V3_ZIP_SHA = "0e71d874dfc7d1bd26b20f3721e7995a4ec8e509cd77662e3bf861e81e8ecf00"
DEFAULT_NEW_ID = "V3-ONE-STAGE-OFFLINE-CORE-CANDIDATE-20261113-V5"
OLD_ID = "V3-ONE-STAGE-OFFLINE-CORE-CANDIDATE-20261113-V3"
F23 = "23_CONTROLLED_AMENDMENT_EXACT_TEXT.csv"
F24 = "24_MSB_CONTROLLED_DUAL_SOURCE_PREDICTIONS_CONTRACT.md"
F25 = "25_MODEL_ARTIFACT_EVIDENCE_EC2_20261113.csv"
EFFECT = "only when the owner signs the G0-R record against the final group root"
EXT = "EXT_G0R_14_UNCHANGED.md"
MAS = "MASTER_V1_8_CORRECTED_UNCHANGED.md"

# ---------------------------------------------------------------- the five pinned-source amendments (exact text)
AMEND_NEW = [
    ["AM-10", EXT,
     "**Keep rejection of actual registry/fit/runtime**; allow only hash field/type and registered pure strategy with **no** model loader | `V3EXT-021` confirms permitted pure strategy cannot import a loader; original M remains negative",
     "**Keep rejection of any fit, training, calibration fitting, promotion, activation for live use, just-in-time training, executable deserialisation (pickle, joblib, dill, cloudpickle, marshal, shelve, numpy allow_pickle) and any model registry or loader import anywhere except the single module `v3/offline/model_intake.py`**; that module may read only the allow-listed non-executable artifact formats of consolidated file 24, and only for an owner-registered artifact that passes every MS-B gate; allow also the hash field/type and the registered pure strategy (the signed test-score source), which still has **no** model loader | `V3EXT-021` still confirms the pure strategy cannot import a loader; MSB-04, MSB-05, MSB-09 and MSB-15 of file 24 are the negative oracles for the loader, and original M remains negative for every other module",
     EFFECT, "MSB-04, MSB-05, MSB-09, MSB-15, V3EXT-021"],
    ["AM-11", EXT,
     "Model/runtime registry import rejected | `UNCHANGED_NEGATIVE` | No ModelArtifactRegistry loader/runtime import; pure strategy interface only; V3EXT-021 |",
     "Model/runtime registry import rejected | `NARROWED_BY_AM-10` | No model registry or loader import in any module except `v3/offline/model_intake.py`; no fit or runtime registry anywhere; pure strategy interface only; V3EXT-021 unchanged |",
     EFFECT, "MSB-15"],
    ["AM-12", EXT,
     "no V2 bytes, live DB mounts or production cohort reads in G1-R |",
     "no V2 bytes (the one exception is an owner-registered converted model artifact admitted under MS-B, file 24: it is data, it enters only through the model-intake route, and it is never an archive member, V2 code or a V2 DB read), live DB mounts or production cohort reads in G1-R |",
     EFFECT, "MSB-05, V3EXT-025, V3EXT-027"],
    ["AM-13", MAS,
     "**EXCLUDED from G1-R runtime and mocks.** Only a hash field/type in `effective_policy.py` is in scope, not an artifact loader or model registry implementation; later scope grant required.",
     "**Controlled dual-source predictions only (MS-B, consolidated file 24).** In G1-R this module returns a `SignalScore` either from a signed test-score set or, through the single module `v3/offline/model_intake.py`, from an owner-registered, immutable, non-executable trained-model artifact; there is no fitting, no promotion, no runtime registry, no pickle or joblib. This is the later scope grant this row anticipated. Registered artifacts are not group members.",
     EFFECT, "MSB-01, MSB-12"],
    ["AM-14", EXT,
     ", model fitting or model activation. All external network egress denied",
     ", model fitting, or any model promotion or activation for live use (offline serving of an owner-registered artifact under MS-B, consolidated file 24, is neither). All external network egress denied",
     EFFECT, "MSB-09, V3EXT-015"],
]

EDITS = []


def E(eid, group, file, old, new, why, count=1):
    EDITS.append({"id": eid, "group": group, "file": file, "old": old, "new": new, "why": why, "count": count})


# ---------------------------------------------------------------- G1 the design text names the two sources
E("G1-1", "G1", "00_READ_ME_FIRST.md",
  "while trained V2/V3 model intake remains excluded pending separate controlled policy. This is not a claim of a fully integrated trained-model trading runtime.",
  "while prediction sources are governed by the proposed MS-B dual-source contract (`24_...md`, `25_...csv`): signed test scores validate the pipeline, owner-registered non-executable trained models may be read once registered, no model is fitted or promoted, and at presentation all five Core-5 trained models are recorded UNAVAILABLE for offline serving, because no registered frozen Core-5 artifact was identified in the inspected locations and the V2 inference code that R2 holds trains afresh on each run (this is not proof that no model exists elsewhere). This is not a claim of a fully integrated trained-model trading runtime.",
  "File 00 said trained-model intake is excluded; the owner chose MS-B (both sources).")
E("G1-2", "G1", "00_READ_ME_FIRST.md",
  "`23_...csv` — the **exact old and new text of the nine controlled source amendments, the controlling form** (not adopted until the owner signs G0-R).",
  "`23_...csv` — the **exact old and new text of the fourteen controlled source amendments (AM-01..AM-14), the controlling form** (not adopted until the owner signs G0-R); `24_...md` — MS-B dual-source prediction contract with 19 tests (proposed, not selected); `25_...csv` — evidence on the model files that exist today.",
  "Contents list: amendment count and the two new members.")
E("G1-3", "G1", "00_READ_ME_FIRST.md",
  "`23_CONTROLLED_AMENDMENT_EXACT_TEXT.csv`; primary bytes under",
  "`23_CONTROLLED_AMENDMENT_EXACT_TEXT.csv`, `" + F24 + "`, `" + F25 + "`; primary bytes under",
  "New-members list omitted 24 and 25.")
E("G1-4", "G1", "01_COMPLETE_OFFLINE_CORE_DESIGN_13_COMPONENTS.md",
  "ModelArtifactRegistry (hash pinning only; no model loader)",
  "ModelArtifactRegistry (two sources behind one `SignalScore` contract, MS-B: signed test scores and, through `v3/offline/model_intake.py`, owner-registered non-executable trained models)",
  "Component 02 owner module description.")
E("G1-5", "G1", "01_COMPLETE_OFFLINE_CORE_DESIGN_13_COMPONENTS.md",
  "evaluate a signed, hash-registered fixture scoring function; no trained-model loader, no fitting, no promotion",
  "return a `SignalScore` either from a signed, hash-registered test-score set (`SIGNED_TEST_SCORE`, pipeline validation only) or from an owner-registered trained model that passes the MS-B gates (`TRAINED_MODEL`); every score carries its source and fingerprint; no pickle or joblib, no fitting, no promotion, no fallback from one source to the other",
  "Component 02 behaviour.")
E("G1-6", "G1", "01_COMPLETE_OFFLINE_CORE_DESIGN_13_COMPONENTS.md",
  "Retained V2/V3 trained-model intake, training cadence and promotion are later separately authorised gates (EXT section 6 T-3; OC-D04-04) | TC-MODEL-* |",
  "Real artifact registration is separate and later; all five Core-5 trained models are UNAVAILABLE at presentation; fit-and-freeze (MS-F), training cadence and promotion are separately authorised later gates (OC-D04-04) | TC-MODEL-*, MSB-01..MSB-19 |",
  "Component 02 remaining dependency and tests.")
E("G1-7", "G1", "02_SCOPE_C_COMPLETE_18_MODULE_SCHEDULE.csv",
  "ModelArtifactRegistry,\"`EXCLUDED`; effective-policy **manifest/hash field only**, not a model loader, registry/mock or runtime\",OFFLINE_FIXTURE_SCORING_ONLY_NO_MODEL_LOADER,G1R_OFFLINE_FIXTURE,Pure signed fixture scoring function registered by hash; no trained-model loader or fitting or promotion; no IG dependency,`G1R-08-M` reject model/runtime registry import; manifest-field validation belongs to `G1R-01-A`,Retained model loader after new scope grant; A/B OPEN,NOT_SELECTED",
  "ModelArtifactRegistry,\"`EXCLUDED`; effective-policy **manifest/hash field only**, not a model loader, registry/mock or runtime\",OFFLINE_DUAL_SOURCE_PREDICTIONS_NO_REFIT,G1R_OFFLINE_FIXTURE,\"Two sources behind one SignalScore contract: signed test scores (SIGNED_TEST_SCORE) and owner-registered non-executable trained models through `v3/offline/model_intake.py` (TRAINED_MODEL); no fitting, no promotion, no pickle or joblib; no IG dependency\",\"`G1R-08-M` narrowed to one module (AM-10, AM-11); MSB-01..MSB-19; manifest-field validation belongs to `G1R-01-A`\",\"Real model registration, any fit-and-freeze (MS-F) and promotion are separate later gates; all five Core-5 trained models UNAVAILABLE at presentation; OC-D04-04 stays DEFER\",NOT_SELECTED",
  "Module row for ModelArtifactRegistry in the 18-row schedule (count stays 18).")

# ---------------------------------------------------------------- G2 amendment schedule and explanatory table
E("G2-1", "G2", "04_CONTROLLED_SCOPE_SOURCE_AMENDMENT_SCHEDULE.md",
  "(AM-01..AM-09; each old text is quoted verbatim",
  "(AM-01..AM-14; each old text is quoted verbatim",
  "Amendment range.")
E("G2-2", "G2", "04_CONTROLLED_SCOPE_SOURCE_AMENDMENT_SCHEDULE.md",
  "| EXT section 5.3 `G1R-08-M` | Rejects model/runtime registry import | Keep rejection of any model fitting, training, promotion or runtime model registry. Permit only a pure deterministic fixture scoring function registered by hash in the plug-in manifest, with no file or model loader and no network. Retained V2/V3 trained artifacts are not loadable in this grant | Negative test: any trained-model loader import is denied; replacement ID `V3EXT-021` | PROPOSED/OPEN |",
  "| EXT section 5.3 `G1R-08-M` | Rejects model/runtime registry import | Keep rejection of any fit, training, promotion, live activation and executable deserialisation, and of any registry or loader import outside `v3/offline/model_intake.py`. That module may read only the allow-listed non-executable formats of file 24, only for owner-registered artifacts that pass the MS-B gates; the pure strategy (the signed test-score source) keeps no loader (AM-10, AM-11) | MSB-04, MSB-05, MSB-09, MSB-15; `V3EXT-021` unchanged | PROPOSED/OPEN |\n| EXT `V3EXT-025` | No V2 bytes in G1-R | One exception: an owner-registered converted model artifact, which is data admitted only through the model-intake route, never an archive member, V2 code or a V2 DB read (AM-12); `V3EXT-027` and `G1R-08-X` unchanged | MSB-05; V3EXT-025, V3EXT-027 | PROPOSED/OPEN |\n| Master V1.8 section 3.1 ModelArtifactRegistry row | Says EXCLUDED from G1-R runtime and mocks and anticipates a later scope grant | Replace with controlled dual-source predictions under MS-B (AM-13); the module schedule row is in file 02 | MSB-01, MSB-12 | PROPOSED/OPEN |\n| EXT section 1.2 invariant 1 (tail) | Bans model fitting or model activation in G1-R | Keep the ban on fitting and on promotion or activation for live use; state that offline serving of an owner-registered artifact under MS-B is neither (AM-14) | MSB-09; `V3EXT-015` | PROPOSED/OPEN |",
  "Schedule row for G1R-08-M rewritten and three rows added for the other amendments.")
E("G2-3", "G2", "20_CONTROLLED_SOURCE_SUPERSESSION_PROPOSAL_NOT_ADOPTED.md",
  "`23_CONTROLLED_AMENDMENT_EXACT_TEXT.csv` (AM-01..AM-09). This table",
  "`23_CONTROLLED_AMENDMENT_EXACT_TEXT.csv` (AM-01..AM-14). This table",
  "Amendment range.")
E("G2-4", "G2", "20_CONTROLLED_SOURCE_SUPERSESSION_PROPOSAL_NOT_ADOPTED.md",
  "Keep loader, fitting, training and promotion denied; allow only signed hash-registered deterministic **fixture scorer**, not V2/V3 trained model load | G1R-08-M and V3EXT-021 negative tests remain for loader/fitting |",
  "Keep fitting, training, promotion and executable deserialisation denied; permit one intake module for owner-registered, non-executable trained models under MS-B (AM-10, AM-11); the signed test-score source stays as the registered pure strategy | G1R-08-M narrowed to one module; MSB-04, MSB-05, MSB-09, MSB-15; V3EXT-021 unchanged |",
  "Explanatory row for G1R-08-M.")

# ---------------------------------------------------------------- G3 tests, forms, blockers, register
E("G3-1", "G3", "08_ACCEPTANCE_TEST_CONTRACT_AND_FAILURE_MATRIX.md",
  "| TC-MODEL | wrong model hash, missing calibration artifact, unapproved refit, source-version collision | no eligible new entry; no duplicate intent after model rerun |",
  "| TC-MODEL | wrong model hash, missing calibration artifact, unapproved refit, source-version collision; and the 19 cases MSB-01..MSB-19 of file 24 (intake gates, hostile pickle, static import scan, unavailable model, registration under a frozen contract, source identity, labelling, no cross-substitution) | no eligible new entry; no duplicate intent after model rerun; NO_AUTHORITATIVE_PREDICTION on any gate failure |",
  "TC-MODEL family now carries the MS-B cases.")
E("G3-2", "G3", "12_G0R_DESIGN_OWNER_ACCEPTANCE_FORM_UNSIGNED.md",
  "Controlled source amendments AM-01..AM-09 exactly as in",
  "Controlled source amendments AM-01..AM-14 exactly as in",
  "Amendment range in the owner form.")
E("G3-3", "G3", "12_G0R_DESIGN_OWNER_ACCEPTANCE_FORM_UNSIGNED.md",
  "- Owner-selected Master Option R / EXT Option C (yes/no): `________________`",
  "- Owner-selected Master Option R / EXT Option C (yes/no): `________________`\n- MS-B dual-source predictions, no refit: file 24, file 25 and tests MSB-01..MSB-19 exactly as hashed; OC-D04-04 stays DEFER and no model cadence is selected (yes/no): `________________`",
  "The G0-R record must bind MS-B and say that no cadence is selected.")
E("G3-4", "G3", "12_G0R_DESIGN_OWNER_ACCEPTANCE_FORM_UNSIGNED.md",
  "model fitting/promotion unapproved except signed offline fixture simulations:",
  "model fitting/promotion unapproved; the only prediction sources are signed test scores and owner-registered non-executable trained models under MS-B (file 24):",
  "Scope-exclusion line named fixtures only.")
E("G3-5", "G3", "13_G1R_OFFLINE_IMPLEMENTATION_GRANT_FORM_UNSIGNED.md",
  "fixture-scored inference (no trained V2 or V3 model is loaded under this grant)",
  "prediction from two sources under the MS-B contract of file 24 (signed test scores for pipeline validation; owner-registered non-executable trained models, none of which is registered at presentation; no model is fitted or promoted)",
  "The grant form said no trained model is loaded, which contradicts MS-B.")
E("G3-6", "G3", "15_READINESS_BLOCKERS_AND_UNSET_VALUES.md",
  "Trained-model loader, candidate publisher and real quote/anchor module remain excluded.",
  "The candidate publisher and the real quote/anchor module remain excluded; the trained-model loader is limited to the single MS-B intake module of file 24.",
  "Blockers file still said the loader is excluded.")
E("G3-7", "G3", "15_READINESS_BLOCKERS_AND_UNSET_VALUES.md",
  "- active V3 model training cadence and release/promotion authority;",
  "- active V3 model training cadence and release/promotion authority;\n- Core-5 frozen model artifacts (none registered or eligible in the inspected locations; other hosts and S3 not checked; MS-F fit-and-freeze authorisation if wanted), the registered parity tolerance, and the live-folder hash of `live_inference.py` (`PENDING_OWNER_CHECK`);",
  "Values and evidence still unset after MS-B.")
E("G3-8", "G3", "18_REGISTER_DISPOSITION_CLASSES.csv",
  "D04-FREEZE-02,FREEZE_FINDING,CARRIED_TO_LATER_GATE,\"PROPOSED classification only; NOT owner-accepted, finding remains formally OPEN.\",G3 retained model intake; G1 fixture scoring only; DENY: G1R-08-M; V3EXT-021",
  "D04-FREEZE-02,FREEZE_FINDING,D_DESIGN_ADOPTED_FOR_OFFLINE_CORE,\"PROPOSED classification only; NOT owner-accepted, finding remains formally OPEN.\",File 24 MS-B gates G-1 to G-11 and MSB-01..MSB-19; DENY: G1R-08-M narrowed by AM-10 to one module; V3EXT-015; V3EXT-021; real-artifact registration and MS-F are later and separate",
  "D04-FREEZE-02 (inference loads retained hashed artifacts, no silent refit) is the finding MS-B integrates.")

# ---------------------------------------------------------------- G4 disposition record and identifiers
E("G4-1", "G4", "21_MERGED_REVIEW_FINDING_DISPOSITION.md",
  "Exact old and new text of nine amendments in file 23,",
  "Exact old and new text of fourteen amendments in file 23,",
  "Amendment count.")
E("G4-2", "G4", "21_MERGED_REVIEW_FINDING_DISPOSITION.md",
  "Explicit bans preserved for trained-model loader and candidate publisher; fixture-only scoring, pure bid/ask validator. Scope amendments given as exact old/new text in 23 (explained in 20) | Full offline trading with fixture scoring only; trained-model intake separate; owner must approve source amendment |",
  "Explicit bans preserved for fitting, promotion, executable deserialisation and the candidate publisher; the trained-model loader is limited to one intake module under MS-B (file 24); pure bid/ask validator. Scope amendments given as exact old/new text in 23 (explained in 20) | Full offline trading with two prediction sources; real model registration separate and later; all five Core-5 trained models UNAVAILABLE; owner must approve source amendment |",
  "Row B3 said fixture scoring only.")
E("G4-3", "G4", "21_MERGED_REVIEW_FINDING_DISPOSITION.md",
  "The author's own run of `verify_v2_replay.py` is the check; no further R2 review round is part of the process.",
  "The author's own run of `verify_v2_replay.py` is the check; no further R2 review round is part of the process.\n\n## MS-B dual-source predictions (R2, 13 Nov 2026)\n\nThe owner chose option B (trained models with signed test scores). R2 read the owner's EC2 inventory: no Core-5 model file was found on the one inspected host, the V2 inference code that R2 holds fits a model on every run, and six other model files exist (file 25). The controlled amendment is AM-10..AM-14 in file 23, the contract and its 19 tests are file 24, and the evidence is file 25. The author's own run of `verify_msb.py` is the check; this is part of the same consolidated process, not a new design stage.",
  "Package records what MS-B adds and that it is inside the one consolidated process.")
E("G4-4", "G4", "14_GROUP_48H_CLOCK_NOT_STARTED.json", "\"package_id\": \"" + OLD_ID + "\"", "\"package_id\": \"@@NEW_ID@@\"",
  "Clock file names the new revision.")
E("G4-5", "G4", "00_READ_ME_FIRST.md", "**Artifact ID:** `" + OLD_ID + "`", "**Artifact ID:** `@@NEW_ID@@`",
  "New revision carries a new ID, equal in file 00, file 14 and the manifest.")


# ---------------------------------------------------------------- machinery
def _read(p):
    with open(p, encoding="utf-8", newline="") as f:
        return f.read()


def _write(p, t):
    with open(p, "w", encoding="utf-8", newline="") as f:
        f.write(t)


def sha_f(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


def all_amendments(skip=()):
    return [r for r in list(CE.AMEND) + AMEND_NEW if r[0] not in skip]


def amendment_csv(skip=()):
    o = io.StringIO()
    w = csv.writer(o, lineterminator="\n")
    w.writerow(CE.AMEND_HEADER)
    for r in all_amendments(skip):
        w.writerow(r)
    return o.getvalue()


def regen_manifest(d, new_id):
    ents = []
    for root, _, fs in os.walk(d):
        for f in sorted(fs):
            rel = os.path.relpath(os.path.join(root, f), d)
            if rel == "MANIFEST_SHA256.json":
                continue
            ents.append({"path": rel, "size_bytes": os.path.getsize(os.path.join(root, f)), "sha256": sha_f(os.path.join(root, f))})
    ents.sort(key=lambda e: e["path"])
    old = json.load(open(os.path.join(d, "MANIFEST_SHA256.json"), encoding="utf-8"))
    out = {"status": old["status"], "id": new_id, "members": len(ents), "hash_algorithm": "SHA-256", "entries": ents,
           "supersedes_candidate_sha256": V3_ZIP_SHA, "authority": old["authority"]}
    json.dump(out, open(os.path.join(d, "MANIFEST_SHA256.json"), "w"), indent=2)


def apply(src, out, evidence, new_id=DEFAULT_NEW_ID, skip=(), with_members=True, with_evidence=True):
    texts = {}
    for e in EDITS:
        if e["id"] in skip:
            continue
        p = os.path.join(src, e["file"])
        t = texts.get(e["file"]) or _read(p)
        n = t.count(e["old"])
        if n != e["count"]:
            sys.exit("STOP %s: old text occurs %d times in %s, expected %d. Nothing written." % (e["id"], n, e["file"], e["count"]))
        texts[e["file"]] = t.replace(e["old"], e["new"].replace("@@NEW_ID@@", new_id))
    for r in AMEND_NEW:
        if r[0] in skip:
            continue
        n = _read(os.path.join(src, "SOURCE_PINS_UNMODIFIED", r[1])).count(r[2])
        if n != 1:
            sys.exit("STOP %s: old text occurs %d times in %s, expected 1. Nothing written." % (r[0], n, r[1]))
    if os.path.exists(out):
        shutil.rmtree(out)
    shutil.copytree(src, out)
    for f, t in texts.items():
        _write(os.path.join(out, f), t)
    _write(os.path.join(out, F23), amendment_csv(skip))
    if with_members:
        for m in (F24, F25):
            shutil.copy(os.path.join(HERE, "members", m), os.path.join(out, m))
    if with_evidence:
        ev = os.path.join(out, "REVIEW_EVIDENCE")
        shutil.rmtree(ev)
        shutil.copytree(evidence, ev, ignore=shutil.ignore_patterns("__pycache__", "attach", "*.pyc"))
    regen_manifest(out, new_id)
    return out


if __name__ == "__main__":
    if len(sys.argv) < 4:
        sys.exit(__doc__)
    apply(sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4] if len(sys.argv) > 4 else DEFAULT_NEW_ID)
    print("applied %d edits + AM-10..AM-14 in %s + members 24, 25 + REVIEW_EVIDENCE + manifest -> %s" % (len(EDITS), F23, sys.argv[2]))
