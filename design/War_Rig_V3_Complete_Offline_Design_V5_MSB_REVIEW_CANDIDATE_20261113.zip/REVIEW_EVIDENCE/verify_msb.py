#!/usr/bin/env python3
"""R2's single mechanical replay for MS-B (CONTROLLED_DUAL_SOURCE_PREDICTIONS / NO_REFIT) and the check the author
re-runs after applying msb_edits.py to the author's V3 package.

  review  V3_DIR WORK_DIR OUT_PREFIX EVIDENCE_DIR [--zip V3.zip] [--inventory FILE ...] [--v2copy FILE ...] [--a010 FILE]
          R2's run: facts about V3 as delivered and about the owner's EC2 inventory, the edits applied to a copy,
          the post-fix checks, leave-one-out, planted faults.
  replay  FIXED_DIR
          the author's re-run on the revised package (post-fix checks only).

The checks inherited from verify_v2_replay.py (which includes verify_cons_review.py) run unchanged, except five that
tested the very wording MS-B replaces (B3.a, B3.e, B3.f: fixture-only scoring; V.1: AM-01..AM-09; V.12: V2 ZIP hash).
Those five are replaced by W.10, W.11, W.12, W.1 and W.16 below. Every check prints PASS or FAIL.
Exit code 1 if any FAIL.
"""
import csv, io, json, os, re, shutil, sys

sys.dont_write_bytecode = True  # running in place must not add files that the manifest does not list

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import verify_cons_review as V  # noqa: E402
import verify_v2_replay as VR  # noqa: E402
import msb_edits as ME  # noqa: E402

F23, F24, F25 = ME.F23, ME.F24, ME.F25
SUPERSEDED = {"B3.a", "B3.e", "B3.f", "V.1", "V.12"}
PINS_JSON = os.path.join(HERE, "msb_pins.json")

# the owner's inventory, section A (13 Nov 2026 16:27:41Z, host ip-172-31-5-61): sha256, bytes, modified UTC, path
INV = [
    ("e314b9c4032e1a7a3f1c3e7b4b8bdf6255909de51cc98e89fba8f8011b138088", 255721, "2026-05-04T09:06:52Z", "models/execution_r_model.pkl"),
    ("5de29eb99bb643146a1e8bd5d2ef1ec411dcbb17c588e79f0ce17b63d6372b7a", 268834, "2026-05-15T21:22:25Z", "models/execution_r_model_proxy_v1.pkl"),
    ("fac25191a6c7e0d598db64b6a3a6226c2831b719c4d48589989d9c531982e6e8", 263774, "2026-05-04T09:06:52Z", "models/execution_skip_model.pkl"),
    ("1d9a16b54eae6672ba2e4af324a5cd552fcc3f129fd3a3776e563eeb50bf0fab", 267950, "2026-05-15T21:22:25Z", "models/execution_skip_model_proxy_v1.pkl"),
    ("89014f0c838b8f26aeb6e9d5b13eefe691f657ca6b8891bc47f2d2612e05808f", 868, "2026-04-26T09:21:41Z", "results/dax_hourly/model_version.json"),
    ("093c49fef39d5b0a761907a017f4deac32836aa4130df177012c4b47576189f7", 1795, "2026-05-04T09:06:52Z", "results/execution_model_metrics.json"),
    ("aa6f695098f54f0e0558abbd945ca1550feca9abbb38f14d47ebd45cc6bf0c52", 514467, "2026-05-18T12:53:44Z", "results/ml/signal_v2/models/signal_v2_20260518T125341Z/model.joblib"),
    ("539f289e5d55d3d40bcf3ea6b9e9ee8640be5f3a51dd16acc9a29607130ed853", 514492, "2026-05-18T13:16:24Z", "results/ml/signal_v2/models/signal_v2_20260518T131620Z/model.joblib"),
]
LIVE_INF_SHA = "8a298149c23ec23cd2dee63349834bd09e7e59c13bd533fb39a5e126795e4601"
A010_SHA = "1b397d2f4284918eb85e43986988da9414090178d904df5a6b6b7dfc49d65abb"
CORE5 = ["Gold", "GER40", "US500", "EURUSD", "GBPUSD"]
STATES25 = {"CREATED_UNREGISTERED", "UNAVAILABLE", "NOT_A_MODEL"}
# wording that MS-B replaces; none may remain in any numbered package member
STALE = ["no trained-model loader", "fixture-scored inference", "no trained V2 or V3 model is loaded", "OFFLINE_FIXTURE_SCORING_ONLY_NO_MODEL_LOADER",
         "AM-01..AM-09", "nine controlled source amendments", "nine amendments", "hash pinning only; no model loader", "Retained model loader after new scope grant",
         "trained V2/V3 model intake remains excluded", "Retained V2/V3 trained artifacts are not loadable", "G3 retained model intake; G1 fixture scoring only",
         "Trained-model loader, candidate publisher and real quote/anchor module remain excluded",
         "none exist; MS-F", "keeps no file", "no Core-5 model file exists", "does not exist as a file", "no frozen artifact exists", "; not promoted;"]
MARKERS24 = (["M%d." % i for i in range(1, 5)] + ["N%d." % i for i in range(1, 8)] + ["S-%d" % i for i in range(1, 9)] + ["F-%d" % i for i in range(1, 5)] + ["AF-%d" % i for i in range(1, 6)] +
             ["G-%d" % i for i in range(1, 12)] + ["C-%d" % i for i in range(1, 6)] + ["**E%d**" % i for i in range(1, 7)])


def rds(d, n):
    p = os.path.join(d, n)
    return open(p, encoding="utf-8").read() if os.path.isfile(p) else ""


def csvrows(t):
    return list(csv.DictReader(io.StringIO(t))) if t.strip() else []


def table_rows(t, prefix):
    return [l for l in t.split("\n") if l.startswith(prefix)]


def w_checks(d, res, expect_id=None):
    P = res.add
    pins = os.path.join(d, "SOURCE_PINS_UNMODIFIED")
    t = {n: rds(d, n) for n in ["00_READ_ME_FIRST.md", "01_COMPLETE_OFFLINE_CORE_DESIGN_13_COMPONENTS.md", "02_SCOPE_C_COMPLETE_18_MODULE_SCHEDULE.csv", "04_CONTROLLED_SCOPE_SOURCE_AMENDMENT_SCHEDULE.md",
                                  "05_CONSOLIDATED_61_ROW_OWNER_DECISION_REGISTER_NOT_SELECTED.csv", "08_ACCEPTANCE_TEST_CONTRACT_AND_FAILURE_MATRIX.md", "12_G0R_DESIGN_OWNER_ACCEPTANCE_FORM_UNSIGNED.md",
                                  "13_G1R_OFFLINE_IMPLEMENTATION_GRANT_FORM_UNSIGNED.md", "15_READINESS_BLOCKERS_AND_UNSET_VALUES.md", "18_REGISTER_DISPOSITION_CLASSES.csv",
                                  "20_CONTROLLED_SOURCE_SUPERSESSION_PROPOSAL_NOT_ADOPTED.md", "21_MERGED_REVIEW_FINDING_DISPOSITION.md", F24, F25]}
    t00, t01, t02, t04, t05, t08, t12, t13, t15, t18, t20, t21, t24, t25 = [t[k] for k in ["00_READ_ME_FIRST.md", "01_COMPLETE_OFFLINE_CORE_DESIGN_13_COMPONENTS.md", "02_SCOPE_C_COMPLETE_18_MODULE_SCHEDULE.csv",
                                                                                         "04_CONTROLLED_SCOPE_SOURCE_AMENDMENT_SCHEDULE.md", "05_CONSOLIDATED_61_ROW_OWNER_DECISION_REGISTER_NOT_SELECTED.csv",
                                                                                         "08_ACCEPTANCE_TEST_CONTRACT_AND_FAILURE_MATRIX.md", "12_G0R_DESIGN_OWNER_ACCEPTANCE_FORM_UNSIGNED.md",
                                                                                         "13_G1R_OFFLINE_IMPLEMENTATION_GRANT_FORM_UNSIGNED.md", "15_READINESS_BLOCKERS_AND_UNSET_VALUES.md",
                                                                                         "18_REGISTER_DISPOSITION_CLASSES.csv", "20_CONTROLLED_SOURCE_SUPERSESSION_PROPOSAL_NOT_ADOPTED.md",
                                                                                         "21_MERGED_REVIEW_FINDING_DISPOSITION.md", F24, F25]]
    ext = rds(pins, "EXT_G0R_14_UNCHANGED.md")

    # ---- amendments: exact text, one controlling form
    am = csvrows(rds(d, F23))
    ids = [r["amendment_id"] for r in am]
    bad = []
    for r in am:
        txt = rds(pins, r["pinned_file"])
        if txt.count(r["exact_old_text"]) != 1 or not r["exact_new_text"].strip() or r["exact_new_text"] == r["exact_old_text"] or not r["takes_effect"].strip() or not r["negative_test_id"].strip():
            bad.append(r["amendment_id"])
    P("W.1 file 23 has AM-01..AM-14 in order; each old text occurs exactly once in its pinned file; each new text is non-empty and different; each has an effect condition and a negative test (replaces V.1)",
      ids == ["AM-%02d" % i for i in range(1, 15)] and not bad, "ids: %s bad: %s" % (ids, bad))
    cur, badseq = {}, []
    for r in am:
        f = r["pinned_file"]
        txt = cur[f] if f in cur else rds(pins, f)
        if txt.count(r["exact_old_text"]) != 1:
            badseq.append(r["amendment_id"])
            continue
        cur[f] = txt.replace(r["exact_old_text"], r["exact_new_text"], 1)
    P("W.2 applied one after another in order, every amendment still finds its old text exactly once (no amendment overlaps or breaks another)", len(am) == 14 and not badseq, "failed: %s" % badseq)
    msb_ids = set(re.findall(r"^\| (MSB-\d\d) \|", t24, re.M))
    unresolved = []
    for r in am:
        for tok in re.findall(r"MSB-\d\d|V3EXT-\d{3}", r["negative_test_id"]):
            if tok.startswith("MSB-") and tok not in msb_ids:
                unresolved.append((r["amendment_id"], tok))
            if tok.startswith("V3EXT-") and ("`%s`" % tok) not in ext:
                unresolved.append((r["amendment_id"], tok))
    newrows = {r["amendment_id"]: r for r in am}
    has_msb = all(re.search(r"MSB-\d\d", newrows.get("AM-%d" % i, {}).get("negative_test_id", "")) for i in range(10, 15))
    P("W.3 every negative test named by AM-10..AM-14 exists (MSB-nn in file 24, V3EXT-nnn in the pinned EXT) and each of them names at least one MSB test", not unresolved and has_msb, str(unresolved))

    # ---- file 24 contract
    P("W.4 file 24 has the MS-B dual-source title and says PROPOSED, NOT SELECTED, NOT APPLIED; its tables are well formed",
      t24.startswith("# MS-B — CONTROLLED_DUAL_SOURCE_PREDICTIONS / NO_REFIT (PROPOSED, NOT SELECTED, NOT APPLIED)") and not V.table_rows_consistent(t24), str(V.table_rows_consistent(t24)[:2]))
    tests = re.findall(r"^\| (MSB-\d\d) \|", t24, re.M)
    P("W.5 file 24 lists MSB-01..MSB-19 exactly once each", tests == ["MSB-%02d" % i for i in range(1, 20)], str(tests))
    missing = [m for m in MARKERS24 if m not in t24]
    P("W.6 file 24 carries every clause: M1-M4, N1-N7, S-1..S-8, F-1..F-4, AF-1..AF-5, G-1..G-11, C-1..C-5, E1-E6", not missing, "missing: %s" % missing)
    need = ["SIGNED_TEST_SCORE", "TRAINED_MODEL", "NO_AUTHORITATIVE_PREDICTION", "NOT_PERFORMANCE_EVIDENCE", "NOT_A_MODEL_PREDICTION", "OC-D04-04", "MS-F", "UNAVAILABLE", "promoted_for_live",
            "never quietly switches", "PIPELINE_VALIDATION_ONLY", "OFFLINE_MODEL_BEHAVIOUR", "SERVING_AUTHORIZED_OFFLINE_ONLY", "PENDING_OWNER_CHECK", "G1R-08-X", "ComparisonEvaluator", "EXT section 4.1", "restarts the group clock by rule (b)",
            "OFFLINE_SIMULATED_MODEL_BEHAVIOUR", "not verified forward or live trading performance", "from the raw signed feature row", "not proof that no model exists anywhere", "cannot reach `VALIDATED`"]
    gone = [s for s in ("does not exist as a file", "no frozen artifact exists") if s in t24 or s in rds(d, F25)]
    P("W.7 file 24 keeps the conditions: both sources, labels, no fallback, no promotion, no cadence selected, MS-F separate, V2 history only through the pinned snapshot", all(s in t24 for s in need) and not gone, "missing: %s; overclaims still present: %s" % ([s for s in need if s not in t24], gone))
    af = table_rows(t24, "| AF-")
    P("W.8 the allow-list has exactly AF-1..AF-5 and none of its rows allows pickle or joblib", [r.split("|")[1].strip() for r in af] == ["AF-%d" % i for i in range(1, 6)] and not any(x in r.lower() for r in af for x in ("pickle", "joblib")), str(af[:1]))

    # ---- file 25 evidence
    rows25 = csvrows(t25)
    inv_ok = True
    for sha, nbytes, mod, path in INV:
        m = [r for r in rows25 if r["path_on_ec2"].endswith(path)]
        if len(m) != 1 or m[0]["sha256"] != sha or m[0]["bytes"] != str(nbytes) or m[0]["modified_utc"] != mod:
            inv_ok = False
    core = [r for r in rows25 if r["item_kind"] == "REQUIRED_MODEL_SET"]
    P("W.9 file 25 has 13 rows; its eight files carry the sha256, size and date of the owner's inventory; the five Core-5 rows are UNAVAILABLE; no row is serving",
      len(rows25) == 13 and inv_ok and [r["instrument_scope"] for r in core] == CORE5 and all(r["state_at_presentation"] == "UNAVAILABLE" for r in core) and all(r["state_at_presentation"] in STATES25 for r in rows25)
      and all(r["promoted_for_live"] != "true" for r in rows25), "rows=%d inv_ok=%s" % (len(rows25), inv_ok))

    # ---- inherited conditions that MS-B replaces
    rows02 = {r["module"]: r for r in csvrows(t02)}
    mar = rows02.get("ModelArtifactRegistry", {})
    p0 = [l for l in t01.split("\n") if l.startswith("| 02 | Model registry and inference")]
    P("W.10 file 02: ModelArtifactRegistry is OFFLINE_DUAL_SOURCE_PREDICTIONS_NO_REFIT, names AM-10 and MSB-01..MSB-19, still 18 rows (replaces B3.a)",
      mar.get("proposed_scope_C_disposition") == "OFFLINE_DUAL_SOURCE_PREDICTIONS_NO_REFIT" and "AM-10" in mar.get("source_test_anchor", "") and "MSB-01..MSB-19" in mar.get("source_test_anchor", "") and len(rows02) == 18 and "OC-D04-04 stays DEFER" in mar.get("remaining_broker_dependency", ""))
    P("W.11 file 01 component 02 names both sources, the model_intake module, no fallback, no pickle or joblib, and the UNAVAILABLE status; still thirteen components (replaces B3.e)",
      len(p0) == 1 and all(s in p0[0] for s in ["SIGNED_TEST_SCORE", "TRAINED_MODEL", "v3/offline/model_intake.py", "no fallback from one source to the other", "no pickle or joblib", "UNAVAILABLE at presentation", "MSB-01..MSB-19"]) and "Thirteen integrated components" in t01 and "| 14 |" not in t01)
    P("W.12 the G1-R grant form allows two prediction sources under file 24 and no longer says no trained model is loaded; the owner form binds MS-B and names AM-14; no retained inference wording (replaces B3.f)",
      "prediction from two sources under the MS-B contract of file 24" in t13 and "no trained V2 or V3 model is loaded" not in t13 and "retained inference" not in t13
      and "AM-01..AM-14" in t12 and "MS-B dual-source predictions, no refit: file 24, file 25 and tests MSB-01..MSB-19" in t12 and "only prediction sources are signed test scores and owner-registered" in t12)

    # ---- nothing selected, nothing else moved
    reg = csvrows(t05)
    od = [r for r in reg if r["decision_id"] == "OC-D04-04"]
    cls = [r for r in csvrows(t18) if r["item_id"] in ("OC-D04-04", "D04-FREEZE-02", "D04-FREEZE-01")]
    cmap = {r["item_id"]: r["disposition_class"] for r in cls}
    P("W.13 OC-D04-04 is still DEFER, OPEN and NOT_SELECTED in file 05 and class K in file 18; D04-FREEZE-02 is class D with the MS-B gates named; D04-FREEZE-01 stays carried to a later gate",
      len(od) == 1 and od[0]["historic_author_recommendation"] == "DEFER" and od[0]["binding_disposition"] == "OPEN" and od[0]["explicit_owner_choice"] == "NOT_SELECTED"
      and cmap.get("OC-D04-04") == "K_KEEP_OFF_UNTIL_LATER_GATE" and cmap.get("D04-FREEZE-02") == "D_DESIGN_ADOPTED_FOR_OFFLINE_CORE" and cmap.get("D04-FREEZE-01") == "CARRIED_TO_LATER_GATE"
      and "MSB-01..MSB-19" in t18)
    try:
        want = json.load(open(PINS_JSON, encoding="utf-8"))
    except Exception:
        want = {}
    have = {}
    for root, _, fs in os.walk(pins):
        for f in fs:
            have[os.path.relpath(os.path.join(root, f), pins)] = V.sha_f(os.path.join(root, f))
    P("W.14 the 25 pinned sources are byte-identical to the V3 package (same names, same SHA-256, nothing added or removed)", len(want) == 25 and have == want, "differs: %s" % sorted(k for k in set(want) | set(have) if want.get(k) != have.get(k))[:4])

    # ---- schedule, explanatory table, stale wording
    rows04 = table_rows(t04, "| ")
    need04 = [("`G1R-08-M`", "AM-10"), ("`V3EXT-025`", "AM-12"), ("Master V1.8 section 3.1 ModelArtifactRegistry row", "AM-13"), ("EXT section 1.2 invariant 1 (tail)", "AM-14")]
    ok04 = all(any(a in r and b in r for r in rows04) for a, b in need04) and "(AM-01..AM-14; each old text" in t04
    P("W.15 file 04 has a row for each of AM-10, AM-12, AM-13 and AM-14 and names AM-01..AM-14; file 20 names AM-01..AM-14 and explains G1R-08-M as narrowed", ok04 and "(AM-01..AM-14)" in t20 and "G1R-08-M narrowed to one module" in t20)
    mf = json.load(open(os.path.join(d, "MANIFEST_SHA256.json"), encoding="utf-8"))
    P("W.16 the manifest records the V3 ZIP it supersedes, lists files 24 and 25, and carries the package id " + (expect_id or "(any)") + " (replaces V.12)",
      mf.get("supersedes_candidate_sha256") == ME.V3_ZIP_SHA and {F24, F25} <= {e["path"] for e in mf["entries"]} and (expect_id is None or mf.get("id") == expect_id), "id=%s" % mf.get("id"))
    stale = []
    for f in sorted(os.listdir(d)):
        if f[:2].isdigit() and f.endswith((".md", ".csv", ".json")):
            tx = rds(d, f)
            stale += [(f[:2], s) for s in STALE if s in tx]
    P("W.17 none of the wording that MS-B replaces remains in any numbered package member", not stale, str(stale[:4]))
    P("W.18 each member carries its MS-B text: 00 (boundary, fourteen amendments, members 24 and 25), 08 (MSB-01..MSB-19), 15 (blockers, PENDING_OWNER_CHECK), 21 (B3 row and the MS-B record)",
      "MS-B dual-source contract (`24_...md`, `25_...csv`)" in t00 and "fourteen controlled source amendments (AM-01..AM-14)" in t00 and ("`" + F24 + "`") in t00 and ("`" + F25 + "`") in t00
      and "MSB-01..MSB-19" in t08 and "NO_AUTHORITATIVE_PREDICTION on any gate failure" in t08 and "limited to the single MS-B intake module of file 24" in t15 and "PENDING_OWNER_CHECK" in t15
      and "fourteen amendments in file 23" in t21 and "limited to one intake module under MS-B" in t21 and "## MS-B dual-source predictions (R2, 13 Nov 2026)" in t21 and "verify_msb.py" in t21)
    ev = os.path.join(d, "REVIEW_EVIDENCE")
    have_ev = set(os.listdir(ev)) if os.path.isdir(ev) else set()
    names = VR.EVIDENCE_NAMES + ["msb_edits.py", "verify_msb.py", "msb_pins.json", "R2_MSB_dual_source_report_20261113.md"]
    P("W.19 REVIEW_EVIDENCE holds the earlier evidence set plus the MS-B change list, this checker, the pin list, the report and the two members the edits copy",
      set(names) <= have_ev and os.path.isfile(os.path.join(ev, "members", F24)) and os.path.isfile(os.path.join(ev, "members", F25)), "missing: %s" % sorted(set(names) - have_ev))


def post_fix(d, res, expect_id=None):
    tmp = V.R()
    VR.post_fix(d, tmp, expect_id)
    for cid, ok, det in tmp.rows:
        if cid.split()[0] in SUPERSEDED:
            continue
        res.add(cid, ok, det)
    w_checks(d, res, expect_id)


# ------------------------------------------------------------------------------------------------
def facts_about_v3(v3, res, v3zip=None, inventory=None, v2copies=(), a010=None):
    P = res.add
    pins = os.path.join(v3, "SOURCE_PINS_UNMODIFIED")
    rd = lambda n: V.rd(v3, n)
    if v3zip:
        P("A01 the V3 ZIP SHA-256 equals 0e71d874...", V.sha_f(v3zip) == ME.V3_ZIP_SHA)
    V.manifest_check(v3, res)
    mf = json.load(open(os.path.join(v3, "MANIFEST_SHA256.json"), encoding="utf-8"))
    P("A02 V3 has 59 manifest entries, the id ends -V3, 25 of them are pinned sources", len(mf["entries"]) == 59 and mf["id"].endswith("-V3") and sum(1 for e in mf["entries"] if e["path"].startswith("SOURCE_PINS_UNMODIFIED/")) == 25)
    tmp = V.R()
    V.manifest_check(v3, tmp)
    VR.post_fix(v3, tmp, None)
    P("A03 all %d of the author's own checks pass on V3 as delivered (the author's 57/57 claim)" % len(tmp.rows), not tmp.fails() and len(tmp.rows) == 57, "rows=%d fails=%s" % (len(tmp.rows), [r[0] for r in tmp.fails()][:3]))
    ext = V.rd(pins, "EXT_G0R_14_UNCHANGED.md")
    mas = V.rd(pins, "MASTER_V1_8_CORRECTED_UNCHANGED.md")
    d04 = V.rd(pins, "War_Rig_V3_D04_Signals_Models_Pricing_Data_Quality_Design_Proposal_V2.md")
    t02, t13, t00 = rd("02_SCOPE_C_COMPLETE_18_MODULE_SCHEDULE.csv"), rd("13_G1R_OFFLINE_IMPLEMENTATION_GRANT_FORM_UNSIGNED.md"), rd("00_READ_ME_FIRST.md")
    P("A04 [why MS-B needs edits] V3 says fixture scoring only: file 02 row, grant form 'no trained V2 or V3 model is loaded', file 00 'intake remains excluded'",
      "OFFLINE_FIXTURE_SCORING_ONLY_NO_MODEL_LOADER" in t02 and "no trained V2 or V3 model is loaded" in t13 and "trained V2/V3 model intake remains excluded" in t00)
    olds = [r[2] for r in ME.AMEND_NEW]
    P("A05 [pinned text] each of the five old texts of AM-10..AM-14 occurs exactly once in its pinned source", all(V.rd(pins, r[1]).count(r[2]) == 1 for r in ME.AMEND_NEW))
    P("A06 [pinned text] the master itself anticipates the scope grant: 'Retained model loader after new scope grant' and 'later scope grant required'", "Retained model loader after new scope grant" in mas and "later scope grant required" in mas)
    P("A07 [pinned text] EXT section 4.1 puts trained-model fitting behind a separately named, fingerprinted authorisation (the basis for MS-F)", "trained-model fit are **not implicitly included**" in ext and "separately named, fingerprinted credential-free research/data authorisation" in ext)
    P("A08 [pinned text] D04-04 and Master section 8 already say per-run transient training is not reproducible and needs a code pin", "per-run transient training without a retained artifact is not eligible to claim reproducibility" in d04 and "V2 inference re-fits each call without permanent model hash" in mas and "code pin needed" in mas)
    P("A09 [pinned text] EXT section 1.2 invariant 1 bans 'model fitting or model activation' and invariant 5 disables actual inference only while authorisations or evidence are missing", "model fitting or model activation" in ext and "actual inference/model-fitting" in ext and "while values, authorisations or evidence are missing" in ext)
    t01 = rd("01_COMPLETE_OFFLINE_CORE_DESIGN_13_COMPONENTS.md")
    P("A10 [package text] ComparisonEvaluator already admits an immutable, quarantined V2 snapshot under G1R-08-X (the basis for N7)", "immutable V2 snapshot" in t01 and "V2 log/data intake requires quarantined scanned, independently pinned source" in t01 and "G1R-08-X" in t02)
    if inventory:
        txt = open(inventory[0], encoding="utf-8", errors="replace").read()
        for extra in inventory[1:]:
            txt += open(extra, encoding="utf-8", errors="replace").read()
        found = re.findall(r"^([0-9a-f]{64})\s+(\d+)\s+(\S+Z)\s+(\S+)$", txt, re.M)
        fmap = {p: (s, int(n), m) for s, n, m, p in found}
        ok = all(any(p.endswith(path) and fmap[p] == (sha, nb, mod) for p in fmap) for sha, nb, mod, path in INV)
        P("A11 [evidence] the eight inventory rows in the checker equal the owner's pasted inventory output (sha256, bytes, modified UTC)", ok and len(found) == 8, "found %d" % len(found))
        crons = [l for l in txt.split("\n") if "backtest_ml.live_inference" in l and re.match(r"^\s*\d", l)]
        P("A12 [evidence] the owner's crontab runs backtest_ml.live_inference nine times each weekday (day-of-week 1-5)", len(crons) == 9 and all(" 1-5 " in l for l in crons), "n=%d" % len(crons))
        hdr = txt.split("== B.")[0]
        P("A13 [evidence] the inventory records the host, the time and that section A is complete", "ip-172-31-5-61" in hdr and "2026-11-13T16:27:41Z" in hdr and "(end of A)" in txt)
        c = txt.split("== C.")[1].split("(end of C)")[0] if "== C." in txt and "(end of C)" in txt else ""
        hits = [l for l in c.split("\n") if l.startswith("/home/ubuntu/")]
        live = [l for l in hits if l.startswith("/home/ubuntu/tradingview_webhook/")]
        P("A14 [evidence] section C stops at 300 lines (the cap) and has no line from the live folder, so the live file is not shown", len(hits) == 300 and not live, "hits=%d live=%d" % (len(hits), len(live)))
    if v2copies:
        shas = {V.sha_f(p) for p in v2copies}
        src = open(v2copies[0], encoding="utf-8").read().split("\n")
        P("A15 [evidence] the three V2 copies of live_inference.py are identical (sha256 8a298149...e4601)", shas == {LIVE_INF_SHA} and len(v2copies) == 3)
        P("A16 [evidence] _live_prob is defined at line 107, builds XGBClassifier at line 138 and calls fit at line 144, and its docstring says 'Train on all available history and predict today'",
          src[106].startswith("def _live_prob(") and "XGBClassifier(" in src[137] and "m.fit(sc.fit_transform(X), y)" in src[143] and "Train on all available history and predict today" in "\n".join(src[106:125]) and "n_estimators=200, max_depth=4, learning_rate=0.05" in "\n".join(src[137:142]))
    if a010:
        j = json.load(open(a010, encoding="utf-8"))
        P("A17 [evidence] the A0.10 OQ-006 file has SHA-256 1b397d2f...5abb, decision REGISTER_BEFORE_SERVE, status PROPOSED_PENDING_REVIEW, and a just-in-time mode and machine authoriser that MS-B does not borrow",
          V.sha_f(a010) == A010_SHA and j["decision"] == "REGISTER_BEFORE_SERVE" and j["status"] == "PROPOSED_PENDING_REVIEW" and "jit_health" in j and "automatic" in j["authorization"])


# ------------------------------------------------------------------------------------------------
def controls(v3, work, evidence, res):
    base = os.path.join(work, "fixed")
    loo = []
    n_edits = len(ME.EDITS)
    ids = [e["id"] for e in ME.EDITS] + [r[0] for r in ME.AMEND_NEW]
    for i in ids:
        d = os.path.join(work, "loo")
        ME.apply(v3, d, evidence, skip=(i,))
        r2 = V.R()
        V.manifest_check(d, r2)
        post_fix(d, r2, ME.DEFAULT_NEW_ID)
        loo.append((i, bool(r2.fails())))
    for nm, kw in (("members-24-25", dict(with_members=False)), ("evidence", dict(with_evidence=False))):
        d = os.path.join(work, "loo")
        ME.apply(v3, d, evidence, **kw)
        r2 = V.R()
        V.manifest_check(d, r2)
        post_fix(d, r2, ME.DEFAULT_NEW_ID)
        loo.append((nm, bool(r2.fails())))
    notflag = [i for i, f in loo if not f]
    res.add("K1 leave-one-out: dropping any one of the %d edits, any one of AM-10..AM-14, the two new members or the evidence replacement makes at least one check FAIL" % n_edits, not notflag, "not flagged: %s" % notflag)

    def planted(cid, mutate, expect):
        d = os.path.join(work, "planted")
        if os.path.exists(d):
            shutil.rmtree(d)
        shutil.copytree(base, d)
        mutate(d)
        r2 = V.R()
        post_fix(d, r2, ME.DEFAULT_NEW_ID)
        f = [x[0] for x in r2.fails()]
        res.add("K2 planted: %s is detected (%s FAIL)" % (cid, "/".join(expect)), all(any(x.startswith(p) for x in f) for p in expect), "failed: %s" % f)

    def w(d, name, fn):
        p = os.path.join(d, name)
        tx = open(p, encoding="utf-8", newline="").read()
        new = fn(tx)
        assert new != tx, "planted fault changed nothing in " + name
        open(p, "w", encoding="utf-8", newline="").write(new)

    planted("AM-12 old text no longer verbatim", lambda d: w(d, F23, lambda x: x.replace("production cohort reads in G1-R |", "production cohort reads in G1-R  |", 1)), ["W.1"])
    planted("AM-13 row removed", lambda d: w(d, F23, lambda x: "\n".join(l for l in x.split("\n") if not l.startswith("AM-13"))), ["W.1"])
    planted("a pinned source changed by one byte (EXT)", lambda d: w(d, "SOURCE_PINS_UNMODIFIED/EXT_G0R_14_UNCHANGED.md", lambda x: x.replace("Five distinct", "Four distinct", 1)), ["W.14"])
    planted("a negative test that does not exist (MSB-99)", lambda d: w(d, F23, lambda x: x.replace("MSB-09, V3EXT-015", "MSB-99, V3EXT-015", 1)), ["W.3"])
    planted("MSB-17 row deleted from file 24", lambda d: w(d, F24, lambda x: "\n".join(l for l in x.split("\n") if not l.startswith("| MSB-17 |"))), ["W.5"])
    planted("the NOT_PERFORMANCE_EVIDENCE stamp removed from file 24", lambda d: w(d, F24, lambda x: x.replace("NOT_PERFORMANCE_EVIDENCE", "NOT_EVIDENCE"), ), ["W.7"])
    planted("the TRAINED_MODEL report stamp removed from file 24", lambda d: w(d, F24, lambda x: x.replace("OFFLINE_SIMULATED_MODEL_BEHAVIOUR", "OFFLINE_MODEL_RESULT")), ["W.7"])
    planted("the overclaim 'does not exist as a file' put back in file 24", lambda d: w(d, F24, lambda x: x.replace("No registered, frozen Core-5 model was found.", "The Core-5 model does not exist as a file today.", 1)), ["W.7"])
    planted("the full-path golden-vector sentence removed from file 24", lambda d: w(d, F24, lambda x: x.replace("from the raw signed feature row", "from the tree output", 1)), ["W.7"])
    planted("the overclaim 'keeps no file' put back in file 00", lambda d: w(d, "00_READ_ME_FIRST.md", lambda x: x.replace("(this is not proof that no model exists elsewhere)", "and keeps no file", 1)), ["W.17"])
    planted("the overclaim 'none exist' put back in file 15", lambda d: w(d, "15_READINESS_BLOCKERS_AND_UNSET_VALUES.md", lambda x: x.replace("none registered or eligible in the inspected locations; other hosts and S3 not checked; MS-F", "none exist; MS-F", 1)), ["W.17"])
    planted("the 'not promoted' status put back in file 24 section 13", lambda d: w(d, F24, lambda x: x.replace("`promoted_for_live` NOT_VERIFIED_BY_R2 (E6);", "not promoted;", 1)), ["W.17"])
    planted("title put back to the single-source name", lambda d: w(d, F24, lambda x: x.replace("CONTROLLED_DUAL_SOURCE_PREDICTIONS", "CONTROLLED_TRAINED_MODEL_INTAKE", 1)), ["W.4"])
    planted("a joblib row added to the allow-list", lambda d: w(d, F24, lambda x: x.replace("| AF-5 | Manifest |", "| AF-5 | Model | joblib file | convenience |\n| AF-6 | Manifest |", 1)), ["W.8"])
    planted("a model hash in file 25 changed by one character", lambda d: w(d, F25, lambda x: x.replace("aa6f695098f54f0e", "aa6f695098f54f0f", 1)), ["W.9"])
    planted("a Core-5 row made serving in file 25", lambda d: w(d, F25, lambda x: x.replace("CORE5-01,REQUIRED_MODEL_SET,Gold,NONE_FOUND,NONE,0,NONE,NONE,UNAVAILABLE", "CORE5-01,REQUIRED_MODEL_SET,Gold,NONE_FOUND,NONE,0,NONE,NONE,SERVING_AUTHORIZED_OFFLINE_ONLY", 1)), ["W.9"])
    planted("file 02 ModelArtifactRegistry back to fixture-only", lambda d: w(d, "02_SCOPE_C_COMPLETE_18_MODULE_SCHEDULE.csv", lambda x: x.replace("OFFLINE_DUAL_SOURCE_PREDICTIONS_NO_REFIT", "OFFLINE_FIXTURE_SCORING_ONLY_NO_MODEL_LOADER", 1)), ["W.10"])
    planted("grant form says no trained model is loaded again", lambda d: w(d, "13_G1R_OFFLINE_IMPLEMENTATION_GRANT_FORM_UNSIGNED.md", lambda x: x.replace("prediction from two sources under the MS-B contract of file 24", "fixture-scored inference (no trained V2 or V3 model is loaded under this grant); prediction from two sources under the MS-B contract of file 24", 1)), ["W.12", "W.17"])
    planted("OC-D04-04 selected on the owner's behalf", lambda d: w(d, "05_CONSOLIDATED_61_ROW_OWNER_DECISION_REGISTER_NOT_SELECTED.csv", lambda x: "\n".join((l.replace(",NOT_SELECTED,", ",SELECTED,", 1) if l.startswith("OC-D04-04,") else l) for l in x.split("\n"))), ["B7.a"])
    planted("D04-FREEZE-02 class reverted in file 18", lambda d: w(d, "18_REGISTER_DISPOSITION_CLASSES.csv", lambda x: x.replace("D04-FREEZE-02,FREEZE_FINDING,D_DESIGN_ADOPTED_FOR_OFFLINE_CORE", "D04-FREEZE-02,FREEZE_FINDING,CARRIED_TO_LATER_GATE", 1)), ["W.13"])
    planted("an amendment count left at nine in file 00", lambda d: w(d, "00_READ_ME_FIRST.md", lambda x: x.replace("fourteen controlled source amendments (AM-01..AM-14)", "nine controlled source amendments", 1)), ["W.17", "W.18"])
    planted("clock started by mistake", lambda d: w(d, "14_GROUP_48H_CLOCK_NOT_STARTED.json", lambda x: x.replace('"status": "NOT_STARTED"', '"status": "RUNNING"', 1)), ["V.11"])
    planted("manifest no longer supersedes the V3 ZIP", lambda d: w(d, "MANIFEST_SHA256.json", lambda x: x.replace(ME.V3_ZIP_SHA, "0" * 64, 1)), ["W.16"])


def main(argv):
    if argv[1] == "replay":
        d = argv[2]
        res = V.R()
        V.manifest_check(d, res)
        post_fix(d, res)
        return report(res, None)
    v3, work, outp, evidence = argv[2], argv[3], argv[4], argv[5]

    def opt(flag, n=1):
        if flag not in argv:
            return []
        i = argv.index(flag) + 1
        out = []
        while i < len(argv) and not argv[i].startswith("--"):
            out.append(argv[i])
            i += 1
        return out

    v3zip = (opt("--zip") or [None])[0]
    a010 = (opt("--a010") or [None])[0]
    os.makedirs(work, exist_ok=True)
    res = V.R()
    facts_about_v3(v3, res, v3zip, opt("--inventory") or None, opt("--v2copy"), a010)
    fixed = os.path.join(work, "fixed")
    ME.apply(v3, fixed, evidence)
    V.manifest_check(fixed, res)
    post_fix(fixed, res, ME.DEFAULT_NEW_ID)
    controls(v3, work, evidence, res)
    return report(res, outp)


def report(res, outp):
    lines = ["%s  %s%s" % ("PASS" if ok else "FAIL", cid, ("  -- " + det) if (det and not ok) else "") for cid, ok, det in res.rows]
    npass = sum(1 for r in res.rows if r[1])
    lines += ["", "TOTAL %d checks: %d PASS, %d FAIL" % (len(res.rows), npass, len(res.rows) - npass)]
    txt = "\n".join(lines)
    print(txt)
    if outp:
        open(outp + ".txt", "w").write(txt + "\n")
        json.dump([{"id": c, "pass": o, "detail": d} for c, o, d in res.rows], open(outp + ".json", "w"), indent=1)
    return 1 if res.fails() else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
