# R2 review of the consolidated offline-core package (revision 2: R1's findings folded in)

**Package reviewed:** `War_Rig_V3_ONE_CONSOLIDATED_Offline_Core_Design_G0R_G1R_Candidate_20261113.zip`, SHA-256 `dac6eb6e377923fe6043d4b583b63d08bdc25f3b4002e4e0c1705dbb09c4c8a7` (30 files). **Date:** 13 November 2026. **Reviewer:** R2 (AI; not an independent human review, and not independent for WDA-08 or ATC-01, which I wrote). One bounded pass; only core items block. Revision 2 (same day) adds the valid parts of R1's review so the author has one combined change list.

## In plain words, for Jon

**Where it stands.** The package is a good, honest candidate. It says plainly that it is not final, no clock is running, nothing is signed, and its plan for the single stage matches the 27 October rules you approved. Its hashes all check out. It is **not yet ready to be presented as the final group**, because I found seven core problems, R1's review added two more that hold up, and there are two small wording points. Every fix is mechanical, with the exact words below and one script to apply them, except that finding 6 also needs one decision from you. None of them changes the plan you chose (Option R, Scope C, one 48-hour wait, one sitting with two signed records).

**The nine, in plain words (seven mine, two from R1).**

1. **The group is not fully fixed.** The 42-edge ledger design, the 84 denied pairs, the three events, the six-clock schema and the 187 tests live in separate files of the Stage D03 zip. The package pins only the first file of that zip (and labels it wrongly) and hashes none of the others. The D03 and D04 design documents are also not pinned. Your own rule (a) says the clock runs only when every hash in the group is fixed.
2. **It quietly drops configurable instruments.** The scope document that Option C comes from (EXT-G0R-14) is about adding a new market by definition alone, with no code change, and makes that the first thing to prove. The package describes five fixed markets and never mentions it. If you signed this, you would be accepting a design that leaves out the first thing that scope document says to prove.
3. **Three modules are marked "build" that the pinned rules say stay banned.** They are the model loader, the candidate publisher and the quote/anchor module. The fix keeps two banned and narrows one. The plain consequence for you: **at the end of this grant the whole machine runs on test signals, not on V2's trained models.** Confidence, TP/SL, break-even, adaptive trailing, risk and the simulator are all built and tested; V2's real models and strategy code come in through a separate later door, which the pinned rules already require (no V2 bytes in this grant; model intake is a decision not yet taken). The grant text said "retained inference", which you could read as V2's model running. It now says what it means.
4. **The seven state axes are listed wrongly.** The package names a different seven from the ones the pinned specification defines.
5. **The 27 October decision is not attached.** The package says it was not available. I have it, re-computed its hash from the bytes (`d3f39baa…`, matches), and it says what the package relies on: 48 hours, rules (a) and (b). The author attaches it.
6. **The package leaves "who counts as independent" open without naming the rule behind it.** The rule is Group 1 principle 5, which you approved on 27 October: the existing independent-reviewer and two-person controls stay in force until a controlled decision called CAR-01 replaces them. Only you can settle this one (see below).
7. **The decision register is thin.** 43 of its 61 rows carry one of two boilerplate sentences, 25 with a typo, and one row still says "G1-only". The fix groups the 43 into three plain classes so you accept three meanings instead of 43 sentences.

8. **The scope amendments are described, not written (from R1).** The simulator needs order, stop and close operations, and the pinned EXT rule 1.2 prohibits "order/stop/close operations" in this grant. The package lists the amendments but gives no exact old and new words, and has no row for that rule. I had seen that the texts were not produced and did not report it; that was my miss. New file 19 gives nine amendments as exact old and new text, each checked to quote its source verbatim, taking effect only when you sign.
9. **Nothing says what happens between a fill and a verified stop (from R1).** The simulator's `submit_market` carries no stop, and no table says what the position, protection, reservation and allowed actions are in a partial fill, a missing or looser stop, a rejected stop or a stale read. The fix adds the stop to `submit_market`, a six-case table built only from states the pinned master already defines, and a test family for it.

**R1's review.** R1 raised seven findings. Three repeat mine (axes, missing source files, 48-hour route) and are already covered. Two hold up and are the items 8 and 9 above. One is partly right: three schedule cells carry stale "later" wording, which is fixed, but R1's reading that the entry-eligibility and risk engines are missing is wrong, because their disposition is full offline implementation. One is a minor wording point in the clock file, fixed. R1 said it did not recompute hashes; its "D01 file absent" is the file mislabelled `D03_TECH_SPEC_UNCHANGED.md`, so the rename in finding 1 answers it. R1 did not find the configurable-instrument gap, the banned-import contradiction, the CAR-01 rule or the register problem. The details are in the table near the end.

**What you decide, once.**

- **Now:** the independence route (finding 6). First the author produces the one table the package already lists as unresolved: which of the existing controls actually apply to an offline-only design acceptance and implementation grant. I cannot tell from the pinned files, because the acceptance contract itself is not among them. Then you pick one: (a) name one real person as an independent witness and records-checker (the narrow role EXT proposes, which still has to be reconciled with the original K1/H13 wording), (b) include a CAR-01 decision in this same group, or (c) record from that table that the control does not apply to an offline-only grant. This is inside the one stage, not a new stage; Group 1 principle 5 created it.
- **At the sitting, not now:** select Option R plus Scope C, accept the three classes for the 43 rows, the dispositions for the 13 findings and 21 repairs, the 14 Stage D rows and ATC J1 to J4. I will lay them out on one page when the group is final. Anything you choose earlier is a provisional input until you sign.
- **At the sitting:** the copy of the decision register and fingerprints kept outside this workspace (Group 1 principle 3), which the package lists as not yet confirmed.

**What happens next.** Send this report to the author together with R1's findings, so there is **one** fix round. I then run one mechanical replay (the same script, no new review). After that the author presents the final group; the 48-hour clock starts at that presentation and not before; then one sitting. Any change after the presentation restarts the whole clock, which is why everything is fixed first. No clock is running now.

## What I checked and found right

- ZIP hash and all 29 manifest hashes match; no extra files; sources are unmodified copies.
- Status is stated correctly everywhere: design only, not frozen, no clock, no authority, forms unsigned.
- The five-step sequence in file 10 matches rules (a) and (b), Group 1 principles 3 and 5, master section 0 and EXT sections 7.1 and 8.1 (two separate exact-hash records, G1-R not automatic, V3-GOV-48-01 kept unadopted).
- The 18-row module schedule accounts for all 16 master modules plus the two new ones, and keeps BrokerMutationGateway out.
- The broker-neutral interface and simulator contract (file 03) keeps ACCEPTED apart from filled, treats UNKNOWN as a first-class outcome, allows at most one wire attempt per intent with no retry, and names the failure injections.
- ATC-01 revision 2 is pinned at `ce5301c1…` and the V2 parity and DV-1 to DV-4 divergences are carried correctly into component 08.

## Findings (core, block presenting the final group)

### B1. The group is not fully fixed

- **What is wrong.** File 16 and `SOURCE_PINS_UNMODIFIED/`. The pinned Stage D01 integrated specification (`ae373e60…`, section 3) defines the 42 edges, 84 denied pairs, three events and six-clock schema through `01_EDGE_CONTRACTS_35_DRAFT.json`, `02_NEGATIVE_GRAPH_COMPLEMENT_59_SOURCE_PRESERVED.json`, `03_THREE_LEDGER_EVENTS_DRAFT.json`, `04_SIX_CLOCK_SCHEMA_DRAFT.json`, `06_DETERMINISTIC_TEST_PLAN_UNEXECUTED.json` and `07_OWNER_DECISIONS_FOR_CONTROLLED_DISPOSITION.json`, all members of the Stage D03 zip (`23bdbe3b…`). None is in the package and none is hashed. The D03 V3 design (`88975c34…`, cited by master section 3.3 as "D03 V3 lines 30 to 59") and the D04 V2 design (`5e2ef530…`) are hashed in master section 1.1 but not pinned. The file called `D03_TECH_SPEC_UNCHANGED.md` is the Stage D01 integrated specification.
- **Why it matters.** Rule (a) of your 27 October decision: the clock runs only once "the full group, every final proposal, their evidence and each SHA-256 are fixed". The ledger design is the part of the baseline the owner can least afford to approve unseen.
- **Fix.** Replace the "claimed ... not mounted" block in file 16 with the pins in edit B1-1 (hashes already computed from the sources). Rename the spec pin to `STAGE_D01_INTEGRATED_TECHNICAL_SPECIFICATION_UNCHANGED.md` (bytes unchanged). Add the D03 V3 and D04 V2 files to `SOURCE_PINS_UNMODIFIED/`. D01, D02, D05, D06, RG-01 to RG-07 and the V2 archive hashes are fixed by reference through the pinned master section 1.1, which file 16 now says. Regenerate the manifest.
- **Edits / checks.** B1-1 / B1.a to B1.f

### B2. The configurable-instrument core is missing

- **What is wrong.** Pinned EXT-G0R-14 is titled "Configurable Instrument & Expanded Offline Scope Contract". Section 3 defines the instrument-family definition (typed fields in tiers T1 to T3), dated listings, the evidence index and the registration manifest. Section 7.2 makes `V3EXT-006` (a second synthetic instrument added by definition plus fixture only, with zero source and zero manifest changes) the first build milestone. Section 5.2 lists the units `EXT-01` to `EXT-13`. Files 00 to 16 contain none of `EXT-01`, `EXT-02`, `EXT-13`, `V3EXT-006` or `instrument_definition`; the 18-row schedule maps only master's 16 modules and two new ones; there is no test family for it.
- **Why it matters.** Option C means freezing "the full bounded offline target and test contracts". Signing the package as it stands accepts a design without the thing EXT says to prove first. Implementers would either hard-wire five markets or add modules outside the grant, which EXT section 7.2 step 4 says must stop and be re-approved.
- **Fix.** Add the instrument definition layer section to file 01 (pinned EXT section 3 unchanged; it is not a fourteenth component), a `TC-INSTR` family to file 08 (`V3EXT-001` to `V3EXT-011`), the pointer in file 04, and new member `17_EXT_AND_ORIGINAL_UNIT_CROSSWALK.csv` mapping the eight original units and `EXT-01` to `EXT-13` to the 18 modules (`EXT-07` stays excluded). The mapping is my proposal from EXT section 5.2's own descriptions; the author corrects any row once.
- **Edits / checks.** B2-1, B2-2, B2-3, B2-4 / B2.a to B2.g

### B3. Three pinned import bans are contradicted, and "model" is not defined

- **What is wrong.** EXT section 5.3 keeps `G1R-08-M` (reject model/runtime registry import), `G1R-08-C` (reject candidate publication service import) and `G1R-08-Q` (reject broker quote/anchor module import) as negative oracles; replacing one needs exact old and new text, test mapping and owner acceptance. File 02 marks `ModelArtifactRegistry`, `CandidatePublisher` and `AnchorQuoteValidator` as `FULL_OFFLINE_IMPLEMENTATION_CANDIDATE` while citing those same tests as their anchors, and file 04 has no row for any of the three. Component 02 says "load retained models"; the grant form says "retained inference". No V2 bytes may enter G1-R (V3EXT-025, -027), and trained-model intake is the unselected decision T-3.
- **Why it matters.** The build and its own test suite would contradict each other, and the owner could read the grant as letting V2's trained model run.
- **Fix.** Keep `G1R-08-C` unchanged: `EXT-07` and `CandidatePublisher` stay excluded and the pure strategy evaluator `EXT-04` emits candidates. Narrow `G1R-08-M`: only a signed, hash-registered fixture scoring function, no loader, no fitting. Narrow `G1R-08-Q`: only a pure bid/ask validator over signed fixture quotes. Edits B3-1 to B3-7 change components 02 and 03, the three schedule rows, the amendment schedule and the grant wording.
- **Edits / checks.** B3-1, B3-2, B3-3, B3-4, B3-5, B3-6, B3-7 / B3.a to B3.f

### B4. The seven axes are misstated

- **What is wrong.** File 01, line 35, lists "intent, attempt, position, protection, monetary outcome, alert/clock, control-latch". The pinned Stage D01 specification section 3 defines the seven as `broker_operation`, `working_order`, `position`, `protection`, `realised_result` (the five Annex G axes) plus `intent_lifecycle` and `attempt_send_eligibility` (master section 3.3). The caveat "canonical taxonomy must be aligned" does not cure it, because the pinned text is not ambiguous.
- **Why it matters.** Test family `TC-STATE` and the 42-edge graph are tied to those exact axes.
- **Fix.** Replace the sentence (B4-1) and the amendment-schedule row wording (B4-2).
- **Edits / checks.** B4-1, B4-2 / B4.a to B4.c

### B5. The 27 October decision is not attached

- **What is wrong.** Files 00, 10, 14, 15 and 16 say the decision file is not mounted and rely on "R2-reported" inspection. I hold the file (`A39_GROUP1_COOLING_OFF_OWNER_DECISION_V2.json`, shipped in the checks zip under `attach/`), re-computed its SHA-256 from the bytes (`d3f39baa27d8a8c91050d19dea32d83883b73eb1ddb80cf4d89dcfbee534143b`, matches) and read it: your reply "Cooling-off duration: 48 hours. I accept rules (a) and (b) as written."; rule (a) groups proposals under one interval starting after the last final evidence-bound presentation; rule (b) restarts the whole group clock when any member changes.
- **Why it matters.** The package itself calls the missing file a presentation blocker.
- **Fix.** Attach the file under `SOURCE_PINS_UNMODIFIED/` and change the nine statements (B5-1 to B5-9). Working Path 1 is also described as "R2-reported, not owner-selected"; it is now "recommended by R2 and sent to the author at the owner's request", recorded as OD-13 and binding only through the signed records.
- **Edits / checks.** B5-1, B5-2, B5-3, B5-4, B5-5, B5-6, B5-7, B5-8, B5-9 / B5.a to B5.e

### B6. The independence route is open and the rule behind it is not named

- **What is wrong.** File 11 lists the independent reviewers, quorum, K1/H13 countersignatures and external custody as unassigned or unsatisfied, and file 15 item 5 says they "cannot be auto-attested by the author". Neither names Group 1 principle 5 (the independent-reviewer and quorum rules, two-person release rules and K1/H13 countersignatures "are not waived"; "a sole-owner alternative must be explicitly reconciled, evidenced and adopted before it can be called effective") or CAR-01, the controlled decision that does that. Master C-02 and EXT section 7.1 say the same: a sole owner is not two independent signatories, and two AI reviewers are not substitutes where such signatures are still required.
- **Why it matters.** This is the one item that decides whether the sitting needs a second person. The package leaves you without the route.
- **Fix.** Edits B6-1 and B6-2 add the rule and the three routes to files 11 and 15. This is an owner decision (see the plain-words section), not an author defect.
- **Edits / checks.** B6-1, B6-2 / B6.a

### B7. The decision register is thin and partly stale

- **What is wrong.** In file 05, the 43 master rows carry one of two texts ("CONTRACT_DEFINED_FOR_FULL_OFFLINE_CORE; FIxture values allowed but not live policy" on 25 rows, spelled with the typo, and "OFFLINE_SIMULATION_ONLY; NO_IG_CAPABILITY"), regardless of the question. Rows such as OC-D04-04 (frozen model versus retained refit) and OC-D03-04 (R denominator) get the same sentence. Files 06 and 07 give all 13 findings and 21 repairs the same treatment text. OD-13 still reads "G1-only cooling-off placement" and "only if primary governance proof confirms".
- **Why it matters.** You are asked to approve each row, and a row the owner cannot tell apart from the next is not an informed approval (Group 1 principle 3, checklist (a)).
- **Fix.** Classify, do not rewrite 77 sentences. The 43 rows fall into three classes by the author's own recorded recommendation: **K** keep off until a later gate (9 rows), **D** design adopted for the offline core (28), **C** carried unchanged from an earlier decision (6). New member `18_REGISTER_DISPOSITION_CLASSES.csv` gives each of the 43 its class and a plain sentence; the script replaces the boilerplate in file 05 with the class. The author classes the 13 findings and 21 repairs once (closed in design text with a location, carried to a later gate with a gate and a denial test ID, or IG-only excluded). OD-13 is corrected (B7-1, B7-2). The class assignment is mechanical, from the recorded recommendation, not from my reading of each master question; the author corrects any misfiled row once.
- **Edits / checks.** B7-1, B7-2 / B7.a to B7.e

### B8. The scope amendments are described, not written (R1 F-01)

- **What is wrong.** File 04 lists eleven amendment rows with a summary of the current wording and a summary of the change, and file 15 item 3 says controlled final amended source artifacts are still needed. The pinned EXT section 1.2 invariant 1 says the G1-R build has no "order/stop/close operations"; read strictly, that also bans the simulator's submit, modify and close. File 04 has no row for it. EXT section 5.3 says any supersession needs exact old and new text.
- **Why it matters.** If the group is signed with only summaries, the pinned contracts still say what they say, and an implementer or a later reviewer can read the simulator as unauthorised. Until you sign, simulator trading and simulated stop modification are proposed, not authorised by the pinned contracts; the package must say so.
- **Fix.** New member `19_CONTROLLED_AMENDMENT_EXACT_TEXT.csv` holds nine amendments (AM-01 to AM-09) as exact old text, exact new text, effect and negative test: EXT 1.2(1), V3EXT-070, Annex G axes, ATC-T11, master Option R and section 3.1A, and three OD14-03 sentences. The checker confirms every old text occurs exactly once in its pinned source. R1-1 makes file 19 the controlling form and states the not-yet-authorised position; R1-2 adds the missing row for EXT 1.2.
- **Edits / checks.** R1-1, R1-2 / R1.a, R1.b

### B9. No contract for the step between a fill and a verified stop (R1 F-04)

- **What is wrong.** In file 03, `submit_market(intent_id, attempt_id, policy_hash, side, stake, guard_hash)` has no stop or geometry, and `modify_stop` is a separate operation. Master section 3.3 starts the protection axis at position creation (`PROTECTION_UNVERIFIED`, `VERIFIED` or `DRIFT` from read-back) but nothing in the package says how the initial stop reaches the simulator or what holds until it is verified. File 08 has absent-stop and read-back cases but no oracle for the position, protection, reservation and allowed actions between fill and verified stop.
- **Why it matters.** This is the moment a position is open and not yet proven protected. It must be specified before the simulator is built, because ATC-01 DV-1 to DV-3 depend on it.
- **Fix.** R1-6 adds `geometry` (stop distance, limit distance) to `submit_market` and makes it part of the `guard_hash` preimage. R1-7 adds a six-case table (full fill, partial fill, no or looser initial stop, rejected stop or UNKNOWN modify, stale read, audit failure) using only the states master section 3.3 already defines; new-entry consequences stay with the pinned D05/D06 rules, unset denies. R1-8 adds test family `TC-PROTECT`.
- **Edits / checks.** R1-6, R1-7, R1-8 / R1.d, R1.e

### B10. Stale "later" wording on three schedule rows (R1 F-02, the part that holds)

- **What is wrong.** In file 02, the `remaining_broker_dependency` cells for EntryEligibilityEngine ("Actual decision engine later"), ExposureRiskLedger ("Monetary ledger after approved separate slice") and CandidatePublisher ("Later offline slice, separate scope") contradict their disposition. The dispositions are what count: the first two are full offline implementation, and CandidatePublisher is now excluded (B3).
- **Why it matters.** A reader sees "later" next to "complete" and cannot tell which is meant.
- **Fix.** Replace the three cells (R1-3 to R1-5). R1's wider claim that the engines are missing is not correct.
- **Edits / checks.** R1-3, R1-4, R1-5 / R1.c

## Wording the owner signs (clarity, two edits)

### C1. Selections before the presentation are provisional; clock field

- **What is wrong.** File 10 step 1 says owner selections are resolved before the final presentation but not what they are until the sitting.
- **Also (R1 F-07).** The clock file shows `NOT_STARTED` beside `duration_elapsed_hours: 48`; edit R1-9 renames it `required_duration_elapsed_hours` and adds `elapsed_hours_so_far: 0`.
- **Fix.** Edit C1-1 adds one sentence: a selection made before the presentation is a provisional input that becomes binding only through the two signed records at the sitting; a selection changed after the presentation is a change to the group and restarts the interval.

## R1's findings, one by one

| R1 | Verdict | Where handled |
|---|---|---|
| F-01 simulator scope not effective in pinned contracts | Holds; I had missed it as a finding | B8: file 19 and edits R1-1, R1-2 |
| F-02 schedule contradicts complete scope | Partly: three stale cells; the claim that engines are missing is wrong | B10: R1-3 to R1-5 |
| F-03 axis names do not match the D03 graph | Same as my B4 | B4 |
| F-04 no contract from entry to verified initial protection | Holds | B9: R1-6 to R1-8 |
| F-05 referenced source and test evidence absent | Same as my B1; the "D01 file" is the mislabelled pin | B1 |
| F-06 readiness conditions open, 48-hour route not established | Same as my B5 and B6; the addendum's "duration UNSET" is now marked superseded by the attached decision | B5, B6, edit B5-1 |
| F-07 clock file ambiguous | Holds, minor | R1-9 |

## Recorded once, not blocking

- **Traceability matrix.** File 08 has 14 families with oracles but no mapping to the 187 Stage D03 test specifications, the 50 `G1R` IDs, the 83 `V3EXT` IDs or ATC-X01 to X23. Build the matrix at the start of implementation; it needs no review before the grant.
- **Naming.** Component 08 says "C1 to C4 shadow comparisons" and `SIMULATOR_ONLY_TIGHTEN`; ATC-01 rev 2 calls the candidate mode compute-only. Same thing; use one word in the build.
- **Simulator clock.** File 03 should say the simulator's clock is injected and deterministic. One sentence at implementation.
- **D05 and D06 coverage.** I read the headers and the rows that bear on this package, not every clause. The Stage D03 replay (56 of 56, report `b60c98c4…`) covers the ledger design.
- **Numbers that stay open by design.** Real monetary limits, stop type, the six clock values, protective-response A/B/C, model training cadence and the IG-specific semantics remain unset, and the package says so correctly.

## Limits of this review

- I am an AI reviewer. Under Group 1 principle 3 this record is labelled `NOT_INDEPENDENT_SINGLE_OWNER_PROCESS`; it is not a human independent review.
- I wrote WDA-08 and ATC-01, so I cannot independently review them; that remains yours (A-06).
- The classification of the 43 rows and the crosswalk of `EXT-01` to `EXT-13` are my proposals for the author to adopt or correct once; the checker confirms they are complete and consistent, not that each judgement is right.
- I did not re-derive the 42 edges. I rely on my earlier replay of the Stage D03 zip.

## How to apply and replay (mechanical)

1. `python3 -I cons_review_edits.py PACKAGE_DIR FIXED_DIR` applies all 37 edits, renames the spec pin, writes members 17, 18 and 19 and rewrites the 43 register candidates. Each `old` text must occur exactly once (the script stops otherwise).
2. The author then attaches the decision file (`attach/A39_GROUP1_COOLING_OFF_OWNER_DECISION_V2.json`), the D03 V3 and D04 V2 files to `SOURCE_PINS_UNMODIFIED/`, classes the 13 findings and 21 repairs in file 18, and regenerates `MANIFEST_SHA256.json`.
3. `python3 -I verify_cons_review.py replay FIXED_DIR` runs the post-fix checks (49 checks including the manifest). R2 runs the same command once on the author's fixed package; that is the whole replay.

## Checks run on this review (86, 86 PASS)

- **A00 to A19**: each finding is a fact about the delivered package and the pinned sources, checked from the files.
- **B1 to B7, R1, C1, S, M**: the conditions the fixed package must meet, run on a simulated fixed copy built by the script.
- **K1**: removing any one of the 37 edits makes at least one check fail. **K2**: 13 planted faults (flipped hash digit, old axis wording, missing `EXT-13`, misclassed row, altered decision byte, "not mounted" text, `CandidatePublisher` built again, boilerplate restored, bogus finding row, an amendment old text no longer verbatim, a deleted case row in the protection trace, the ambiguous clock field restored, clock set to RUNNING) are each detected. **K3**: with the 34 rows classed and the manifest regenerated, the strict replay passes.

## Appendix: the exact change list

Each entry gives the file, where, the finding, the exact text now present (it occurs exactly once unless a count is shown) and the exact replacement.

### B1-1 `16_SOURCE_PROVENANCE_AND_COUNTS.json`

**Where:** replaces the `claimed_R2_verified_but_primary_file_not_mounted` block (lines 57-61). **Finding:** Ledger design members, D03 V3 and D04 V2 are not fixed in the group; decision record is not attached.

Says now:

```text
  "claimed_R2_verified_but_primary_file_not_mounted": {
    "name": "27-Oct owner-approved grouped 48h decision rules a,b",
    "reported_sha256": "d3f39baa27d8a8c91050d19dea32d83883b73eb1ddb80cf4d89dcfbee534143b",
    "status": "REPORTED_BY_USER_MESSAGE_NOT_VERIFIED_FROM_EXACT_BYTES_HERE"
  },
```

Replace with:

```text
  "primary_owner_decision": {
    "name": "27-Oct owner-approved grouped 48h decision, rules (a) and (b)",
    "file_in_package": "SOURCE_PINS_UNMODIFIED/A39_GROUP1_COOLING_OFF_OWNER_DECISION_V2.json",
    "sha256": "d3f39baa27d8a8c91050d19dea32d83883b73eb1ddb80cf4d89dcfbee534143b",
    "status": "ATTACHED_AND_HASH_RECOMPUTED_FROM_BYTES_BY_R2_20261113"
  },
  "additional_group_members": {
    "note": "Added by the R2 review so that every hash the baseline relies on is fixed in this group.",
    "stage_d03_zip": {
      "file": "War_Rig_V3_StageD03_Bounded_Mechanical_Residual_Fixes_20261113.zip",
      "sha256": "23bdbe3b7d0d34b8b1d19fd78daf9990b7ea89b506634da7d4953cea9ef67ead",
      "members_pinned_here": {
      "00_STAGE_D01_INTEGRATED_TECHNICAL_SPECIFICATION.md": "ae373e60fb136bde6a85862cdb466b6370d1d1af7a7c387d3ecb910c07706dc7",
      "01_EDGE_CONTRACTS_35_DRAFT.json": "eb9e29e14514988f6008815dbcd4bd3e584f62098068a669122adf39f6c6fd28",
      "02_NEGATIVE_GRAPH_COMPLEMENT_59_SOURCE_PRESERVED.json": "8023c7e7d1067f64b40dcea01647e9166af53e91d9a1603e2bbc9e04987e03bf",
      "03_THREE_LEDGER_EVENTS_DRAFT.json": "cc89fb339d068d31c8011fc623d5b4fc4bf5da6083ad1fc06f1228dd3953327a",
      "04_SIX_CLOCK_SCHEMA_DRAFT.json": "df3b788b265c6418b40e512ba2e05cb381d9e81fe675b7e183211a58927bfee9",
      "05_FORMAL_CROSSWALK_COUNTS_AND_PROVENANCE.json": "14136669797992d9c2fe069b4656780525e18f83a2aca6b0f8c99938656cdce1",
      "06_DETERMINISTIC_TEST_PLAN_UNEXECUTED.json": "fedd90a0e940cc4e454fcddb8949fb60a2b45d96b746a55808eb1e72a374b703",
      "07_OWNER_DECISIONS_FOR_CONTROLLED_DISPOSITION.json": "9239eeb9317ef2e1327b2635a8bd32fb93370c2de068dbf49af451bdc9e0f955",
      "12_PROPOSED_EXT_AND_WDA_CONTROLLED_SOURCE_ALIGNMENT_NOT_ADOPTED.md": "e79d78a55ebc696b9f5ac3bd6a2ea87cd37e957dc4c3751f75536fd8ed4fbef1"
      }
    },
    "d03_v3_design_pinned_in_package": {"file": "War_Rig_V3_D03_Order_Lifecycle_Protection_Sizing_Design_Proposal_V3.md", "sha256": "88975c34282f4f611b8d3bcad2c4598c16bf6465316b8d54caa55b3f09646661"},
    "d04_v2_design_pinned_in_package": {"file": "War_Rig_V3_D04_Signals_Models_Pricing_Data_Quality_Design_Proposal_V2.md", "sha256": "5e2ef530f8e50520959d79aa736f758d7256607ab772e8b08f5b1fa7bae41934"}
  },
  "fixed_by_reference_via_pinned_master_section_1_1": {
    "note": "Hashes are listed in the pinned master V1.8 section 1.1 table (D01, D02, D05, D06 and RG-01..RG-07 response ZIPs) and the V2 snapshot archive and instrument_map tables; bytes are held by the owner, not copied here.",
    "master_sha256": "dce9968ec3645cd03b786409c86eeb513826df9b6d14b340533973b7c08aafdd"
  },
```

### B4-1 `01_COMPLETE_OFFLINE_CORE_DESIGN_13_COMPONENTS.md`

**Where:** line 35, section `State contracts`. **Finding:** Seven axes listed here differ from the pinned Stage D specification section 3.

Says now:

```text
seven independent axes (intent, attempt, position, protection, monetary outcome, alert/clock, control-latch; canonical source taxonomy must be aligned before acceptance). Exact axes and edge IDs remain governed by source pins; this memo does not activate them.
```

Replace with:

```text
the seven ledger axes exactly as the pinned Stage D integrated specification section 3 defines them: `broker_operation`, `working_order`, `position`, `protection`, `realised_result` (the five Annex G axes) plus `intent_lifecycle` and `attempt_send_eligibility` (the two axes master V1.8 section 3.3 proposes). Alert, clock, manual-Stop, automatic-breaker and reset-authorisation records are control and watchdog records (master section 3.3, WDA-08); they are not among these seven ledger axes. Exact edge IDs remain governed by the pinned Stage D03 members `01_EDGE_CONTRACTS_35_DRAFT.json` and `02_NEGATIVE_GRAPH_COMPLEMENT_59_SOURCE_PRESERVED.json`; this memo does not activate them.
```

### B4-2 `04_CONTROLLED_SCOPE_SOURCE_AMENDMENT_SCHEDULE.md`

**Where:** row `EXT Annex G, WDA §3.1`. **Finding:** Amendment row misdescribes the axes and edges.

Says now:

```text
Five axes vs master seven axes and seven master-derived candidate edges
```

Replace with:

```text
Five Annex G axes in EXT/WDA vs the seven axes in the pinned Stage D specification (the five plus master section 3.3's `intent_lifecycle` and `attempt_send_eligibility`) and seven new candidate edges `D03-MST-036` to `D03-MST-042`
```

### B2-1 `01_COMPLETE_OFFLINE_CORE_DESIGN_13_COMPONENTS.md`

**Where:** heading before the five-instrument table (line 37). **Finding:** The configurable-instrument core of EXT-G0R-14 (section 3, EXT-01/02/13, V3EXT-006) is absent from the design baseline.

Says now:

```text
## All five instruments, offline only
```

Replace with:

```text
## Instrument definition layer (EXT-G0R-14 section 3; part of this baseline)

War Rig V3 is configurable by instrument, not hard-wired to five markets. This baseline includes the pinned EXT-G0R-14 section 3 model unchanged: a stable **instrument-family definition** whose typed fields each sit in tier T1, T2 or T3; separate **dated listings** with per-field evidence; an acyclic **input-evidence index**; and a **registration manifest** under which every plug-in is declared by signed hash. A new instrument is added by a new definition plus fixture data only, with zero source changes and zero plug-in-manifest changes (`V3EXT-006`, the first build milestone). Modules: `EXT-01 instrument_definition.py`, `EXT-02 plugin_manifest.py`, `EXT-13 contract_listing_registry.py`, mapped in `17_EXT_AND_ORIGINAL_UNIT_CROSSWALK.csv`; the layer sits under components 01, 03, 04 and 13 and is not a fourteenth component. Fail-closed: a missing or wrongly typed field, a T3 value that tries to override a T2 or T1 check, an uncertified or stale listing, or a missing mandatory check denies new entry (`V3EXT-002`, `-007`, `-010`). A second synthetic instrument is the `V3EXT-006` proof; the EXT Annex A six-instrument walkthrough (core five plus Brent) remains paper evidence and certifies no IG economics.

## All five instruments, offline only
```

### B2-2 `08_ACCEPTANCE_TEST_CONTRACT_AND_FAILURE_MATRIX.md`

**Where:** last row of the family table. **Finding:** No test family covers the instrument definition layer.

Says now:

```text
| TC-ISOLATION | direct IG hostname/DNS/IP/redirect/socket/stream, nested archive secret, unsafe path, unpinned mirror/lockfile | real network denied, secret intake quarantined, zero broker/credential imports |
```

Replace with:

```text
| TC-ISOLATION | direct IG hostname/DNS/IP/redirect/socket/stream, nested archive secret, unsafe path, unpinned mirror/lockfile | real network denied, secret intake quarantined, zero broker/credential imports |
| TC-INSTR | missing, extra or wrong-typed definition field; T3 value overriding a T2/T1 check; unmanifested or dynamically discovered plug-in; stale or uncertified listing; second synthetic instrument added by definition plus fixture only; synthetic equity of 1,000, 10,000 and larger with a below-minimum stake | unknown field or check denies entry; zero source and zero manifest change for the second instrument (`V3EXT-001` to `V3EXT-011`); no hard-coded instrument and no hard-coded minimum equity |
```

### B2-3 `04_CONTROLLED_SCOPE_SOURCE_AMENDMENT_SCHEDULE.md`

**Where:** row `Master V1.8 §3.1A`. **Finding:** Schedule must point to the crosswalk of original units 01-08 and EXT-01..13.

Says now:

```text
all broker-neutral behaviours included; IG gateway excluded
```

Replace with:

```text
all broker-neutral behaviours included; IG gateway excluded; original units 01-08 and `EXT-01` to `EXT-13` are mapped one by one in `17_EXT_AND_ORIGINAL_UNIT_CROSSWALK.csv`
```

### B2-4 `00_READ_ME_FIRST.md`

**Where:** Contents list. **Finding:** List the two new members in the read-me contents.

Says now:

```text
- `SOURCE_PINS_UNMODIFIED/` — fingerprinted copies of source proposals/reviews, never amended in place.
```

Replace with:

```text
- `17_...csv` — crosswalk of the eight original units and `EXT-01` to `EXT-13` to the 18 modules and 13 components; `18_...csv` — disposition class of each of the 43 master rows, with the 13 findings and 21 repairs to be classed; `19_...csv` — exact old-text and new-text rows of every controlled amendment.
- `SOURCE_PINS_UNMODIFIED/` — fingerprinted copies of source proposals/reviews, never amended in place.
```

### B3-1 `01_COMPLETE_OFFLINE_CORE_DESIGN_13_COMPONENTS.md`

**Where:** component 02 row (line 14). **Finding:** Model component loads trained models, contradicting G1R-08-M and EXT section 5.3; G0-R/G1-R text must not imply a V2 model runs.

Says now:

```text
| 02 | Model registry and inference | ModelArtifactRegistry | Pin model/data/feature and calibration hashes; load retained models without silent per-run fitting | model_manifest + input_snapshot -> SignalScore/NOT_PROVEN | Model missing/stale/unhashed -> no eligible entry; no unapproved fitting/promotion | Fixture model and hashes in G1; production training cadence later owner policy | TC-MODEL-* |
```

Replace with:

```text
| 02 | Model registry and inference | ModelArtifactRegistry (hash pinning only; no model loader) | Pin model/data/feature and calibration hashes; evaluate a signed, hash-registered fixture scoring function; no trained-model loader, no fitting, no promotion | model_manifest + input_snapshot -> SignalScore/NOT_PROVEN | Model missing/stale/unhashed -> no eligible entry; no fitting or promotion | Retained V2/V3 trained-model intake, training cadence and promotion are later separately authorised gates (EXT section 6 T-3; OC-D04-04) | TC-MODEL-* |
```

### B3-2 `01_COMPLETE_OFFLINE_CORE_DESIGN_13_COMPONENTS.md`

**Where:** component 03 row (line 15). **Finding:** Candidate publisher is excluded by G1R-08-C and EXT-07 yet used as module owner.

Says now:

```text
| 03 | Confidence, climate and selection | EffectivePolicyResolver + CandidatePublisher |
```

Replace with:

```text
| 03 | Confidence, climate and selection | EffectivePolicyResolver + EXT-04 strategy_evaluator (CandidatePublisher stays excluded) |
```

### B3-3 `02_SCOPE_C_COMPLETE_18_MODULE_SCHEDULE.csv`

**Where:** row ModelArtifactRegistry. **Finding:** Schedule marks ModelArtifactRegistry as fully implemented although its anchor test G1R-08-M rejects the import.

Says now:

```text
ModelArtifactRegistry,"`EXCLUDED`; effective-policy **manifest/hash field only**, not a model loader, registry/mock or runtime",FULL_OFFLINE_IMPLEMENTATION_CANDIDATE,G1R_OFFLINE_FIXTURE,Complete offline implementation using signed synthetic/historical snapshots; no IG dependency,
```

Replace with:

```text
ModelArtifactRegistry,"`EXCLUDED`; effective-policy **manifest/hash field only**, not a model loader, registry/mock or runtime",OFFLINE_FIXTURE_SCORING_ONLY_NO_MODEL_LOADER,G1R_OFFLINE_FIXTURE,Pure signed fixture scoring function registered by hash; no trained-model loader or fitting or promotion; no IG dependency,
```

### B3-4 `02_SCOPE_C_COMPLETE_18_MODULE_SCHEDULE.csv`

**Where:** row CandidatePublisher. **Finding:** Schedule marks CandidatePublisher as built although G1R-08-C is unchanged negative and EXT-07 is excluded.

Says now:

```text
CandidatePublisher,`EXCLUDED`,FULL_OFFLINE_IMPLEMENTATION_CANDIDATE,G1R_OFFLINE_FIXTURE,Complete offline implementation using signed synthetic/historical snapshots; no IG dependency,
```

Replace with:

```text
CandidatePublisher,`EXCLUDED`,EXCLUDED_RESERVED_EXT07_NO_PUBLISHER_OR_STORE,G1R_OFFLINE_FIXTURE,Not built: candidate records are carried by intent identity plus ledger plus audit events and emitted by the pure strategy evaluator EXT-04; no IG dependency,
```

### B3-5 `02_SCOPE_C_COMPLETE_18_MODULE_SCHEDULE.csv`

**Where:** row AnchorQuoteValidator. **Finding:** Schedule marks AnchorQuoteValidator as fully implemented although G1R-08-Q rejects quote/anchor module import.

Says now:

```text
AnchorQuoteValidator,`EXCLUDED`,FULL_OFFLINE_IMPLEMENTATION_CANDIDATE,G1R_OFFLINE_FIXTURE,Complete offline implementation using signed synthetic/historical snapshots; no IG dependency,
```

Replace with:

```text
AnchorQuoteValidator,`EXCLUDED`,OFFLINE_PURE_VALIDATOR_OVER_FIXTURE_QUOTES,G1R_OFFLINE_FIXTURE,Pure bid/ask validator over signed fixture quotes only; no feed or broker-quote or anchor-module import; no IG dependency,
```

### B3-6 `04_CONTROLLED_SCOPE_SOURCE_AMENDMENT_SCHEDULE.md`

**Where:** after row `EXT V3EXT-070`. **Finding:** No amendment row for the three pinned negative oracles G1R-08-M, -C, -Q.

Says now:

```text
| EXT V3EXT-070 | Prohibits any stop-modification import when adaptive field unselected | Prohibit IG/real transport imports; allow local simulated modify under signed fixture/mode with deterministic negative tests | `LIVE_TIGHTEN_ONLY` denied, simulator path exercised | PROPOSED/OPEN |
```

Replace with:

```text
| EXT V3EXT-070 | Prohibits any stop-modification import when adaptive field unselected | Prohibit IG/real transport imports; allow local simulated modify under signed fixture/mode with deterministic negative tests | `LIVE_TIGHTEN_ONLY` denied, simulator path exercised | PROPOSED/OPEN |
| EXT section 5.3 `G1R-08-M` | Rejects model/runtime registry import | Keep rejection of any model fitting, training, promotion or runtime model registry. Permit only a pure deterministic fixture scoring function registered by hash in the plug-in manifest, with no file or model loader and no network. Retained V2/V3 trained artifacts are not loadable in this grant | Negative test: any trained-model loader import is denied; replacement ID `V3EXT-021` | PROPOSED/OPEN |
| EXT section 5.3 `G1R-08-C` | Rejects candidate publication service import | No change. `EXT-07` and `CandidatePublisher` stay excluded; candidate records are carried by intent identity, ledger and audit events and emitted by the pure strategy evaluator `EXT-04` | Existing negative oracle stays; `V3EXT-022` | UNCHANGED |
| EXT section 5.3 `G1R-08-Q` | Rejects broker quote/anchor module import | Keep rejection of any broker quote, feed or anchor module. Permit only a pure bid/ask validator over signed fixture quotes | Negative test: no quote-adapter or anchor-module import; `V3EXT-023` | PROPOSED/OPEN |
```

### B3-7 `13_G1R_OFFLINE_IMPLEMENTATION_GRANT_FORM_UNSIGNED.md`

**Where:** proposed owner grant text. **Finding:** Grant text says 'retained inference', which the owner could read as a V2 model running.

Says now:

```text
market data, retained inference, confidence
```

Replace with:

```text
market data, fixture-scored inference (no trained V2 or V3 model is loaded under this grant), confidence
```

### B5-1 `00_READ_ME_FIRST.md`

**Where:** line 32, `Historical evidence caution`. **Finding:** 27 Oct decision is described as not mounted; it is attached and byte-verified.

Says now:

```text
R2 reported verifying the later decision's hash `d3f39baa…`, but the exact approved file is not mounted in this package. Attach/hash-verify that primary record and its approved rules (a),(b) before declaring the timing route legally/procedurally settled. Its absence is a presentation blocker, not permission to waive timing.
```

Replace with:

```text
The approved decision is attached byte for byte as `SOURCE_PINS_UNMODIFIED/A39_GROUP1_COOLING_OFF_OWNER_DECISION_V2.json` (SHA-256 `d3f39baa27d8a8c91050d19dea32d83883b73eb1ddb80cf4d89dcfbee534143b`, re-computed from its bytes by R2 on 13 Nov 2026). Owner reply, verbatim: "Cooling-off duration: 48 hours. I accept rules (a) and (b) as written." Rule (a): one interval covers proposals presented together once the full group, every final proposal, its evidence and each SHA-256 are fixed, and it starts after the last final evidence-bound presentation. Rule (b): a change to proposal text, evidence-bound scope or SHA-256 restarts the clock, and for an indivisible group it restarts the whole group clock. The Group 1 V2 addendum pinned here records the duration as UNSET and the cooling-off decision as pending; the 27 Oct decision above sets the duration and supersedes that statement for duration only.
```

### B5-2 `10_GOVERNANCE_CONFORMANCE_AND_SINGLE_48H_RULE.md`

**Where:** line 3. **Finding:** Working Path 1 is labelled R2-reported and not owner-selected.

Says now:

```text
**Working Path 1 reported by R2 (13 Nov 2026), NOT owner-selected.**
```

Replace with:

```text
**Working Path 1: recommended by R2 and sent to the author at the owner's request (13 Nov 2026); recorded as OD-13 and binding only through the owner's signed records.**
```

### B5-3 `10_GOVERNANCE_CONFORMANCE_AND_SINGLE_48H_RULE.md`

**Where:** line 3. **Finding:** Reliance on 'R2's reported direct inspection' is replaced by the attached record.

Says now:

```text
This relies on R2's reported direct inspection of the 27 Oct source decision rules (a),(b). The exact subsequently approved decision bytes/hash are an **outstanding final-evidence attachment**; a local historical `PENDING_V1` placeholder is specifically NOT relied upon.
```

Replace with:

```text
This rests on rules (a) and (b) of the owner-approved 27 Oct decision, attached under `SOURCE_PINS_UNMODIFIED` (`A39_GROUP1_COOLING_OFF_OWNER_DECISION_V2.json`, SHA-256 `d3f39baa…`, bytes verified by R2). A local historical `PENDING_V1` placeholder is specifically NOT relied upon.
```

### B5-4 `10_GOVERNANCE_CONFORMANCE_AND_SINGLE_48H_RULE.md`

**Where:** row `27 Oct rule (a)`. **Finding:** Table cells still say R2-reported / attach.

Says now:

```text
R2-reported cooling-off owner decision SHA
```

Replace with:

```text
Owner-approved cooling-off decision (attached) SHA
```

### B5-5 `10_GOVERNANCE_CONFORMANCE_AND_SINGLE_48H_RULE.md`

**Where:** row `27 Oct rule (a)`. **Finding:** Table cell still asks to attach the decision.

Says now:

```text
Attach/hash original decision; verify exact rule text and end-to-end group hashes
```

Replace with:

```text
Decision attached and byte-verified; end-to-end group hashes are fixed at the final presentation
```

### B5-6 `15_READINESS_BLOCKERS_AND_UNSET_VALUES.md`

**Where:** item 7. **Finding:** Item 7 still says the decision is not mounted.

Says now:

```text
7. **Primary timing proof:** R2 reports checking approved 27 October rule (a)/(b) decision (`d3f39baa…`), but the exact approved decision is not present in these mounted source files; earlier **pending V1** is not adequate. Attach hash-verified actual approved decision before final presentation. Recheck any incompatible master clause once, rather than restarting GOV-48-01 amendment by default.
```

Replace with:

```text
7. **Primary timing proof:** done. The owner-approved 27 October decision (`A39_GROUP1_COOLING_OFF_OWNER_DECISION_V2.json`, `d3f39baa…`) is attached and byte-verified: 48 elapsed hours, rules (a) and (b). Remaining: record the final-group manifest and the presentation time (UTC) at the final presentation. `V3-GOV-48-01` is not needed under Path 1.
```

### B5-7 `14_GROUP_48H_CLOCK_NOT_STARTED.json`

**Where:** line 4. **Finding:** Clock file says the rules are not verified in this package.

Says now:

```text
"interpretation": "R2_PROPOSED_PATH1_FROM_OWNER_DESCRIBED_GROUP_RULE_A_AND_B_NOT_YET_VERIFIED_IN_THIS_PACKAGE",
```

Replace with:

```text
"interpretation": "PATH1_ON_OWNER_APPROVED_27_OCT_RULES_A_AND_B_VERIFIED_FROM_ATTACHED_BYTES",
```

### B5-8 `14_GROUP_48H_CLOCK_NOT_STARTED.json`

**Where:** line 15. **Finding:** Clock file: hash is not 'reported'.

Says now:

```text
"governing_duration_primary_decision_sha256_reported":
```

Replace with:

```text
"governing_duration_primary_decision_sha256":
```

### B5-9 `14_GROUP_48H_CLOCK_NOT_STARTED.json`

**Where:** line 16. **Finding:** Clock file: file is now verified.

Says now:

```text
"primary_decision_file_verified_locally": false,
```

Replace with:

```text
"primary_decision_file_verified_locally": true,
```

### B6-1 `11_INDEPENDENT_VERIFICATION_AND_QUORUM_RECORD_UNSIGNED.md`

**Where:** role crosswalk row. **Finding:** Quorum crosswalk row does not name the controlled path (CAR-01) that Group 1 principle 5 requires.

Says now:

```text
| Required quorum/owner role crosswalk | `[source exact requirement -> verified actors]` | UNRESOLVED |
```

Replace with:

```text
| Required quorum/owner role crosswalk | `[source exact requirement -> verified actors]`; must state whether CAR-01 (Group 1 V1 record, `next_controlled_contract_decision`, status NOT_APPROVED_NOT_PERFORMED) is decided inside this group before a sole-owner record can stand in for the V32 independent-reviewer and quorum rules, K1/H13 countersignatures and two-person rules that Group 1 principle 5 keeps in force, or whether the V32 text shows that a control does not apply to an offline-only grant | UNRESOLVED |
```

### B6-2 `15_READINESS_BLOCKERS_AND_UNSET_VALUES.md`

**Where:** item 5. **Finding:** Item 5 does not tell the owner the one thing only he can settle.

Says now:

```text
are not supplied and cannot be auto-attested by the author.
```

Replace with:

```text
are not supplied and cannot be auto-attested by the author. Only the owner can settle this, once, by choosing one of: name real independent humans for the controls in force; include a CAR-01 decision in this same group; or record from the V32 text that the control does not apply to an offline-only grant.
```

### B7-1 `05_CONSOLIDATED_61_ROW_OWNER_DECISION_REGISTER_NOT_SELECTED.csv`

**Where:** row OD-13. **Finding:** OD-13 topic still says G1-only.

Says now:

```text
G1-only cooling-off placement
```

Replace with:

```text
Cooling-off placement: one grouped 48h interval then G0-R and G1-R signed in one sitting (Path 1)
```

### B7-2 `05_CONSOLIDATED_61_ROW_OWNER_DECISION_REGISTER_NOT_SELECTED.csv`

**Where:** row OD-13. **Finding:** OD-13 candidate says 'only if primary governance proof confirms'; the proof is attached.

Says now:

```text
; only if primary governance proof confirms
```

Replace with:

```text
; primary proof attached: 27 Oct decision d3f39baa… rules (a) and (b) byte-verified by R2 on 13 Nov 2026
```

### C1-1 `10_GOVERNANCE_CONFORMANCE_AND_SINGLE_48H_RULE.md`

**Where:** step 1. **Finding:** Pre-presentation selections must be marked provisional so the owner does not think they are already binding.

Says now:

```text
Resolve owner selections **before** final evidence-bound presentation, but no final G0/G1 acceptance signature before the waiting interval.
```

Replace with:

```text
Resolve owner selections **before** final evidence-bound presentation, but no final G0/G1 acceptance signature before the waiting interval. A selection made before the presentation is a provisional input that becomes binding only through the two signed records at the sitting; a selection changed after the presentation is a change to the group and restarts the interval.
```

### R1-1 `04_CONTROLLED_SCOPE_SOURCE_AMENDMENT_SCHEDULE.md`

**Where:** header paragraph. **Finding:** R1 F-01: amendments are described, not written; the signed baseline would still contain the pinned prohibition on order/stop/close operations. Exact old/new text is required (EXT section 5.3 rule), and until signature the behaviour is proposed and unapproved.

Says now:

```text
The clauses below are **amendment proposals**; signing this schedule alone does not mutate their source files.
```

Replace with:

```text
The clauses below are **amendment proposals**; signing this schedule alone does not mutate their source files. The controlling form of each amendment is its exact old-text and new-text row in `19_CONTROLLED_AMENDMENT_EXACT_TEXT.csv`; each takes effect only when the owner signs the G0-R record against the final group root, and until then simulator trading and simulated stop modification are proposed and unapproved, not authorised by the pinned contracts.
```

### R1-2 `04_CONTROLLED_SCOPE_SOURCE_AMENDMENT_SCHEDULE.md`

**Where:** before row `EXT V3EXT-070`. **Finding:** R1 F-01: no amendment row for EXT section 1.2 invariant 1, which prohibits order/stop/close operations in G1-R.

Says now:

```text
| EXT V3EXT-070 | Prohibits any stop-modification import when adaptive field unselected |
```

Replace with:

```text
| EXT section 1.2 invariant 1 | Prohibits "order/stop/close operations" in the G1-R build and runtime | Read as real-broker operations only; simulated order, stop and close operations inside `OfflineBrokerSimulator` are test-only and have no real transport, credential or network path | Negative tests `V3EXT-024`, `-025` and the TC-ISOLATION family; real operations remain denied | PROPOSED/OPEN |
| EXT V3EXT-070 | Prohibits any stop-modification import when adaptive field unselected |
```

### R1-3 `02_SCOPE_C_COMPLETE_18_MODULE_SCHEDULE.csv`

**Where:** row EntryEligibilityEngine. **Finding:** R1 F-02: stale dependency wording contradicts FULL_OFFLINE disposition (EntryEligibilityEngine).

Says now:

```text
,Actual decision engine later,NOT_SELECTED
```

Replace with:

```text
,Real feed and IG account inputs only; the decision engine itself is built offline,NOT_SELECTED
```

### R1-4 `02_SCOPE_C_COMPLETE_18_MODULE_SCHEDULE.csv`

**Where:** row ExposureRiskLedger. **Finding:** R1 F-02: stale dependency wording contradicts FULL_OFFLINE disposition (ExposureRiskLedger).

Says now:

```text
,Monetary ledger after approved separate slice,NOT_SELECTED
```

Replace with:

```text
,Real monetary limits and account equity are UNSET until G3; the ledger is built offline against signed fixture policy,NOT_SELECTED
```

### R1-5 `02_SCOPE_C_COMPLETE_18_MODULE_SCHEDULE.csv`

**Where:** row CandidatePublisher. **Finding:** R1 F-02: stale dependency wording on CandidatePublisher after it is excluded (B3-4).

Says now:

```text
,"Later offline slice, separate scope",NOT_SELECTED
```

Replace with:

```text
,Reserved as EXT-07; considered again only by a separately reviewed scope,NOT_SELECTED
```

### R1-6 `03_BROKER_NEUTRAL_EXECUTION_AND_SIMULATOR_CONTRACT.md`

**Where:** interface sketch, line 12. **Finding:** R1 F-04: submit_market carries no initial stop or geometry, and no contract states the trace between fill and verified protection.

Says now:

```text
submit_market(intent_id, attempt_id, policy_hash, side, stake, guard_hash)
```

Replace with:

```text
submit_market(intent_id, attempt_id, policy_hash, side, stake, geometry, guard_hash)
```

### R1-7 `03_BROKER_NEUTRAL_EXECUTION_AND_SIMULATOR_CONTRACT.md`

**Where:** after the interface block, before the CapabilityRecord bullet. **Finding:** R1 F-04: add the fill-to-protection trace to the interface contract.

Says now:

```text
- `CapabilityRecord` must declare tick/price grid
```

Replace with:

```text
**Initial stop and fill-to-protection trace.** `geometry` is (stop_distance, limit_distance or none) as validated by the entry engine. It is part of the preimage of `guard_hash`, so the simulator cannot be handed a different stop than the one the guard approved. The position axis and the protection axis (master V1.8 section 3.3) then move only on read-back evidence:

| Case | Position axis | Protection axis | Reservation | Until protection is VERIFIED |
|---|---|---|---|---|
| Full fill; `read_position` shows an applied stop equal to or tighter than the requested stop | `OPEN_CONFIRMED` | `PROTECTION_VERIFIED` | gross reservation kept for the open position | tighten-only modification allowed |
| Partial fill | `OPEN_CONFIRMED` for the filled quantity, versioned on each fill | evaluated on the filled position exactly as in the other rows | filled quantity and any still-working remainder both reserved | as in the other rows |
| Fill with no initial stop applied, or an applied stop looser than requested | `OPEN_CONFIRMED` | `PROTECTION_DRIFT` if positively proven, otherwise `PROTECTION_UNVERIFIED` | kept | every ATC modification frozen and an alert raised; new-entry consequences follow the pinned D05/D06 admission rules, and an unset rule denies |
| Initial stop rejected, or `modify_stop` UNKNOWN | `OPEN_CONFIRMED` | `PROTECTION_UNVERIFIED`; the requested stop is never treated as applied | kept | as above; no retry under the same intent; a new modify intent only after a fresh read-back |
| `read_position` UNKNOWN or stale | `OPEN_CONFIRMED` or `BROKER_OUTCOME_UNKNOWN` as the evidence supports | `PROTECTION_UNVERIFIED` | kept | as above |
| Audit append fails before a simulated stop move | unchanged | unchanged | kept | the move is denied; no unaudited mutation |

`PROTECTION_VERIFIED` is reached only by a fresh attributable read-back of the applied stop.

- `CapabilityRecord` must declare tick/price grid
```

### R1-8 `08_ACCEPTANCE_TEST_CONTRACT_AND_FAILURE_MATRIX.md`

**Where:** before row TC-INSTR. **Finding:** R1 F-04: no test family covers fill-to-protection.

Says now:

```text
| TC-INSTR |
```

Replace with:

```text
| TC-PROTECT | full fill with verified stop; partial fill; fill with no initial stop; initial stop looser than requested; initial stop rejected; `modify_stop` UNKNOWN; `read_position` UNKNOWN or stale; audit append failure before the simulated stop move | position axis, protection axis, reservation and allowed or denied actions match the trace table in file 03 for every case; a requested stop is never recorded as applied; VERIFIED only after a fresh attributable read-back; no retry under the same intent |
| TC-INSTR |
```

### R1-9 `14_GROUP_48H_CLOCK_NOT_STARTED.json`

**Where:** line 6. **Finding:** R1 F-07: clock file shows status NOT_STARTED beside duration_elapsed_hours 48.

Says now:

```text
"duration_elapsed_hours": 48,
```

Replace with:

```text
"required_duration_elapsed_hours": 48,
  "elapsed_hours_so_far": 0,
```

### New member 17 `17_EXT_AND_ORIGINAL_UNIT_CROSSWALK.csv`

Generated by the script; contents:

```csv
source_unit,source_file,source_status,mapped_module_row_in_02,mapped_component_in_01,disposition_in_this_grant,test_family,note
unit 01,effective_policy.py,original G1-R unit,EffectivePolicyResolver,"03, 13",ADMITTED,"TC-CONF, TC-ISOLATION",extended by EXT-01
unit 02,intent_identity.py,original G1-R unit,IntentLedger & SingleWriter,10,ADMITTED,"TC-ENGINE, TC-STATE",
unit 03,state_ledger.py,original G1-R unit,IntentLedger & SingleWriter,10,ADMITTED,TC-STATE,"seven axes, 42 edges"
unit 04,audit_events.py,original G1-R unit,AuditCustody & Dashboard; IndependentWatchdog & AlertProof,"10, 11",ADMITTED,TC-AUDIT,
unit 05,control_latches.py,original G1-R unit,StopBreakerControls,10,ADMITTED,TC-STATE,
unit 06,calendar_completion.py,original G1-R unit,SourceSnapshotLoader,01,ADMITTED,TC-DATA,
unit 07,synthetic_observer.py,original G1-R unit,AccountBoundBrokerObserver,"07, 09",ADMITTED (simulated observer only),"TC-SIM, TC-RECON",no live IG read
unit 08,capability_guard.py + tests/offline,original G1-R unit,EffectivePolicyResolver + OfflineBrokerSimulator + audit,13,ADMITTED,TC-ISOLATION,extended by EXT-02
EXT-01,instrument_definition.py,EXT-G0R-14 section 5.2 ADD,EffectivePolicyResolver,"instrument layer (under 01, 03, 04, 13)",ADMITTED,TC-INSTR,V3EXT-001..003
EXT-02,plugin_manifest.py,EXT-G0R-14 section 5.2 ADD,EffectivePolicyResolver + audit (capability guard),instrument layer; 13,ADMITTED,"TC-INSTR, TC-ISOLATION","V3EXT-004, -005"
EXT-03,macro_features.py,EXT-G0R-14 section 5.2 ADD,SourceSnapshotLoader,01,ADMITTED,TC-DATA,as-of / vintage; late publication denies
EXT-04,strategy_evaluator.py,EXT-G0R-14 section 5.2 ADD,EntryEligibilityEngine,"03, 04",ADMITTED (pure evaluation; no model loader),"TC-CONF, TC-STRAT",emits candidates; replaces CandidatePublisher
EXT-05,risk_math.py,EXT-G0R-14 section 5.2 ADD,ExposureRiskLedger,05,ADMITTED,TC-RISK,pure synthetic equations
EXT-06,synthetic_backtester.py + fixture_policy_loader.py + offline_scenario_runner.py,EXT-G0R-14 section 5.2 ADD,ComparisonEvaluator; OfflineBrokerSimulator,"07, 12, 13",ADMITTED,"TC-COMP, TC-SIM",FIXTURE_ONLY signed-domain policy loader
EXT-07,offline_candidate_store.py,EXT-G0R-14 section 5.2 EXCLUDED/RESERVED,CandidatePublisher,none,EXCLUDED_RESERVED,TC-ISOLATION,G1R-08-C stays negative
EXT-08,offline_reconciler.py,EXT-G0R-14 section 5.2 ADD,ConfirmationReconciler,09,ADMITTED,TC-RECON,
EXT-09,audit_projection.py,EXT-G0R-14 section 5.2 ADD,AuditCustody & Dashboard,11,ADMITTED (read-only projection),TC-AUDIT,no control route
EXT-10,data_intake_schema.py,EXT-G0R-14 section 5.2 ADD,SourceSnapshotLoader; ComparisonEvaluator,"01, 12",ADMITTED (schema and mock validation only),"TC-DATA, TC-COMP",real ingestion is a separate authorisation
EXT-11,offline_eligibility.py + supervision_admission_validator.py,EXT-G0R-14 section 5.2 ADD,EntryEligibilityEngine; IndependentWatchdog & AlertProof,"04, 10",ADMITTED,"TC-STRAT, TC-AUDIT",WDA-08 section 4 nine-predicate fixture validator
EXT-12,synthetic_fill_model.py,EXT-G0R-14 section 5.2 ADD,OfflineBrokerSimulator,07,ADMITTED,TC-SIM,never broker proof
EXT-13,contract_listing_registry.py,EXT-G0R-14 section 5.2 ADD,EffectivePolicyResolver,instrument layer,ADMITTED,TC-INSTR,"V3EXT-003, -010"
```

### New member 19 `19_CONTROLLED_AMENDMENT_EXACT_TEXT.csv`

Generated by the script. Each row quotes the pinned source verbatim (the checker confirms it occurs exactly once) and gives the replacement; each takes effect only when the owner signs the G0-R record against the final group root.

**AM-01** (`EXT_G0R_14_UNCHANGED.md`; negative test: V3EXT-024, V3EXT-025, TC-ISOLATION)

Old:

```text
real market-data network acquisition, order/stop/close operations, external notifications
```

New:

```text
real market-data network acquisition, real-broker order/stop/close operations (simulated order, stop and close operations inside the OfflineBrokerSimulator are test-only and have no real transport, credential or network path), external notifications
```

**AM-02** (`EXT_G0R_14_UNCHANGED.md`; negative test: V3EXT-070 (amended oracle))

Old:

```text
no stop-modification import or real permit; explicit signed fixture policies only
```

New:

```text
no real-broker or IG stop-modification import or real permit; a simulator-only stop modification is permitted solely in mode SIMULATOR_ONLY_TIGHTEN under explicit signed fixture policies
```

**AM-03** (`EXT_G0R_14_UNCHANGED.md`; negative test: TC-STATE)

Old:

```text
**Five distinct state axes:** `broker_operation`, `working_order`, `position`, `protection`, `realised_result`.
```

New:

```text
**Seven distinct state axes:** the five Annex G axes `broker_operation`, `working_order`, `position`, `protection`, `realised_result` plus `intent_lifecycle` and `attempt_send_eligibility` (master V1.8 section 3.3, Stage D01 specification section 3).
```

**AM-04** (`ATC_01_REV2_UNCHANGED.md`; negative test: TC-ATC)

Old:

```text
`OFF`, `COMPUTE_AND_LOG_ONLY`, `LIVE_TIGHTEN_ONLY`.
```

New:

```text
`OFF`, `COMPUTE_AND_LOG_ONLY`, `SIMULATOR_ONLY_TIGHTEN`, `LIVE_TIGHTEN_ONLY` (unavailable in this grant).
```

**AM-05** (`MASTER_V1_8_CORRECTED_UNCHANGED.md`; negative test: TC-ISOLATION)

Old:

```text
no broker endpoint reachable, no trade, no fitting or policy activation;
```

New:

```text
no broker endpoint reachable, no real trade (simulated trades against the OfflineBrokerSimulator are permitted), no model fitting, no policy activation;
```

**AM-06** (`MASTER_V1_8_CORRECTED_UNCHANGED.md`; negative test: TC-ISOLATION)

Old:

```text
### 3.1A Complete module-to-first-slice mapping and test-oracle plan (PROPOSED)
```

New:

```text
### 3.1A Complete module-to-first-slice mapping and test-oracle plan (REPLACED for Scope C by file 02 of the consolidated package, 18 rows; the 16-row table that follows is superseded)
```

**AM-07** (`OD14_03_REVIEW_UNCHANGED.md`; negative test: TC-ATC, TC-ISOLATION)

Old:

```text
For restricted offline scope, keep every V3 protective broker action disabled: automatic stop repair, stop tightening or trailing, close and cancel.
```

New:

```text
For this offline scope, keep every real-broker V3 protective action disabled: automatic stop repair, stop tightening or trailing, close and cancel against IG. Simulated stop tightening, trailing, close and cancel against the OfflineBrokerSimulator are permitted as test-only under mode SIMULATOR_ONLY_TIGHTEN and signed fixture policies.
```

**AM-08** (`OD14_03_REVIEW_UNCHANGED.md`; negative test: TC-ATC)

Old:

```text
V3 stop tightening or trailing stays disabled until separately decided
```

New:

```text
real-broker V3 stop tightening or trailing stays disabled until separately decided (simulated tightening and trailing are in scope)
```

**AM-09** (`OD14_03_REVIEW_UNCHANGED.md`; negative test: TC-ATC, V3EXT-070)

Old:

```text
Offline V3 cannot send orders, so these cannot run here; `adaptive_protection_required` stays `UNSELECTED` and V3EXT-070 denies.
```

New:

```text
Offline V3 sends no real orders; these run here against the OfflineBrokerSimulator under signed fixture policies, with stop modification in mode SIMULATOR_ONLY_TIGHTEN; `adaptive_protection_required` stays `UNSELECTED` for any real broker and V3EXT-070 denies every real-broker path.
```

### New member 18 `18_REGISTER_DISPOSITION_CLASSES.csv`

Generated by the script from file 05 (43 master rows classed; 13 findings and 21 repairs listed for the author to class). Legend:

- `K_KEEP_OFF_UNTIL_LATER_GATE`: Stays switched off. The offline simulator may use a labelled test value; the real value is chosen by the owner at G2, G3 or G4. Nothing here allows a real trade.
- `D_DESIGN_ADOPTED_FOR_OFFLINE_CORE`: The rule is built into the offline system and tested on the simulator. Proof against the real broker comes later.
- `C_CARRY_PRIOR_DECISION`: Settled earlier; carried unchanged. No new choice is asked now.

