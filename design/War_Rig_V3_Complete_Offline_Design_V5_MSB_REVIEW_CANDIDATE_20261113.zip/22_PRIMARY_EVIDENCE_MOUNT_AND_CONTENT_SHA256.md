# Primary evidence and status audit (added during the merged correction round)

- The original source package SHA is `dac6eb6e377923fe6043d4b583b63d08bdc25f3b4002e4e0c1705dbb09c4c8a7`.
- `SOURCE_PINS_UNMODIFIED/War_Rig_V3_StageD03_Bounded_Mechanical_Residual_Fixes_20261113.zip` is attached as a byte-identical archival copy, SHA-256 `23bdbe3b7d0d34b8b1d19fd78daf9990b7ea89b506634da7d4953cea9ef67ead`.
- Nine extracted `STAGE_D03_REVIEW_BYTES` members are individually hash-verified to the immutable R2 `required_pins.json`, including `00_STAGE_D01_INTEGRATED_TECHNICAL_SPECIFICATION.md` and `06_DETERMINISTIC_TEST_PLAN_UNEXECUTED.json` (the 187 test specification source).
- `SOURCE_PINS_UNMODIFIED/A39_GROUP1_COOLING_OFF_OWNER_DECISION_V2.json` SHA-256 `d3f39baa27d8a8c91050d19dea32d83883b73eb1ddb80cf4d89dcfbee534143b` contains owner rule (a) and (b) and 48h duration, *not* a running timer.
- `SOURCE_PINS_UNMODIFIED/War_Rig_V3_D03_Order_Lifecycle_Protection_Sizing_Design_Proposal_V3.md` SHA-256 `88975c34282f4f611b8d3bcad2c4598c16bf6465316b8d54caa55b3f09646661`.
- `SOURCE_PINS_UNMODIFIED/War_Rig_V3_D04_Signals_Models_Pricing_Data_Quality_Design_Proposal_V2.md` SHA-256 `5e2ef530f8e50520959d79aa736f758d7256607ab772e8b08f5b1fa7bae41934`.
- Actual independent human review, original V32 clause applicability, real G1-R environment evidence, owner selections and approval forms remain absent. Hash verification establishes byte identity **only**, not substantive acceptance.
