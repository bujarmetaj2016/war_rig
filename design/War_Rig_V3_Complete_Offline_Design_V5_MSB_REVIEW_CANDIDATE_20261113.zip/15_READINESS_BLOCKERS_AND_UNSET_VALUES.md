# Readiness to present a final immutable group — current blockers / NOT a new stage

This file keeps the process to **one consolidated owner stage**. These are **conditions inside that stage**, not new approval stages. Only a safety defect, master contradiction, unbuildable core contract, misrepresented approval, or missing required human evidence blocks presentation. Numeric fixture tuning may be decided at implementation; unselected values can never authorise real money dealing.

## Remaining substantive completion items

1. **Scope:** Owner has not yet selected exact Master R + EXT C in a controlled register. Original master §3.1A eight-unit restriction must be amended to all broker-neutral offline modules, and paired simulator/IG isolation semantics independently checked.
2. **Decision register:** 14 Stage D and 4 ATC decisions, all 43 master binding questions, 13 freeze findings and 21 repairs remain unselected/open in this candidate. Convert proposals into explicit owner choices and verified dispositions once; do not infer consent from today's request to generate a package.
3. **Source corrections:** EXT §1.1, master §3.1A, OD-01 and OD-06, V3EXT-070, ATC-T11/§5 and the proposed seven-axis/42-edge alignment need controlled final amended source artifacts. The immutable historical pins here are **not amended**.
4. **Technical completeness:** Full offline interface contracts are specified here; independent checker must validate executable feasibility including simulated protection, fixture-only controls, position-closed truth and no-IG capability proof. Stage D03's N12 cross-axis atomicity test contract still needs authoritative alignment. All tests listed are NOT_RUN.
5. **Evidence of reviewer independence:** R2 authored WDA-08 and ATC-01; R2 cannot certify those independently. Reviewer appointment, actual reviewer evidence, quorum, K1/H13/witness and external custody are not supplied and cannot be auto-attested by the author. Only the owner can settle this, once, by choosing one of: name real independent humans for the controls in force; include a CAR-01 decision in this same group; or record from the V32 text that the control does not apply to an offline-only grant.
6. **G1-R packet before group presentation:** signed deny-egress environment policy, real quarantine secret-scan report, build graph, no-V2-bytes proof, mirror/lockfile hashes, and hostile-test manifest all need actual evidence with hashes. Plans for tests are not results.
7. **Primary timing proof:** done. The owner-approved 27 October decision (`A39_GROUP1_COOLING_OFF_OWNER_DECISION_V2.json`, `d3f39baa…`) is attached and byte-verified: 48 elapsed hours, rules (a) and (b). Remaining: record the final-group manifest and the presentation time (UTC) at the final presentation. `V3-GOV-48-01` is not needed under Path 1.
8. **Group presentation:** after final evidence and all source/decision/document values are fixed, record a final indivisible group member manifest, exact SHA256s, latest actual presentation UTC, and the 48 elapsed hours with no changes. This candidate itself is not that final group; changes after presenting would restart the wait.
9. **Two records in one sitting:** G0-R acceptance and G1-R grant require different exact fingerprint records, executed in that order at one owner sitting. No automatic permission after the clock.

## Values deliberately UNSET (not blockers to simulation architecture)

- G3 IG account/epic/product point value, minimum stake/stop/step and stop modification guarantee for five markets;
- real GBP monetary caps, equity/margin/FX/live risk ratios, instrument trade authority and any LIVE exposure limit;
- six D1–D3 / E1–E3 operational clock values, alert recipients/channels, delivery/ACK SLAs;
- active V3 model training cadence and release/promotion authority;
- Core-5 frozen model artifacts (none registered or eligible in the inspected locations; other hosts and S3 not checked; MS-F fit-and-freeze authorisation if wanted), the registered parity tolerance, and the live-folder hash of `live_inference.py` (`PENDING_OWNER_CHECK`);
- per-instrument and per-regime adaptation parameters, candidate split shares and threshold values;
- actual human protective-response A/B/C, backup owner and closed-market IG rescue procedures;
- requested IG-specific quote/confirmation/retry semantics and actual operational data delivery;
- calibrated side-specific short-model production proofs.

Every simulation test must carry a **signed fixture-scoped** value and a negative test proving it cannot be silently promoted into IG authority. No IG gate is activated by this document.

**Bottom line:** The package is ready to review and complete **in one consolidated round**, but is **not yet acceptance-ready** and **must not start the 48-hour clock** until all indicated final group membership and approval prerequisites are genuinely complete.

**Independence applicability crosswalk:** `19_GROUP1_INDEPENDENCE_APPLICABILITY_OWNER_ROUTE_NOT_SELECTED.md` retains Group 1 principle 5, names CAR-01 and the three real choices (human compliance, controlled CAR-01 replacement, source-exact nonapplicability). **None is selected.** The original V32 contract clauses remain missing in this group; a human independent reviewer is not yet appointed.

**Second-review clarification:** core eligibility, simulated monetary risk/exposure, stop monitor and reconciliation are required runtime capabilities in G1-R fixture scope and cannot be deferred as mocked schemas. See `02_...csv`, `03_...` and TC-INIT tests. The candidate publisher and the real quote/anchor module remain excluded; the trained-model loader is limited to the single MS-B intake module of file 24.
