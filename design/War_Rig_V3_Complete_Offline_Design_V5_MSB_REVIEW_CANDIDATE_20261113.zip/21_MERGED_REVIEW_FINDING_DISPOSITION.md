# Consolidated R2 + secondary document-review finding disposition — candidate V2

**Review provenance:** R2 `R2_review_of_consolidated_offline_core_package_and_change_list_20261113.md` (AI, not human independent); the second document-level reviewer findings F-01..F-07 were supplied in the current conversation, are not signed human evidence, and did not recompute hashes or run tests. Neither review is final acceptance. Both are preserved as documentary findings; the wording below reports our corrective changes, **not** R2's own replay acceptance.

| R2 item | Second review | Treatment in this revision | Residual gate |
|---|---|---|---|
| B1 | F-05 | Stage D03 archive and nine pinned members (including D01 integrated technical spec and 187 detailed test specifications) attached byte-for-byte; D03 V3 and D04 V2 pinned | Independent recheck and source-closed owner selection |
| B2 | F-02 (part) | Configurable-instrument layer, second synthetic instrument `V3EXT-006`, 17 crosswalk and TC-INSTR added | Implement/test at G1; all NOT_RUN |
| B3 | F-01/F-02 | Explicit bans preserved for fitting, promotion, executable deserialisation and the candidate publisher; the trained-model loader is limited to one intake module under MS-B (file 24); pure bid/ask validator. Scope amendments given as exact old/new text in 23 (explained in 20) | Full offline trading with two prediction sources; real model registration separate and later; all five Core-5 trained models UNAVAILABLE; owner must approve source amendment |
| B4 | F-03 | Seven canonical state axes corrected to exact Stage D specification; source graph pinned | 42/84 alignment and tests NOT_RUN |
| B5 | F-06 | Actual 27 Oct grouped wait decision attached and hash-matched; clock metadata corrected to 48 *required*, 0 elapsed | No timer until final presentation, independent proof and frozen group |
| B6 | F-06 | Group 1 principle 5, CAR-01 and source applicability table added in 19 | OWNER CHOICE/CLAUSE CROSSWALK OPEN; cannot assume witness sufficient |
| B7 | F-06 (decisions) | 43 historical master classes + 13/21 proposed classes, comments and sources; all 61 remain NOT_SELECTED | Classes require independent semantic validation and owner choice, no implicit closure |
| C1 | F-07 | Pre-presentation choices provisional; elapsed time 0 while NOT_STARTED | Accepted group not presented |
| — | F-01 | Exact old and new text of fourteen amendments in file 23, each old text verbatim and unique in its pinned file (file 20 explains purpose only); original pinned sources immutable | MUST BE owner-approved against final fingerprints before effective scope |
| — | F-04 | Fill-to-initial-protection account/quantity/stop reconciliation contract and TC-INIT-01..10 | Tests NOT_RUN; no real broker proof |
| — | F-05 | Primary ledger spec and detailed 187 synthetic test specifications now included rather than hashes only | Required human/independent source review OPEN |

**No false completion:** all source amendments PROPOSED, 61 decisions OPEN, 13 freeze findings OPEN, 21 repairs OPEN, real human independence/custody/evidence pending, G0-R/G1-R unsigned, no cooling-off. This is a corrected **candidate**, not a freeze-ready final group.

## R2 mechanical replay of V2 and the residual fixes

R2 replayed V2 once (`REVIEW_EVIDENCE/R2_replay_of_V2_and_residual_fix_list_20261113.md`; AI, not human independent). Everything else in V2 passed. It found these residual items: exact old/new amendment text (now file 23, one controlling form), the EXT section 1.2 row in file 04, protection state names aligned to the pinned ledger specification, one precedence sentence over the Group 1 addendum's UNSET duration, package identifiers, and the review-evidence folder carrying the current checker. They are applied in this revision. The author's own run of `verify_v2_replay.py` is the check; no further R2 review round is part of the process.

## MS-B dual-source predictions (R2, 13 Nov 2026)

The owner chose option B (trained models with signed test scores). R2 read the owner's EC2 inventory: no Core-5 model file was found on the one inspected host, the V2 inference code that R2 holds fits a model on every run, and six other model files exist (file 25). The controlled amendment is AM-10..AM-14 in file 23, the contract and its 19 tests are file 24, and the evidence is file 25. The author's own run of `verify_msb.py` is the check; this is part of the same consolidated process, not a new design stage.
