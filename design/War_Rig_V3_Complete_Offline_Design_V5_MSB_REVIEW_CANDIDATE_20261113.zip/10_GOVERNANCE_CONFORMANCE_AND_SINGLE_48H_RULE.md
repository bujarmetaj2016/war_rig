# Grouped 48h cooling-off and dual signature in one sitting — PROCEDURAL CANDIDATE

**Working Path 1: recommended by R2 and sent to the author at the owner's request (13 Nov 2026); recorded as OD-13 and binding only through the owner's signed records.** One indivisible final evidence-bound group, a single full **48 elapsed hours** after the last final presentation, then two separate owner forms (G0-R exact-hash design approval and G1-R exact-hash implementation grant) executed at the **same owner sitting**, and no coding before G1-R signature. This rests on rules (a) and (b) of the owner-approved 27 Oct decision, attached under `SOURCE_PINS_UNMODIFIED` (`A39_GROUP1_COOLING_OFF_OWNER_DECISION_V2.json`, SHA-256 `d3f39baa…`, bytes verified by R2). A local historical `PENDING_V1` placeholder is specifically NOT relied upon. If primary text contradicts this route, stop and present the exact clause, not an inferred exception.

## Requirement-level source and remaining proof

| Requirement | Primary source | Proposed route compliance | Remaining condition |
|---|---|---|---|
| Group 1 principle 3: cooling-off between final proposal and final approval | Group 1 principles approved-source SHA `be6dad1f…` | Freeze entire final group and wait 48h before final owner signatures | Final presentation proof and exact 48h proof; no earlier signatures |
| Group 1 principle 5: review/quorum and independent controls stay | Group 1 principles, V1 record/V2 addendum | Preserve reviewer independence, witness/custody and K1/H13 countersignatures; do not substitute R2 or AI author | Human appointment, attestation, signatures and copy outside workspace |
| 27 Oct rule (a): grouped interval | Owner-approved cooling-off decision (attached) SHA `d3f39baa27d8a8c91050d19dea32d83883b73eb1ddb80cf4d89dcfbee534143b` | One interval covers separately presented G0-R/G1-R final proposals and evidence if all fixed together, starts after **last** presentation | Decision attached and byte-verified; end-to-end group hashes are fixed at the final presentation |
| 27 Oct rule (b): restart on change | Same 27 Oct owner record | Any change of proposal text, scope or SHA restarts whole indivisible group | Full group diff/restart tracking and no reused time credit |
| Master §0 / §10 distinct G0 and G1 grants | Corrected Master V1.8 SHA `dce9968e…` | Two separately signed fingerprinted records in one sitting after the group hold; G1 not automatic | Exact owner signatures and review proof; separate record IDs |
| EXT §7.1 / §8.1 scope and preimplementation controls | EXT-G0R-14 SHA `256ad6bd…` | Exact R+C scope, module and test manifest, approved environment and deny-egress package before clock | Controlled amendment + signed environment and negative-test inventory |
| Controlled source amendment | Master + EXT + Stage D + ATC-01 | Exact old/new text in `23_CONTROLLED_AMENDMENT_EXACT_TEXT.csv`; purposes in `04_...` | Adopt exact controlled amended text and add hashes to final group |
| WDA/ATC authors not independent reviewers | WDA-08, ATC-01 rev2 | Require separate independent reviewer of those sources | Appointment and actual review attestation |
| V3-GOV-48-01 timing alternative | GOV-48-01 REV3 was proposed, not adopted | Do not treat alternative as active or finish its review if Path 1 source-verified | Preserve unadopted status; no implicit change to standing timing |

## Exact sequence INSIDE ONE CONSOLIDATED STAGE

1. Complete all design and G1-R preimplementation artifacts, with verified reviewer/custody/signature procedures. Resolve owner selections **before** final evidence-bound presentation, but no final G0/G1 acceptance signature before the waiting interval. A selection made before the presentation is a provisional input that becomes binding only through the two signed records at the sitting; a selection changed after the presentation is a change to the group and restarts the interval.
2. Seal the **final** indivisible group: core design + controlled source amendments; 61-row consolidated decisions plus all explicit 43/13/21 dispositions; G1 build/environment manifests and genuine evidence; independent review; both unsigned owner forms; source/governance proof. Hash every member and group root. Present **every** final evidence-bound member to owner; record the latest actual presentation timestamp from a trusted clock.
3. Wait a full 48 elapsed hours from the last presentation. Change to any member's bytes/scope/hash -> void previous group interval, re-freeze/re-present whole set and restart. No design or implementation acceptance during hold.
4. When validly elapsed and when human independence, quorum, witness, K1/H13 and custody conditions hold, owner sits **once** and signs G0-R design acceptance **and** a separately identifiable G1-R grant against exact hashes. A single sitting does not mean a single combined signature substitutes for the two records.
5. Implementation may commence **only** after the actual G1-R signed record is verified. No clock triggers deployment by itself. IG integration, DEMO/LIVE use and V2 retirement remain separate future controlled authorisations.

**Important:** Neither preparing this package nor acknowledging this plan constitutes `WAIT_START`. No user-visible or internal clock begins until an independently verifiable presentation of the genuinely final group occurs. No timer is running now.
